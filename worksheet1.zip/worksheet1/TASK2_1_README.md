# TASK 2.1 - USER INPUT VALIDATION WITH LOOPS

## Overview
This program demonstrates advanced assembly programming concepts including user input, validation logic, conditional jumps, and loop constructs.

## File: task2.asm

### Purpose
- Handle user input from keyboard
- Implement input validation logic
- Use conditional jumps for decision making
- Create loops using assembly constructs
- Demonstrate error handling

### Program Logic Flow
1. **Get User Name**: Prompt and read string input
2. **Get Repeat Count**: Prompt and read integer input
3. **Validate Input**: Check if 50 < number < 100
4. **Execute Loop**: Print welcome message specified number of times
5. **Error Handling**: Display error for invalid input

### Code Structure Analysis

#### Data Section
```assembly
section .data
    prompt_name     db  "Please enter your name: ", 0
    prompt_num      db  "How many times should I print the welcome message? ", 0
    welcome_msg     db  "Welcome, ", 0
    exclamation     db  "!", 0
    error_msg       db  "Error: Number must be between 50 and 100!", 0
```

#### Buffer Section
```assembly
section .bss
    user_name       resb 100    ; Buffer for user name (100 bytes)
    repeat_count    resd 1       ; Storage for repeat count (4 bytes)
```

**Key Concepts:**
- `resb` = Reserve Bytes (uninitialized)
- `resd` = Reserve Double-words (uninitialized)
- `.bss` section for uninitialized data

### Advanced Assembly Concepts

#### Input Validation Logic
```assembly
; Validate number (must be 50 < num < 100)
cmp     eax, 50
jle     error_exit      ; Jump if <= 50
cmp     eax, 100
jge     error_exit      ; Jump if >= 100
```

**Comparison Instructions:**
- `cmp` = Compare (sets flags)
- `jle` = Jump if Less or Equal
- `jge` = Jump if Greater or Equal

#### Loop Implementation
```assembly
print_loop:
    ; Print welcome message components
    mov     rdi, welcome_msg
    call    print_string
    mov     rdi, user_name
    call    print_string
    mov     rdi, exclamation
    call    print_string
    call    print_nl
    
    ; Loop control
    dec     ecx             ; Decrement counter
    cmp     ecx, 0          ; Compare with zero
    jg      print_loop      ; Jump if greater than zero
```

**Loop Concepts:**
- Counter-based loop using ECX register
- `dec` = Decrement instruction
- `jg` = Jump if Greater

#### String Operations
```assembly
mov     rdi, user_name      ; String parameter in RDI
mov     rsi, 100            ; Buffer size in RSI
call    read_string         ; Read string from user
```

### Testing Results ✅

#### Valid Input Test
```bash
echo -e "John\n75" | ./task2
```
**Output:** Welcome message printed multiple times

#### Invalid Input Tests
```bash
echo -e "John\n49" | ./task2   # Too low
echo -e "John\n101" | ./task2  # Too high
```
**Output:** Error message displayed correctly

### Register Usage Patterns

#### Function Call Registers
- **RDI**: First parameter (strings)
- **RSI**: Second parameter (buffer size)
- **EAX**: Return values and calculations
- **ECX**: Loop counter

#### Conditional Jump Instructions
- **JLE**: Jump if Less or Equal (signed)
- **JGE**: Jump if Greater or Equal (signed)
- **JG**: Jump if Greater (signed)
- **JMP**: Unconditional jump

### Memory Management

#### Stack Frame
```assembly
push    rbp          ; Save caller's base pointer
mov     rbp, rsp     ; Establish new stack frame
...
pop     rbp          ; Restore caller's base pointer
ret                  ; Return to caller
```

#### Data Storage
- **Global strings**: In `.data` section
- **User input buffer**: In `.bss` section
- **Temporary values**: In registers

### Error Handling Strategy
1. **Input Validation**: Check bounds before processing
2. **Branch to Error Handler**: Use conditional jumps
3. **Error Message Display**: Clear error communication
4. **Program Termination**: Return error code

### Learning Objectives Achieved
1. ✅ User input handling
2. ✅ String operations
3. ✅ Input validation logic
4. ✅ Conditional jumps and branching
5. ✅ Loop constructs
6. ✅ Error handling
7. ✅ Register management
8. ✅ Memory buffer usage

### Compilation Details
- Assembled with NASM for x86-64
- Links with C library for I/O functions
- Uses System V AMD64 calling convention

### Integration Notes
- Part of modular worksheet solution
- Shares I/O library with other tasks
- Built through unified Makefile system