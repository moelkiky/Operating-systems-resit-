# TASK 2.2 - ARRAY INITIALIZATION AND SUM CALCULATION

## Overview
This program demonstrates advanced array operations, pointer arithmetic, loop constructs, and accumulator patterns in x86-64 assembly.

## File: task2_2.asm

### Purpose
- Initialize large arrays with sequential data
- Implement pointer arithmetic for array traversal
- Use nested loops for data processing
- Demonstrate accumulator programming patterns
- Show memory management for large data structures

### Program Algorithm
1. **Array Initialization Loop**: Fill array with values 1-100
2. **Sum Calculation Loop**: Iterate through array and accumulate sum
3. **Result Display**: Show calculated sum and expected result
4. **Verification**: Compare with mathematical expectation (5050)

### Code Structure Deep Dive

#### Memory Layout
```assembly
section .data
    msg1        db  "Initializing array with numbers 1-100...", 0
    msg2        db  "Sum of array elements: ", 0
    msg3        db  "Expected sum: 5050", 0
    
section .bss
    array       resd 100    ; Array of 100 integers (400 bytes total)
```

**Memory Allocation:**
- `resd 100` = Reserve 100 double-words
- Each double-word = 4 bytes
- Total memory = 400 bytes
- Uninitialized memory in .bss section

### Advanced Array Operations

#### Array Initialization Pattern
```assembly
mov     ecx, 1          ; Counter starting at 1
mov     rsi, array      ; Point to start of array

init_loop:
    mov     [rsi], ecx      ; Store current value in array
    add     rsi, 4          ; Move to next array element (4 bytes per int)
    inc     ecx             ; Increment counter
    cmp     ecx, 101        ; Check if we've done 100 elements
    jl      init_loop       ; Continue if counter < 101
```

**Key Concepts:**
- **Pointer Arithmetic**: `add rsi, 4` moves to next integer
- **Memory Store**: `[rsi]` dereferences pointer for storage
- **Loop Counter**: ECX tracks current value and position
- **Boundary Check**: Compare with 101 to process exactly 100 elements

#### Sum Calculation Pattern
```assembly
mov     ecx, 100        ; Number of elements
mov     rsi, array      ; Point to start of array
mov     eax, 0          ; Initialize sum to 0

sum_loop:
    add     eax, [rsi]      ; Add current element to sum
    add     rsi, 4          ; Move to next element
    dec     ecx             ; Decrement counter
    cmp     ecx, 0          ; Check if done
    jg      sum_loop        ; Continue if more elements
```

**Accumulator Pattern:**
- **EAX**: Accumulator register for running sum
- **Memory Load**: `[rsi]` loads current array element
- **Pointer Increment**: Move 4 bytes per iteration
- **Countdown Loop**: Decrement counter until zero

### Pointer Arithmetic Explained

#### Memory Address Calculation
```
Base Address: array
Element 0: array + (0 * 4) = array + 0
Element 1: array + (1 * 4) = array + 4
Element 2: array + (2 * 4) = array + 8
...
Element 99: array + (99 * 4) = array + 396
```

#### Register as Pointer
```assembly
mov     rsi, array      ; RSI = base address
add     rsi, 4          ; RSI = RSI + 4 (next element)
mov     eax, [rsi]      ; Load value at address RSI
```

### Mathematical Verification

#### Expected Sum Formula
Sum of 1 to 100 = n(n+1)/2 where n=100
= 100 × 101 / 2
= 10100 / 2
= 5050

#### Array Contents
```
array[0] = 1
array[1] = 2
array[2] = 3
...
array[99] = 100
```

### Register Usage Strategy

#### Initialization Phase
- **ECX**: Current value to store (1, 2, 3, ..., 100)
- **RSI**: Pointer to current array position
- **Loop bounds**: 1 to 100 inclusive

#### Summation Phase
- **EAX**: Running sum accumulator
- **RSI**: Pointer to current array element
- **ECX**: Countdown counter (100, 99, 98, ..., 1)

### Memory Access Patterns

#### Sequential Access
```assembly
mov     rsi, array      ; Start at beginning
; Process array[0]
add     rsi, 4          ; Move to array[1]
; Process array[1]
add     rsi, 4          ; Move to array[2]
; And so on...
```

#### Cache-Friendly Access
- Sequential memory access pattern
- Optimal for CPU cache performance
- Predictable memory addressing

### Loop Constructs Comparison

#### Count-Up Loop (Initialization)
```assembly
mov     ecx, 1          ; Start value
init_loop:
    ; Process current value in ECX
    inc     ecx         ; Increment
    cmp     ecx, 101    ; Check upper bound
    jl      init_loop   ; Continue if less
```

#### Count-Down Loop (Summation)
```assembly
mov     ecx, 100        ; Start with count
sum_loop:
    ; Process current element
    dec     ecx         ; Decrement count
    cmp     ecx, 0      ; Check if zero
    jg      sum_loop    ; Continue if greater
```

### Testing and Verification

#### Expected Output
```
Initializing array with numbers 1-100...
Sum of array elements: [calculated sum]
Expected sum: 5050
```

#### Verification Steps
1. Array initialized with correct sequence
2. Sum calculation uses proper accumulator
3. Result compared with mathematical expectation
4. Program demonstrates understanding of loops and arrays

### Performance Characteristics

#### Time Complexity
- Initialization: O(n) where n=100
- Summation: O(n) where n=100
- Overall: O(n) linear time

#### Space Complexity
- Array storage: 400 bytes (100 × 4-byte integers)
- Additional variables: ~16 bytes
- Stack frame: minimal overhead

### Learning Objectives Achieved
1. ✅ Large array allocation and management
2. ✅ Pointer arithmetic for array traversal
3. ✅ Sequential memory access patterns
4. ✅ Loop constructs (count-up and count-down)
5. ✅ Accumulator programming patterns
6. ✅ Memory-to-register data movement
7. ✅ Mathematical verification of results
8. ✅ Performance-conscious programming

### Integration with Worksheet
- Demonstrates advanced assembly concepts
- Shows practical application of loops
- Illustrates memory management skills
- Provides mathematical verification approach