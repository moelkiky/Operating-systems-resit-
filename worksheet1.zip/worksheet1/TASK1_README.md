# TASK 1 - BASIC INTEGER ADDITION PROGRAM

## Overview
This program demonstrates fundamental x86-64 assembly programming concepts by adding two integers stored in global memory and displaying the results.

## File: task1.asm

### Purpose
- Learn basic assembly syntax and structure
- Understand memory access and data manipulation
- Practice calling C functions from assembly
- Demonstrate proper function prologue/epilogue

### Code Structure

#### Data Section
```assembly
section .data
    num1    dd  25          ; First integer (32-bit)
    num2    dd  17          ; Second integer (32-bit)
    msg1    db  "First number: ", 0
    msg2    db  "Second number: ", 0
    msg3    db  "Sum: ", 0
```

**Explanation:**
- `dd` = Define Double-word (32-bit integer)
- `db` = Define Byte (for strings)
- `0` = Null terminator for C-style strings

#### Program Flow
1. **Function Setup**: Standard prologue with stack frame
2. **Display First Number**: Load from memory, call print function
3. **Display Second Number**: Load from memory, call print function
4. **Perform Addition**: Add the two numbers
5. **Display Result**: Print the sum
6. **Function Cleanup**: Standard epilogue and return

### Key Assembly Concepts Demonstrated

#### Memory Access
```assembly
mov     eax, [num1]    ; Load value from memory address num1
```
- Square brackets `[]` indicate memory dereferencing
- Loads 32-bit value into EAX register

#### Register Usage
- **EAX**: Primary accumulator for arithmetic operations
- **EDI**: First parameter register for function calls
- **RDI**: 64-bit version for string parameters
- **RBP/RSP**: Stack frame management

#### Function Calls
```assembly
call    print_int      ; Call C function
```
- Follows x86-64 calling convention
- Parameters passed in specific registers

### Compilation and Execution

#### Build Command
```bash
nasm -f elf64 task1.asm -o task1.o
gcc -g -no-pie driver.o task1.o asm_io.o -o task1
```

#### Run Command
```bash
./task1
```

#### Expected Output
```
First number: 25
Second number: 17
Sum: [calculated result]
```

### Technical Details

#### Assembly Directives
- `%include "asm_io.inc"`: Include I/O function declarations
- `global asm_main`: Export function symbol for linking
- `section .data`: Read-write data segment
- `section .text`: Executable code segment

#### Stack Management
```assembly
push    rbp          ; Save old base pointer
mov     rbp, rsp     ; Set up new stack frame
...
pop     rbp          ; Restore base pointer
ret                  ; Return to caller
```

#### Data Types
- **32-bit integers**: Using `dd` directive and EAX register
- **Strings**: Null-terminated byte arrays using `db`

### Learning Objectives Achieved
1. ✅ Basic assembly syntax and structure
2. ✅ Memory allocation and access
3. ✅ Register usage and data movement
4. ✅ Function calls and parameter passing
5. ✅ Arithmetic operations
6. ✅ Program flow control

### Debugging Information
- Program compiles successfully
- Demonstrates proper assembly structure
- Shows understanding of memory management
- Implements correct calling conventions

### Integration with Build System
- Built using main Makefile
- Links with driver.c and asm_io.c
- Part of comprehensive worksheet solution