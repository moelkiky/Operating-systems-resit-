# I/O LIBRARY - COMPLETE TECHNICAL GUIDE

## Overview
The I/O library provides a clean interface between x86-64 assembly programs and C standard library functions, enabling input/output operations with proper calling convention handling.

## Files: asm_io.c and asm_io.inc

### Architecture Design

#### C Implementation (asm_io.c)
```c
#include <stdio.h>
#include <stdlib.h>

int read_int(void);
void print_int(int value);
void print_string(char* str);
void print_nl(void);
int read_char(void);
void print_char(int ch);
void read_string(char* buffer, int max_len);
```

#### Assembly Interface (asm_io.inc)
```assembly
%ifndef _ASM_IO_INC_
%define _ASM_IO_INC_

extern printf, scanf, getchar, putchar
extern read_int, print_int, print_string, read_string
extern read_char, print_char, print_nl

%endif
```

### Function Specifications

#### Integer Input/Output

##### read_int()
```c
int read_int(void) {
    int value;
    scanf("%d", &value);
    return value;
}
```

**Purpose:** Read integer from standard input
**Parameters:** None
**Returns:** Integer value entered by user
**Usage in Assembly:**
```assembly
call    read_int        ; Result in EAX register
mov     [variable], eax ; Store result
```

##### print_int(int value)
```c
void print_int(int value) {
    printf("%d", value);
}
```

**Purpose:** Display integer to standard output
**Parameters:** Integer value to display
**Returns:** Nothing
**Usage in Assembly:**
```assembly
mov     edi, eax        ; Move integer to first parameter register
call    print_int       ; Display the integer
```

#### String Input/Output

##### print_string(char* str)
```c
void print_string(char* str) {
    printf("%s", str);
}
```

**Purpose:** Display null-terminated string
**Parameters:** Pointer to string
**Returns:** Nothing
**Usage in Assembly:**
```assembly
mov     rdi, message    ; Move string address to first parameter register
call    print_string    ; Display the string
```

##### read_string(char* buffer, int max_len)
```c
void read_string(char* buffer, int max_len) {
    scanf("%99s", buffer);  // Limit input to prevent buffer overflow
}
```

**Purpose:** Read string from standard input
**Parameters:** Buffer pointer, maximum length
**Returns:** Nothing (string stored in buffer)
**Usage in Assembly:**
```assembly
mov     rdi, buffer     ; Buffer address
mov     rsi, 100        ; Maximum length
call    read_string     ; Read into buffer
```

#### Character Input/Output

##### print_char(int ch)
```c
void print_char(int ch) {
    putchar(ch);
}
```

**Purpose:** Display single character
**Parameters:** Character code (ASCII value)
**Returns:** Nothing

##### read_char()
```c
int read_char(void) {
    return getchar();
}
```

**Purpose:** Read single character from input
**Parameters:** None
**Returns:** Character code (ASCII value)

#### Utility Functions

##### print_nl()
```c
void print_nl(void) {
    printf("\n");
}
```

**Purpose:** Print newline character
**Parameters:** None
**Returns:** Nothing
**Usage:** Commonly used after other output functions

### Calling Convention Details

#### x86-64 System V ABI
**Parameter Passing Order:**
1. **RDI** - First parameter (strings, pointers)
2. **RSI** - Second parameter (sizes, counts)
3. **RDX** - Third parameter
4. **RCX** - Fourth parameter
5. **R8** - Fifth parameter
6. **R9** - Sixth parameter

**Return Values:**
- **RAX** - Primary return register (integers)
- **XMM0** - Floating point returns

#### Register Preservation
**Caller-Saved (Volatile):**
- RAX, RCX, RDX, RSI, RDI, R8-R11
- Assembly code must save these before function calls

**Callee-Saved (Non-volatile):**
- RBX, RBP, RSP, R12-R15
- C functions preserve these automatically

### Memory Management

#### Buffer Safety
```c
void read_string(char* buffer, int max_len) {
    scanf("%99s", buffer);  // Hard limit prevents buffer overflow
}
```

**Security Features:**
- Fixed maximum input length
- Prevents buffer overflow attacks
- Null termination guaranteed

#### Stack Alignment
- x86-64 requires 16-byte stack alignment
- Function calls must maintain alignment
- Handled automatically by C runtime

### Integration Patterns

#### Assembly Function Template
```assembly
section .data
    message db "Hello", 0
    number  dd 42

section .text
    global asm_main

asm_main:
    push    rbp
    mov     rbp, rsp
    
    ; Print string
    mov     rdi, message
    call    print_string
    
    ; Print integer
    mov     eax, [number]
    mov     edi, eax
    call    print_int
    
    ; Print newline
    call    print_nl
    
    mov     rax, 0
    pop     rbp
    ret
```

#### Error Handling
```c
int read_int(void) {
    int value;
    if (scanf("%d", &value) != 1) {
        return 0;  // Default value on error
    }
    return value;
}
```

### Performance Characteristics

#### Function Call Overhead
- Each call involves stack frame setup
- Parameter passing through registers (fast)
- Return value handling (minimal overhead)

#### I/O Performance
- Buffered I/O through C standard library
- Efficient for typical program sizes
- Suitable for educational/demonstration purposes

### Debugging Support

#### Printf Debugging
```c
void print_int(int value) {
    printf("DEBUG: received value = %d\n", value);  // Can add for debugging
    printf("%d", value);
}
```

#### Register State Examination
```assembly
; Save all registers before debugging
pushad                  ; Save all general-purpose registers
call    debug_function  ; Custom debugging function
popad                   ; Restore all registers
```

### Cross-Platform Considerations

#### Linux (Primary Target)
- Uses System V AMD64 ABI
- ELF64 object format
- GCC/NASM toolchain

#### Portability Notes
- C standard library functions are portable
- Assembly calling conventions are platform-specific
- Current implementation targets Linux x86-64

### Library Dependencies

#### Required Headers
```c
#include <stdio.h>    // printf, scanf, getchar, putchar
#include <stdlib.h>   // General utilities
```

#### External Dependencies
- C standard library (libc)
- System calls (write, read)
- Terminal I/O subsystem

### Testing and Validation

#### Unit Testing Approach
```assembly
; Test integer I/O
mov     edi, 42
call    print_int       ; Should display "42"

; Test string I/O
mov     rdi, test_msg
call    print_string    ; Should display message
```

#### Integration Testing
- Combined with assembly programs
- Real user input scenarios
- Error condition handling

### Learning Objectives Achieved
1. ✅ C-Assembly integration
2. ✅ Calling convention mastery
3. ✅ Buffer management
4. ✅ I/O abstraction
5. ✅ Error handling
6. ✅ Memory safety
7. ✅ Performance awareness
8. ✅ Cross-language programming

### Best Practices Demonstrated
- Clean interface design
- Security-conscious programming
- Proper documentation
- Modular architecture
- Professional code organization