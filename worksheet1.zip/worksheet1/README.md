# Operating Systems Worksheet 1 - Assembly Programming

This repository contains solutions for UFCFWK-15-2 Operating Systems Worksheet 1, focusing on x86 assembly language programming. The worksheet covers basic assembly programming, calling C from assembly, translating C loops to assembly, and using make to build programs.

## Directory Structure

```
worksheet1/
├── README.md          # This documentation file
└── src/
    ├── asm_io.inc     # I/O function declarations and macros
    ├── asm_io.asm     # I/O function implementations
    ├── driver.c       # C driver program
    ├── task1.asm      # Task 1: Basic integer addition
    ├── task2.asm      # Task 2.1: User input with validation
    ├── task2_2.asm    # Task 2.2: Array initialization and sum
    └── Makefile       # Build automation
```

## Compilation and Execution

### Prerequisites
- NASM (Netwide Assembler)
- GCC compiler with 32-bit support
- Linux environment

### Build All Programs
```bash
cd src/
make all
```

### Build Individual Programs
```bash
make task1      # Build Task 1
make task2      # Build Task 2.1
make task2_2    # Build Task 2.2
```

### Run Programs
```bash
./task1         # Run Task 1
./task2         # Run Task 2.1
./task2_2       # Run Task 2.2
```

### Clean Generated Files
```bash
make clean
```

## Task Implementations

### Task 1: Basic Assembly Programming (20%)

#### Task 1.1: Integer Addition Program

**Purpose**: Demonstrates basic assembly programming concepts including data declaration, memory access, and function calls.

**Key Assembly Concepts**:
- **Data Segment**: Declaring global variables with `dd` (define double-word)
- **Memory Access**: Using `[variable]` syntax to access memory
- **Register Usage**: EAX register for function parameters and return values
- **Function Structure**: Standard prologue (`enter`) and epilogue (`leave`, `ret`)

**Code Snippet**:
```assembly
; Add two numbers stored in memory
mov     eax, [num1]   ; Load first number into EAX
add     eax, [num2]   ; Add second number to EAX
```

**Expected Output**:
```
First number: 25
Second number: 17
Sum: 42
```

### Task 2: Loops and Conditionals (20%)

#### Task 2.1: User Input with Validation

**Purpose**: Demonstrates input/output operations, conditional jumps, and loop constructs in assembly.

**Key Assembly Concepts**:
- **String Input**: Using `read_string` for text input
- **Integer Input**: Using `read_int` for numeric input
- **Conditional Jumps**: `jle` (jump if less or equal), `jge` (jump if greater or equal)
- **Loop Implementation**: Using counter register (ECX) with `dec` and conditional jumps
- **Error Handling**: Branching to error handling code

**Code Snippet**:
```assembly
; Validate number (must be 50 < num < 100)
cmp     eax, 50
jle     error_exit      ; Jump if <= 50
cmp     eax, 100
jge     error_exit      ; Jump if >= 100

; Loop implementation
print_loop:
    ; ... print welcome message ...
    dec     ecx
    cmp     ecx, 0
    jg      print_loop
```

**Sample Interaction**:
```
Please enter your name: John
How many times should I print the welcome message? 75
Welcome, John!
Welcome, John!
... (75 times total)
```

#### Task 2.2: Array Initialization and Sum

**Purpose**: Demonstrates array manipulation, pointer arithmetic, and accumulator patterns in assembly.

**Key Assembly Concepts**:
- **Array Declaration**: Using `resd 100` to reserve space for 100 integers
- **Pointer Arithmetic**: Using ESI register with `add esi, 4` to traverse array
- **Loop Counters**: Using ECX for counting iterations
- **Accumulator Pattern**: Using EAX to accumulate sum values

**Code Snippet**:
```assembly
; Initialize array with values 1-100
init_loop:
    mov     [esi], ecx      ; Store current value in array
    add     esi, 4          ; Move to next array element (4 bytes per int)
    inc     ecx             ; Increment counter
    cmp     ecx, 101        ; Check if we've done 100 elements
    jl      init_loop       ; Continue if counter < 101

; Calculate sum
sum_loop:
    add     eax, [esi]      ; Add current element to sum
    add     esi, 4          ; Move to next element
    dec     ecx             ; Decrement counter
    jg      sum_loop        ; Continue if more elements
```

**Expected Output**:
```
Initializing array with numbers 1-100...
Sum of array elements: 5050
Expected sum: 5050
```

## Assembly Programming Concepts Covered

### 1. Registers
- **EAX**: Primary accumulator, function parameters and return values
- **EBX**: Base register, temporary storage
- **ECX**: Counter register, loop iterations
- **ESI**: Source index, array traversal
- **ESP**: Stack pointer (managed automatically)
- **EBP**: Base pointer (managed by enter/leave)

### 2. Memory Operations
- **MOV**: Transfer data between registers and memory
- **ADD**: Arithmetic addition
- **CMP**: Compare values (sets flags)
- **INC/DEC**: Increment/decrement operations

### 3. Control Flow
- **Conditional Jumps**: JL, JLE, JG, JGE, JE, JNE
- **Unconditional Jump**: JMP
- **Function Calls**: CALL and RET
- **Loop Implementation**: Counter-based and condition-based loops

### 4. Function Structure
- **Prologue**: `enter 0,0` - set up stack frame
- **Epilogue**: `leave` and `ret` - clean up and return
- **Calling Convention**: cdecl standard

### 5. Data Types and Storage
- **DD**: Define double-word (32-bit integers)
- **DB**: Define byte (strings and characters)
- **RESD**: Reserve space for double-words
- **RESB**: Reserve space for bytes

## Build System (Task 3)

The Makefile provides comprehensive build automation:

- **Modular Compilation**: Separate compilation of C and assembly files
- **Dependency Management**: Proper file dependencies
- **Multiple Targets**: Individual program builds
- **Clean Operations**: Remove generated files
- **Test Automation**: Automated program execution

**Key Makefile Features**:
```makefile
# 32-bit compilation flags
CFLAGS = -m32
ASMFLAGS = -f elf

# Automatic dependency handling
$(TASK1_EXE): $(TASK1_OBJ) $(DRIVER_OBJ) $(ASM_IO_OBJ)
    $(CC) $(CFLAGS) $(DRIVER_OBJ) $(TASK1_OBJ) $(ASM_IO_OBJ) -o $(TASK1_EXE)
```

## Testing and Validation

### Task 1 Testing
- Verify correct addition of global variables
- Check proper output formatting
- Validate function return codes

### Task 2.1 Testing
- Test input validation with edge cases (49, 50, 100, 101)
- Verify correct loop iteration counts
- Test with various name inputs

### Task 2.2 Testing
- Verify array initialization with correct values
- Validate sum calculation (should be 5050)
- Check memory access patterns

## Implementation Challenges and Solutions

### Challenge 1: Memory Addressing
**Problem**: Understanding 32-bit memory addressing modes
**Solution**: Used bracket notation `[variable]` for memory access and proper register sizing

### Challenge 2: Loop Implementation
**Problem**: Translating high-level loop constructs to assembly
**Solution**: Implemented counter-based loops with ECX register and conditional jumps

### Challenge 3: Function Calling Convention
**Problem**: Proper stack management and parameter passing
**Solution**: Used standard cdecl convention with enter/leave instructions

### Challenge 4: Input/Output Operations
**Problem**: Interfacing with C library functions from assembly
**Solution**: Created comprehensive asm_io module with proper function declarations

## Low-Level Programming Insights

This worksheet demonstrates several key operating systems concepts:

1. **CPU Instruction Execution**: Direct control over processor instructions
2. **Memory Management**: Manual memory addressing and pointer arithmetic
3. **System Call Interface**: Understanding how high-level I/O translates to system calls
4. **Stack Management**: Function call overhead and stack frame operations
5. **Binary Representation**: Working directly with 32-bit integers and memory layouts

## Technical Specifications

- **Architecture**: x86 (32-bit)
- **Assembler**: NASM (Netwide Assembler)
- **Syntax**: Intel syntax
- **Calling Convention**: cdecl
- **Target Platform**: Linux with GCC

## Files Description

### Core Assembly Files
- `task1.asm`: Basic arithmetic and I/O demonstration
- `task2.asm`: Control flow and input validation
- `task2_2.asm`: Array operations and loops

### Support Files
- `driver.c`: C wrapper for assembly functions
- `asm_io.asm`: I/O function implementations
- `asm_io.inc`: Function declarations and macros
- `Makefile`: Automated build system

## Author

Created for UFCFWK-15-2 Operating Systems Course - Worksheet 1  
Assembly Programming Fundamentals