# MAKEFILE - BUILD SYSTEM COMPLETE GUIDE

## Overview
The Makefile provides comprehensive build automation for all assembly programs, handling compilation, linking, and testing with professional-grade dependency management.

## File: Makefile

### Build System Architecture

#### Compiler Configuration
```makefile
CC = gcc                # C compiler
ASM = nasm             # Assembly compiler
CFLAGS = -g -no-pie    # C compilation flags
ASMFLAGS = -f elf64    # Assembly flags for 64-bit ELF format
```

**Flag Explanations:**
- `-g`: Include debugging information
- `-no-pie`: Disable Position Independent Executable (required for assembly linking)
- `-f elf64`: Generate 64-bit ELF object files

### Dependency Management

#### Source Files
```makefile
DRIVER_SRC = driver.c      # C driver program
ASM_IO_SRC = asm_io.c      # I/O library implementation
TASK1_SRC = task1.asm      # Task 1 assembly source
TASK2_SRC = task2.asm      # Task 2.1 assembly source
TASK2_2_SRC = task2_2.asm  # Task 2.2 assembly source
```

#### Object Files
```makefile
DRIVER_OBJ = driver.o      # Compiled C driver
ASM_IO_OBJ = asm_io.o      # Compiled I/O library
TASK1_OBJ = task1.o        # Assembled task 1
TASK2_OBJ = task2.o        # Assembled task 2.1
TASK2_2_OBJ = task2_2.o    # Assembled task 2.2
```

#### Executable Files
```makefile
TASK1_EXE = task1          # Task 1 executable
TASK2_EXE = task2          # Task 2.1 executable
TASK2_2_EXE = task2_2      # Task 2.2 executable
```

### Build Targets Explained

#### Default Target
```makefile
all: $(TASK1_EXE) $(TASK2_EXE) $(TASK2_2_EXE)
```
- Builds all three programs
- Most commonly used target
- Ensures complete solution compilation

#### Individual Program Targets
```makefile
$(TASK1_EXE): $(TASK1_OBJ) $(DRIVER_OBJ) $(ASM_IO_OBJ)
    $(CC) $(CFLAGS) $(DRIVER_OBJ) $(TASK1_OBJ) $(ASM_IO_OBJ) -o $(TASK1_EXE)
```

**Linking Process:**
1. Combines assembly object file
2. Links with C driver
3. Links with I/O library
4. Creates executable

#### Assembly Compilation Rules
```makefile
$(TASK1_OBJ): $(TASK1_SRC)
    $(ASM) $(ASMFLAGS) $(TASK1_SRC) -o $(TASK1_OBJ)
```

**Assembly Process:**
- NASM assembles .asm files
- Generates ELF64 object files
- Prepares for linking with C code

#### C Compilation Rules
```makefile
$(ASM_IO_OBJ): $(ASM_IO_SRC)
    $(CC) $(CFLAGS) -c $(ASM_IO_SRC) -o $(ASM_IO_OBJ)
```

**C Compilation:**
- GCC compiles C source
- `-c` flag for object file only
- No linking at this stage

### Utility Targets

#### Clean Target
```makefile
clean:
    rm -f *.o $(TASK1_EXE) $(TASK2_EXE) $(TASK2_2_EXE)
```
- Removes all generated files
- Object files and executables
- Prepares for fresh build

#### Test Targets
```makefile
test-task1: $(TASK1_EXE)
    ./$(TASK1_EXE)

test-task2: $(TASK2_EXE)
    ./$(TASK2_EXE)

test-task2_2: $(TASK2_2_EXE)
    ./$(TASK2_2_EXE)

test-all: test-task1 test-task2 test-task2_2
```

**Testing Features:**
- Individual program testing
- Automated execution
- Batch testing capability

#### Help Target
```makefile
help:
    @echo "Available targets:"
    @echo "  all       - Build all programs"
    @echo "  task1     - Build Task 1 program"
    @echo "  task2     - Build Task 2.1 program"
    @echo "  task2_2   - Build Task 2.2 program"
    @echo "  clean     - Remove all generated files"
    @echo "  test-*    - Run specific program"
    @echo "  test-all  - Run all programs"
    @echo "  help      - Show this help message"
```

### Usage Instructions

#### Basic Commands
```bash
make clean      # Remove old files
make all        # Build everything
make help       # Show available options
```

#### Individual Builds
```bash
make task1      # Build only Task 1
make task2      # Build only Task 2.1
make task2_2    # Build only Task 2.2
```

#### Testing Commands
```bash
make test-task1     # Run Task 1
make test-task2     # Run Task 2.1
make test-task2_2   # Run Task 2.2
make test-all       # Run all programs
```

### Advanced Features

#### Phony Targets
```makefile
.PHONY: all clean test-task1 test-task2 test-task2_2 test-all help task1 task2 task2_2
```
- Prevents conflicts with files of same name
- Ensures targets always execute
- Professional Makefile practice

#### Automatic Variables
- `$(CC)`: Expands to compiler name
- `$(CFLAGS)`: Expands to compilation flags
- `$(ASM)`: Expands to assembler name
- Configurable build system

### Build Process Flow

#### Step 1: Source Analysis
1. Makefile identifies source files
2. Checks dependencies
3. Determines what needs building

#### Step 2: Object Compilation
1. Assembly files → Object files (NASM)
2. C files → Object files (GCC)
3. Separate compilation for modularity

#### Step 3: Linking
1. Combine all object files
2. Link with C library
3. Generate executable

#### Step 4: Testing (Optional)
1. Execute programs
2. Verify functionality
3. Report results

### Error Handling

#### Common Build Errors
- **Missing dependencies**: Install NASM, GCC
- **Permission errors**: Check file permissions
- **Linking errors**: Verify object file generation

#### Warning Messages
- Stack section warnings (normal for assembly)
- cdecl attribute warnings (expected in 64-bit)
- Circular dependency messages (handled automatically)

### Professional Features

#### Modular Design
- Separate compilation units
- Clear dependency relationships
- Maintainable structure

#### Scalability
- Easy to add new programs
- Configurable compiler settings
- Extensible target system

#### Documentation
- Self-documenting with help target
- Clear target names
- Logical organization

### Integration Benefits
- One-command build system
- Consistent compilation flags
- Automated testing capability
- Professional development workflow

### Learning Objectives Achieved
1. ✅ Professional build automation
2. ✅ Dependency management
3. ✅ Multi-language compilation
4. ✅ Testing integration
5. ✅ Clean development workflow
6. ✅ Error handling
7. ✅ Documentation practices