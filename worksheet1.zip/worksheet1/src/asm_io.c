/*
 * file: asm_io.c
 * Simple I/O functions for assembly programs
 */

#include <stdio.h>
#include <stdlib.h>

int read_int(void) {
    int value;
    scanf("%d", &value);
    return value;
}

void print_int(int value) {
    printf("%d", value);
}

void print_string(char* str) {
    printf("%s", str);
}

void print_nl(void) {
    printf("\n");
}

int read_char(void) {
    return getchar();
}

void print_char(int ch) {
    putchar(ch);
}

void read_string(char* buffer, int max_len) {
    scanf("%99s", buffer);  // Limit input to prevent buffer overflow
}