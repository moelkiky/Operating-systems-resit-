/*
 * file: driver.c
 * C driver program for assembly functions
 * This program calls the asm_main function implemented in assembly
 */

int __attribute__((cdecl)) asm_main( void );

int main() {
    int ret_status;
    ret_status = asm_main();
    return ret_status;
}