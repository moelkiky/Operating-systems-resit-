#include "framebuffer.h"
#include "../drivers/interrupts.h"
#include "../drivers/pic.h"
#include "../drivers/keyboard.h"

// String utility functions
int strlen(const char* str) {
    int len = 0;
    while (str[len]) len++;
    return len;
}

int strcmp(const char* str1, const char* str2) {
    while (*str1 && (*str1 == *str2)) {
        str1++;
        str2++;
    }
    return *(unsigned char*)str1 - *(unsigned char*)str2;
}

void strcpy(char* dest, const char* src) {
    while (*src) {
        *dest = *src;
        dest++;
        src++;
    }
    *dest = '\0';
}

// Simple shell commands
void cmd_help(void) {
    fb_write_string("Available commands:\n", FB_MAKE_COLOR(FB_CYAN, FB_BLACK));
    fb_write_string("  help    - Show this help message\n", FB_MAKE_COLOR(FB_WHITE, FB_BLACK));
    fb_write_string("  clear   - Clear the screen\n", FB_MAKE_COLOR(FB_WHITE, FB_BLACK));
    fb_write_string("  echo    - Echo back what you type\n", FB_MAKE_COLOR(FB_WHITE, FB_BLACK));
    fb_write_string("  calc    - Simple calculator\n", FB_MAKE_COLOR(FB_WHITE, FB_BLACK));
    fb_write_string("  reboot  - Reboot the system\n", FB_MAKE_COLOR(FB_WHITE, FB_BLACK));
}

void cmd_clear(void) {
    fb_clear();
}

void cmd_echo(void) {
    char buffer[256];
    fb_write_string("Enter text to echo: ", FB_MAKE_COLOR(FB_YELLOW, FB_BLACK));
    readline(buffer, sizeof(buffer));
    fb_write_string("You typed: ", FB_MAKE_COLOR(FB_GREEN, FB_BLACK));
    fb_write_string(buffer, FB_MAKE_COLOR(FB_WHITE, FB_BLACK));
    fb_write_string("\n", FB_MAKE_COLOR(FB_WHITE, FB_BLACK));
}

void cmd_calc(void) {
    char buffer[256];
    fb_write_string("Simple calculator - Enter expression (e.g., 5+3): ", FB_MAKE_COLOR(FB_YELLOW, FB_BLACK));
    readline(buffer, sizeof(buffer));
    
    // Very simple parser for demonstration
    int num1 = 0, num2 = 0;
    char op = 0;
    int result = 0;
    
    // Parse first number
    int i = 0;
    while (buffer[i] >= '0' && buffer[i] <= '9') {
        num1 = num1 * 10 + (buffer[i] - '0');
        i++;
    }
    
    // Get operator
    if (buffer[i] == '+' || buffer[i] == '-' || buffer[i] == '*' || buffer[i] == '/') {
        op = buffer[i];
        i++;
    }
    
    // Parse second number
    while (buffer[i] >= '0' && buffer[i] <= '9') {
        num2 = num2 * 10 + (buffer[i] - '0');
        i++;
    }
    
    // Calculate result
    switch (op) {
        case '+': result = num1 + num2; break;
        case '-': result = num1 - num2; break;
        case '*': result = num1 * num2; break;
        case '/': 
            if (num2 != 0) result = num1 / num2;
            else {
                fb_write_string("Error: Division by zero!\n", FB_MAKE_COLOR(FB_RED, FB_BLACK));
                return;
            }
            break;
        default:
            fb_write_string("Error: Invalid operator!\n", FB_MAKE_COLOR(FB_RED, FB_BLACK));
            return;
    }
    
    fb_write_string("Result: ", FB_MAKE_COLOR(FB_GREEN, FB_BLACK));
    fb_write_int(result, FB_MAKE_COLOR(FB_WHITE, FB_BLACK));
    fb_write_string("\n", FB_MAKE_COLOR(FB_WHITE, FB_BLACK));
}

void cmd_reboot(void) {
    fb_write_string("Rebooting system...\n", FB_MAKE_COLOR(FB_RED, FB_BLACK));
    // Trigger a triple fault to reboot
    __asm__ volatile ("int $0x00");
}

// Simple shell
void shell(void) {
    char buffer[256];
    
    fb_write_string("Welcome to KernelOS Shell!\n", FB_MAKE_COLOR(FB_LIGHT_GREEN, FB_BLACK));
    fb_write_string("Type 'help' for available commands.\n\n", FB_MAKE_COLOR(FB_CYAN, FB_BLACK));
    
    while (1) {
        fb_write_string("kernel> ", FB_MAKE_COLOR(FB_YELLOW, FB_BLACK));
        readline(buffer, sizeof(buffer));
        
        if (strcmp(buffer, "help") == 0) {
            cmd_help();
        } else if (strcmp(buffer, "clear") == 0) {
            cmd_clear();
        } else if (strcmp(buffer, "echo") == 0) {
            cmd_echo();
        } else if (strcmp(buffer, "calc") == 0) {
            cmd_calc();
        } else if (strcmp(buffer, "reboot") == 0) {
            cmd_reboot();
        } else if (strlen(buffer) > 0) {
            fb_write_string("Unknown command: ", FB_MAKE_COLOR(FB_RED, FB_BLACK));
            fb_write_string(buffer, FB_MAKE_COLOR(FB_WHITE, FB_BLACK));
            fb_write_string("\nType 'help' for available commands.\n", FB_MAKE_COLOR(FB_CYAN, FB_BLACK));
        }
    }
}

// Simplified main kernel function for debugging
void kmain(void) {
    // Initialize framebuffer
    fb_clear();
    
    // Display basic information
    fb_write_string("KernelOS Debug Version\n", FB_MAKE_COLOR(FB_WHITE, FB_BLACK));
    fb_write_string("======================\n", FB_MAKE_COLOR(FB_WHITE, FB_BLACK));
    
    // Test framebuffer first
    fb_write_string("Framebuffer test: Hello World!\n", FB_MAKE_COLOR(FB_GREEN, FB_BLACK));
    
    // Initialize PIC without interrupts first
    fb_write_string("Initializing PIC...", FB_MAKE_COLOR(FB_CYAN, FB_BLACK));
    pic_remap();
    fb_write_string(" OK\n", FB_MAKE_COLOR(FB_GREEN, FB_BLACK));
    
    // Initialize keyboard buffer
    fb_write_string("Initializing keyboard buffer...", FB_MAKE_COLOR(FB_CYAN, FB_BLACK));
    keyboard_init();
    fb_write_string(" OK\n", FB_MAKE_COLOR(FB_GREEN, FB_BLACK));
    
    // Test keyboard polling (no interrupts)
    fb_write_string("\nTesting keyboard polling mode:\n", FB_MAKE_COLOR(FB_YELLOW, FB_BLACK));
    fb_write_string("Press keys - they should appear below:\n", FB_MAKE_COLOR(FB_WHITE, FB_BLACK));
    
    // Simple polling loop - no interrupts
    int char_count = 0;
    while (char_count < 20) {  // Limit to prevent infinite loop
        // Check if keyboard has data
        u8int status = inb(KEYBOARD_STATUS_PORT);
        if (status & 0x01) {  // Data available
            u8int scan_code = inb(KEYBOARD_DATA_PORT);
            
            // Only process key presses (not releases)
            if (!(scan_code & 0x80)) {
                char ascii = scan_code_to_ascii(scan_code, false);
                if (ascii != 0 && ascii != '\b' && ascii != '\t') {
                    fb_write_char(ascii, FB_MAKE_COLOR(FB_WHITE, FB_BLACK));
                    char_count++;
                    
                    if (ascii == '\n') {
                        fb_write_string("Enter detected! Test complete.\n", FB_MAKE_COLOR(FB_GREEN, FB_BLACK));
                        break;
                    }
                }
            }
        }
        
        // Small delay to prevent busy waiting
        for (volatile int i = 0; i < 1000000; i++);
    }
    
    fb_write_string("\nPolling test complete. System will halt.\n", FB_MAKE_COLOR(FB_CYAN, FB_BLACK));
    
    // Halt the system
    while (1) {
        __asm__ volatile ("hlt");
    }
}