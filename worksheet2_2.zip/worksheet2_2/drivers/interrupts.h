#ifndef INTERRUPTS_H
#define INTERRUPTS_H

#include "../types.h"

// IDT entry structure
struct idt_entry {
    u16int base_low;   // Lower 16 bits of handler address
    u16int selector;   // Kernel segment selector
    u8int always0;     // Always 0
    u8int flags;       // Flags (type and attributes)
    u16int base_high;  // Upper 16 bits of handler address
} __attribute__((packed));

// IDT pointer structure
struct idt_ptr {
    u16int limit;      // Size of IDT - 1
    u32int base;       // Address of IDT
} __attribute__((packed));

// Interrupt handler function type
typedef void (*interrupt_handler_t)(void);

// Function declarations
void idt_init(void);
void idt_set_gate(u8int num, u32int base, u16int selector, u8int flags);
void load_idt(struct idt_ptr* idt_ptr);

// External assembly interrupt handlers
extern void isr33(void);  // Keyboard interrupt handler

#endif