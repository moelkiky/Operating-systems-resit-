#include "keyboard.h"
#include "pic.h"
#include "../source/framebuffer.h"

// Global input buffer
static struct input_buffer input_buf;
static bool shift_pressed = false;

// Scan code to ASCII conversion table
static char scan_code_table[128] = {
    0,  27, '1', '2', '3', '4', '5', '6', '7', '8',  // 0-9
    '9', '0', '-', '=', '\b',   // Backspace
    '\t',           // Tab
    'q', 'w', 'e', 'r',     // 16-19
    't', 'y', 'u', 'i', 'o', 'p', '[', ']', '\n',  // Enter key
    0,          // 29   - Control
    'a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l', ';',  // 30-39
    '\'', '`',   0,     // Left shift
    '\\', 'z', 'x', 'c', 'v', 'b', 'n',         // 41-49
    'm', ',', '.', '/',   0,                // Right shift
    '*',
    0,  // Alt
    ' ',    // Space bar
    0,  // Caps lock
    0,  // 59 - F1 key ... >
    0,   0,   0,   0,   0,   0,   0,   0,
    0,  // < ... F10
    0,  // 69 - Num lock
    0,  // Scroll Lock
    0,  // Home key
    0,  // Up Arrow
    0,  // Page Up
    '-',
    0,  // Left Arrow
    0,
    0,  // Right Arrow
    '+',
    0,  // 79 - End key
    0,  // Down Arrow
    0,  // Page Down
    0,  // Insert Key
    0,  // Delete Key
    0,   0,   0,
    0,  // F11 Key
    0,  // F12 Key
    0,  // All other keys are undefined
};

// Shifted characters
static char scan_code_table_shift[128] = {
    0,  27, '!', '@', '#', '$', '%', '^', '&', '*',  // 0-9
    '(', ')', '_', '+', '\b',   // Backspace
    '\t',           // Tab
    'Q', 'W', 'E', 'R',     // 16-19
    'T', 'Y', 'U', 'I', 'O', 'P', '{', '}', '\n',  // Enter key
    0,          // 29   - Control
    'A', 'S', 'D', 'F', 'G', 'H', 'J', 'K', 'L', ':',  // 30-39
    '"', '~',   0,     // Left shift
    '|', 'Z', 'X', 'C', 'V', 'B', 'N',         // 41-49
    'M', '<', '>', '?',   0,                // Right shift
    '*',
    0,  // Alt
    ' ',    // Space bar
    0,  // Caps lock
    0,  // 59 - F1 key ... >
    0,   0,   0,   0,   0,   0,   0,   0,
    0,  // < ... F10
    0,  // 69 - Num lock
    0,  // Scroll Lock
    0,  // Home key
    0,  // Up Arrow
    0,  // Page Up
    '-',
    0,  // Left Arrow
    0,
    0,  // Right Arrow
    '+',
    0,  // 79 - End key
    0,  // Down Arrow
    0,  // Page Down
    0,  // Insert Key
    0,  // Delete Key
    0,   0,   0,
    0,  // F11 Key
    0,  // F12 Key
    0,  // All other keys are undefined
};

// Initialize keyboard system
void keyboard_init(void) {
    input_buf.read_pos = 0;
    input_buf.write_pos = 0;
    input_buf.count = 0;
    shift_pressed = false;
}

// Keyboard interrupt handler
void keyboard_handler(void) {
    u8int scan_code = inb(KEYBOARD_DATA_PORT);
    
    // Debug: Add a simple counter to prevent infinite loops
    static int handler_count = 0;
    handler_count++;
    
    // Check if it's a key release (break code)
    if (scan_code & KEY_RELEASE_MASK) {
        scan_code &= ~KEY_RELEASE_MASK;
        
        // Handle shift key release
        if (scan_code == KEY_LEFT_SHIFT || scan_code == KEY_RIGHT_SHIFT) {
            shift_pressed = false;
        }
        return;
    }
    
    // Handle shift key press
    if (scan_code == KEY_LEFT_SHIFT || scan_code == KEY_RIGHT_SHIFT) {
        shift_pressed = true;
        return;
    }
    
    // Convert scan code to ASCII
    char ascii = scan_code_to_ascii(scan_code, shift_pressed);
    
    if (ascii != 0) {
        // Handle special keys
        if (ascii == '\b') {
            // Backspace - remove character from screen and buffer
            fb_write_char('\b', FB_MAKE_COLOR(FB_WHITE, FB_BLACK));
            return;
        }
        
        // Display character on screen immediately
        fb_write_char(ascii, FB_MAKE_COLOR(FB_WHITE, FB_BLACK));
        
        // Add to input buffer if there's space
        if (input_buf.count < INPUT_BUFFER_SIZE - 1) {
            input_buf.data[input_buf.write_pos] = ascii;
            input_buf.write_pos = (input_buf.write_pos + 1) % INPUT_BUFFER_SIZE;
            input_buf.count++;
        }
    }
    
    // Make sure we read any pending scan codes to prevent retriggering
    while (inb(KEYBOARD_STATUS_PORT) & 0x01) {
        inb(KEYBOARD_DATA_PORT);
    }
}

// Get single character from input buffer
char getc(void) {
    while (input_buf.count == 0) {
        // Wait for input with interrupts enabled
        __asm__ volatile ("sti; hlt; cli");
    }
    
    disable_interrupts();
    char c = input_buf.data[input_buf.read_pos];
    input_buf.read_pos = (input_buf.read_pos + 1) % INPUT_BUFFER_SIZE;
    input_buf.count--;
    enable_interrupts();
    
    return c;
}

// Read a complete line until enter is pressed
void readline(char* buffer, u32int size) {
    u32int pos = 0;
    char c;
    
    while (pos < size - 1) {
        c = getc();
        
        if (c == '\n') {
            buffer[pos] = '\0';
            return;
        }
        
        buffer[pos] = c;
        pos++;
    }
    
    buffer[pos] = '\0';
}

// Convert scan code to ASCII character
char scan_code_to_ascii(u8int scan_code, bool shift) {
    if (scan_code >= 128) {
        return 0;
    }
    
    if (shift) {
        return scan_code_table_shift[scan_code];
    } else {
        return scan_code_table[scan_code];
    }
}