#include "pic.h"

// Remap PIC to avoid conflicts with CPU exceptions
void pic_remap(void) {
    u8int a1, a2;
    
    // Save masks
    a1 = inb(PIC1_DATA);
    a2 = inb(PIC2_DATA);
    
    // Start initialization sequence
    outb(PIC1_COMMAND, 0x11);
    io_wait();
    outb(PIC2_COMMAND, 0x11);
    io_wait();
    
    // Set vector offsets
    outb(PIC1_DATA, 0x20);  // Master PIC: IRQ 0-7 -> INT 0x20-0x27
    io_wait();
    outb(PIC2_DATA, 0x28);  // Slave PIC: IRQ 8-15 -> INT 0x28-0x2F
    io_wait();
    
    // Configure cascade
    outb(PIC1_DATA, 4);     // Tell master PIC slave is at IRQ2
    io_wait();
    outb(PIC2_DATA, 2);     // Tell slave PIC its cascade identity
    io_wait();
    
    // Set mode
    outb(PIC1_DATA, 0x01);
    io_wait();
    outb(PIC2_DATA, 0x01);
    io_wait();
    
    // Restore masks
    outb(PIC1_DATA, a1);
    outb(PIC2_DATA, a2);
}

// Send End of Interrupt signal
void pic_send_eoi(u8int irq) {
    if (irq >= 8) {
        outb(PIC2_COMMAND, PIC_EOI);
    }
    outb(PIC1_COMMAND, PIC_EOI);
}

// Mask an IRQ
void pic_mask_irq(u8int irq) {
    u16int port;
    u8int value;
    
    if (irq < 8) {
        port = PIC1_DATA;
    } else {
        port = PIC2_DATA;
        irq -= 8;
    }
    
    value = inb(port) | (1 << irq);
    outb(port, value);
}

// Unmask an IRQ
void pic_unmask_irq(u8int irq) {
    u16int port;
    u8int value;
    
    if (irq < 8) {
        port = PIC1_DATA;
    } else {
        port = PIC2_DATA;
        irq -= 8;
    }
    
    value = inb(port) & ~(1 << irq);
    outb(port, value);
}