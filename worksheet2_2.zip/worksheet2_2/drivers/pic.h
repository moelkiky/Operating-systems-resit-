#ifndef PIC_H
#define PIC_H

#include "../types.h"

// Function declarations
extern u8int inb(u16int port);
extern void outb(u16int port, u8int data);
extern void io_wait(void);

// PIC functions
void pic_remap(void);
void pic_send_eoi(u8int irq);
void pic_mask_irq(u8int irq);
void pic_unmask_irq(u8int irq);

#endif