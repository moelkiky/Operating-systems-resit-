#ifndef KEYBOARD_H
#define KEYBOARD_H

#include "../types.h"

// Keyboard scan codes
#define KEY_RELEASE_MASK    0x80
#define KEY_BACKSPACE       0x0E
#define KEY_ENTER           0x1C
#define KEY_LEFT_SHIFT      0x2A
#define KEY_RIGHT_SHIFT     0x36
#define KEY_LEFT_CTRL       0x1D
#define KEY_LEFT_ALT        0x38

// Input buffer structure
struct input_buffer {
    char data[INPUT_BUFFER_SIZE];
    u32int read_pos;
    u32int write_pos;
    u32int count;
};

// Function declarations
void keyboard_init(void);
void keyboard_handler(void);
char getc(void);
void readline(char* buffer, u32int size);
char scan_code_to_ascii(u8int scan_code, bool shift);

// External interrupt control functions
extern void enable_interrupts(void);
extern void disable_interrupts(void);

#endif