#include "../source/framebuffer.h"

// Framebuffer memory address
#define FB_MEMORY 0x000B8000

// I/O port addresses for cursor control
#define FB_COMMAND_PORT 0x3D4
#define FB_DATA_PORT    0x3D5

// Cursor commands
#define FB_HIGH_BYTE_COMMAND 0x0E
#define FB_LOW_BYTE_COMMAND  0x0F

// Current cursor position
static unsigned short cursor_x = 0;
static unsigned short cursor_y = 0;

// External I/O functions from io.s
extern unsigned char inb(unsigned short port);
extern void outb(unsigned short port, unsigned char val);

// Update hardware cursor position
void fb_update_cursor() {
    unsigned short pos = cursor_y * FB_COLS + cursor_x;
    
    // Send high byte
    outb(FB_COMMAND_PORT, FB_HIGH_BYTE_COMMAND);
    outb(FB_DATA_PORT, (pos >> 8) & 0xFF);
    
    // Send low byte
    outb(FB_COMMAND_PORT, FB_LOW_BYTE_COMMAND);
    outb(FB_DATA_PORT, pos & 0xFF);
}

// Scroll screen up by one line
void fb_scroll() {
    unsigned short *fb = (unsigned short *)FB_MEMORY;
    
    // Move all lines up
    for (int i = 0; i < (FB_ROWS - 1) * FB_COLS; i++) {
        fb[i] = fb[i + FB_COLS];
    }
    
    // Clear bottom line
    for (int i = (FB_ROWS - 1) * FB_COLS; i < FB_ROWS * FB_COLS; i++) {
        fb[i] = 0x0720; // Space character with default color
    }
    
    cursor_y = FB_ROWS - 1;
}

// Move cursor to specified position
void fb_move(unsigned short x, unsigned short y) {
    if (x >= FB_COLS) x = FB_COLS - 1;
    if (y >= FB_ROWS) y = FB_ROWS - 1;
    
    cursor_x = x;
    cursor_y = y;
    fb_update_cursor();
}

// Write single character at current cursor position
void fb_write_char(char c, unsigned char color) {
    unsigned short *fb = (unsigned short *)FB_MEMORY;
    
    if (c == '\b') {
        // Backspace - move cursor back and clear character
        if (cursor_x > 0) {
            cursor_x--;
        } else if (cursor_y > 0) {
            cursor_y--;
            cursor_x = FB_COLS - 1;
        }
        unsigned short pos = cursor_y * FB_COLS + cursor_x;
        fb[pos] = (color << 8) | ' '; // Clear with space
    } else if (c == '\n') {
        cursor_x = 0;
        cursor_y++;
        if (cursor_y >= FB_ROWS) {
            fb_scroll();
        }
    } else if (c == '\r') {
        cursor_x = 0;
    } else if (c == '\t') {
        cursor_x = (cursor_x + 8) & ~7; // Align to 8-character boundary
        if (cursor_x >= FB_COLS) {
            cursor_x = 0;
            cursor_y++;
            if (cursor_y >= FB_ROWS) {
                fb_scroll();
            }
        }
    } else {
        unsigned short pos = cursor_y * FB_COLS + cursor_x;
        fb[pos] = (color << 8) | c;
        
        cursor_x++;
        if (cursor_x >= FB_COLS) {
            cursor_x = 0;
            cursor_y++;
            if (cursor_y >= FB_ROWS) {
                fb_scroll();
            }
        }
    }
    
    fb_update_cursor();
}

// Write string at current cursor position
void fb_write_string(const char* str, unsigned char color) {
    while (*str) {
        fb_write_char(*str, color);
        str++;
    }
}

// Clear entire screen
void fb_clear() {
    unsigned short *fb = (unsigned short *)FB_MEMORY;
    unsigned short blank = 0x0720; // Space with default color (white on black)
    
    for (int i = 0; i < FB_COLS * FB_ROWS; i++) {
        fb[i] = blank;
    }
    
    cursor_x = 0;
    cursor_y = 0;
    fb_update_cursor();
}

// Set default color (not used in current implementation)
void fb_set_color(unsigned char fg, unsigned char bg) {
    // This could be used to set a default color for subsequent writes
    // Currently each write function takes its own color parameter
}

// Write integer as string
void fb_write_int(int num, unsigned char color) {
    char buffer[12]; // Enough for 32-bit integer
    char *ptr = buffer + 11;
    *ptr = '\0';
    
    int is_negative = 0;
    if (num < 0) {
        is_negative = 1;
        num = -num;
    }
    
    if (num == 0) {
        *(--ptr) = '0';
    } else {
        while (num > 0) {
            *(--ptr) = '0' + (num % 10);
            num /= 10;
        }
    }
    
    if (is_negative) {
        *(--ptr) = '-';
    }
    
    fb_write_string(ptr, color);
}