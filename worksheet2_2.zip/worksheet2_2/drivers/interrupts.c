#include "interrupts.h"

// IDT array
static struct idt_entry idt_entries[IDT_SIZE];
static struct idt_ptr idt_ptr;

// Initialize the IDT
void idt_init(void) {
    idt_ptr.limit = sizeof(struct idt_entry) * IDT_SIZE - 1;
    idt_ptr.base = (u32int)&idt_entries;
    
    // Clear the IDT
    for (int i = 0; i < IDT_SIZE; i++) {
        idt_entries[i].base_low = 0;
        idt_entries[i].base_high = 0;
        idt_entries[i].selector = 0;
        idt_entries[i].always0 = 0;
        idt_entries[i].flags = 0;
    }
    
    // Set up keyboard interrupt (IRQ1 -> INT 33)
    idt_set_gate(33, (u32int)isr33, KERNEL_CODE_SEGMENT, INTERRUPT_GATE);
    
    // Load the IDT
    load_idt(&idt_ptr);
}

// Set an IDT gate
void idt_set_gate(u8int num, u32int base, u16int selector, u8int flags) {
    idt_entries[num].base_low = base & 0xFFFF;
    idt_entries[num].base_high = (base >> 16) & 0xFFFF;
    idt_entries[num].selector = selector;
    idt_entries[num].always0 = 0;
    idt_entries[num].flags = flags;
}