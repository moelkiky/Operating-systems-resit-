#!/bin/bash

echo "Testing Worksheet2_2 Kernel..."
echo "================================"

# Check if kernel exists
if [ ! -f "kernel.elf" ]; then
    echo "❌ kernel.elf not found! Run 'make' first."
    exit 1
fi

echo "✅ kernel.elf found ($(stat -c%s kernel.elf) bytes)"

# Check if QEMU is available
if ! command -v qemu-system-i386 &> /dev/null; then
    echo "❌ qemu-system-i386 not found! Install QEMU first."
    exit 1
fi

echo "✅ QEMU found"

echo ""
echo "Starting kernel test..."
echo "Expected behavior:"
echo "1. Kernel boots with initialization messages"
echo "2. Keyboard input test appears"
echo "3. Interactive shell starts"
echo "4. You can type and see characters immediately"
echo "5. Commands like 'help', 'calc', 'echo' work"
echo ""
echo "Press any key to start the test..."
read -n 1

echo "Launching kernel..."
qemu-system-i386 -kernel kernel.elf