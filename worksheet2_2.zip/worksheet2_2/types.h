#ifndef TYPES_H
#define TYPES_H

// Standard integer types
typedef unsigned char  u8int;
typedef unsigned short u16int;
typedef unsigned int   u32int;
typedef signed char    s8int;
typedef signed short   s16int;
typedef signed int     s32int;

// Boolean type
typedef u8int bool;
#define true  1
#define false 0

// NULL definition
#ifndef NULL
#define NULL ((void*)0)
#endif

// Keyboard constants
#define KEYBOARD_DATA_PORT    0x60
#define KEYBOARD_STATUS_PORT  0x64
#define IDT_SIZE             256
#define INTERRUPT_GATE       0x8E
#define KERNEL_CODE_SEGMENT  0x08

// PIC constants
#define PIC1_COMMAND 0x20
#define PIC1_DATA    0x21
#define PIC2_COMMAND 0xA0
#define PIC2_DATA    0xA1
#define PIC_EOI      0x20

// Buffer constants
#define INPUT_BUFFER_SIZE    256

#endif