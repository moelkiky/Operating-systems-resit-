# Worksheet 2: Tiny OS Development - Complete Technical Guide

## Table of Contents
1. [Project Overview](#project-overview)
2. [System Architecture](#system-architecture)
3. [Development Environment](#development-environment)
4. [Build System](#build-system)
5. [Source Code Analysis](#source-code-analysis)
6. [Testing & Debugging](#testing--debugging)
7. [Hardware Interface](#hardware-interface)
8. [Memory Management](#memory-management)
9. [Troubleshooting](#troubleshooting)
10. [Advanced Topics](#advanced-topics)

---

## Project Overview

### What We Built
A minimal operating system kernel from scratch that demonstrates:
- **Boot Process**: GRUB multiboot compliance and system initialization
- **Assembly-C Integration**: Seamless calling between assembly and C code
- **Hardware Programming**: Direct VGA framebuffer and I/O port control
- **System Architecture**: Memory layout, linking, and executable format

### Task Breakdown
- **Task 1**: Basic bootable kernel writing 0xCAFEBABE to EAX register
- **Task 2**: Enhanced kernel calling C functions from assembly
- **Task 3**: Complete framebuffer driver with 2D text API
- **Task 4**: Comprehensive documentation and build system

### Learning Objectives
- Understand low-level system boot process
- Master assembly-C calling conventions
- Implement memory-mapped I/O and hardware interfaces
- Design modular kernel architecture

---

## System Architecture

### Memory Layout
```
Physical Memory Map:
0x00000000 - 0x000FFFFF  Lower Memory (BIOS, Real Mode)
0x00100000 - 0x0010XXXX  Kernel Code (.text sections)
0x00101000 - 0x0010XXXX  Kernel Data (.rodata)
0x00102000 - 0x00106004  Kernel Stack (16KB in .bss)
0x000B8000 - 0x000B8FA0  VGA Text Buffer (4000 bytes)

Virtual Memory (Identity Mapped):
- No paging enabled (1:1 physical mapping)
- Kernel runs in protected mode (32-bit)
- Stack grows downward from 0x00106004
```

### Boot Sequence
1. **BIOS/UEFI** → Loads GRUB from boot device
2. **GRUB Stage 1** → Loads GRUB Stage 2 
3. **GRUB Stage 2** → Reads `menu.lst`, loads `kernel.elf`
4. **Multiboot** → Verifies kernel header, switches to protected mode
5. **Kernel Entry** → `loader` symbol, sets up stack, calls `kmain()`
6. **C Runtime** → Executes kernel logic with full C environment

### File Structure
```
worksheet2/
├── source/           # Core kernel components
│   ├── loader.asm   # Assembly entry point & C interface
│   ├── kernel.c     # Main kernel logic & test functions
│   ├── link.ld      # Memory layout linker script
│   └── framebuffer.h # Framebuffer API definitions
├── drivers/          # Hardware drivers
│   └── framebuffer.c # VGA text mode driver
├── iso/              # Bootable image structure
│   └── boot/
│       ├── kernel.elf    # Final kernel binary
│       └── grub/menu.lst # Boot configuration
├── Makefile         # Build automation
└── *.md            # Documentation files
```

---

## Development Environment

### Required Tools
```bash
# Essential build tools
sudo apt-get install -y \
    nasm \           # Netwide Assembler for x86
    gcc-multilib \   # 32-bit compilation support
    build-essential  # Make, LD, etc.

# Testing & debugging tools  
sudo apt-get install -y \
    qemu-system-x86 \    # System emulator
    gdb-multiarch \      # Cross-architecture debugger
    hexdump \           # Binary analysis
    objdump \           # ELF analysis
    
# ISO creation (optional)
sudo apt-get install -y \
    genisoimage \       # ISO creation
    grub-legacy         # GRUB stage2_eltorito
```

### Development Workflow
1. **Edit Source** → Modify .asm/.c files
2. **Build** → `make clean && make all`
3. **Test** → `make run-kernel` or `make test`
4. **Debug** → Analyze with objdump/hexdump
5. **Iterate** → Repeat until functionality complete

### Code Standards
- **Assembly**: NASM syntax, 4-byte alignment, proper labels
- **C Code**: Freestanding environment, no standard library
- **Comments**: Extensive inline documentation
- **Naming**: Descriptive function/variable names

---

## Build System

### Makefile Targets Overview
```bash
# Primary build targets
make all              # Build kernel.elf (default)
make clean            # Remove all build artifacts
make help             # Show all available targets

# Testing targets  
make run-kernel       # Test kernel directly (recommended)
make run-kernel-curses # Visual framebuffer testing
make run-simple       # Test Task 1 only
make test             # Automated Task 1 verification
make test-kernel      # Full kernel functionality test

# Advanced targets
make iso              # Create bootable ISO (needs dependencies)
make install-deps     # Install required packages (needs sudo)
make setup            # Create directory structure
```

### Build Process Detailed

#### 1. Assembly Compilation
```bash
nasm -f elf source/loader.asm -o source/loader.o
```
- **Input**: `loader.asm` (Assembly source)
- **Output**: `loader.o` (ELF object file)
- **Format**: 32-bit ELF for i386 architecture
- **Contains**: Multiboot header, stack setup, C calling code

#### 2. C Compilation
```bash
gcc -m32 -c -ffreestanding -fno-stack-protector -Wall-Wextra \
    source/kernel.c -o source/kernel.o
    
gcc -m32 -c -ffreestanding -fno-stack-protector -Wall -Wextra \
    drivers/framebuffer.c -o drivers/framebuffer.o
```
- **Flags Explained**:
  - `-m32`: Generate 32-bit code
  - `-c`: Compile only (no linking)
  - `-ffreestanding`: No standard library
  - `-fno-stack-protector`: Disable stack canaries (no runtime support)
  - `-Wall -Wextra`: Enable all warnings

#### 3. Linking
```bash
ld -T ./source/link.ld -melf_i386 \
   source/loader.o source/kernel.o drivers/framebuffer.o \
   -o kernel.elf
```
- **Linker Script**: `link.ld` defines memory layout
- **Output**: `kernel.elf` bootable executable
- **Entry Point**: `loader` symbol from assembly
- **Load Address**: 0x00100000 (1MB)

#### 4. ISO Creation (Optional)
```bash
cp kernel.elf iso/boot/
genisoimage -R -b boot/grub/stage2_eltorito -no-emul-boot \
    -boot-load-size 4 -A os -input-charset utf8 -quiet \
    -boot-info-table -o os.iso iso/
```

### Build Dependencies
```
loader.o ← loader.asm
kernel.o ← kernel.c + framebuffer.h  
framebuffer.o ← framebuffer.c + framebuffer.h
kernel.elf ← loader.o + kernel.o + framebuffer.o + link.ld
os.iso ← kernel.elf + menu.lst + stage2_eltorito
```

### Build Verification
```bash
# Check file types
file kernel.elf kernel-simple.elf
# Expected: ELF 32-bit LSB executable, Intel 80386

# Check sections
objdump -h kernel.elf
# Expected: .text, .rodata, .bss sections

# Check symbols
objdump -t kernel.elf | grep -E "(loader|kmain|fb_)"
# Expected: All function symbols present

# Check machine code
objdump -d kernel.elf | head -50
# Expected: Assembly instructions visible
```

---

## Source Code Analysis

### Task 1: Basic Kernel (`loader-simple.asm`)
```assembly
global loader                    ; Entry symbol for ELF
MAGIC_NUMBER equ 0x1BADB002     ; Multiboot magic
FLAGS equ 0x0                   ; No special flags
CHECKSUM equ -MAGIC_NUMBER      ; Must sum to zero

section .text:                  ; Code section
    align 4                     ; 4-byte boundary
    dd MAGIC_NUMBER             ; Multiboot header
    dd FLAGS                    
    dd CHECKSUM                 

loader:                         ; Entry point
    mov eax, 0xCAFEBABE        ; ← Task requirement
.loop:
    jmp .loop                   ; Infinite halt
```

**Key Concepts**:
- **Multiboot Header**: Required for GRUB to recognize kernel
- **Magic Number**: 0x1BADB002 identifies multiboot kernel
- **Checksum**: Ensures header integrity
- **Entry Point**: `loader` label where execution begins
- **Target Instruction**: `mov eax, 0xCAFEBABE` fulfills Task 1

### Task 2: C Integration (`loader.asm`)
```assembly
global loader                    ; Entry symbol
extern kmain                     ; C function declaration

; Multiboot header (same as Task 1)
MAGIC_NUMBER equ 0x1BADB002
FLAGS equ 0x0
CHECKSUM equ -MAGIC_NUMBER

section .text:
    align 4
    dd MAGIC_NUMBER
    dd FLAGS
    dd CHECKSUM

loader:                         ; Enhanced entry point
    ; Critical: Set up C runtime stack
    mov esp, kernel_stack + KERNEL_STACK_SIZE
    
    ; Call C main function
    call kmain                  ; ← Transfer to C code
    
    ; If C returns, halt system
.loop:
    jmp .loop

section .bss                    ; Uninitialized data
    align 4
    kernel_stack_bottom:
    resb 16384                  ; 16KB stack space
    kernel_stack:               ; Stack top label

KERNEL_STACK_SIZE equ $ - kernel_stack_bottom
```

**Critical Details**:
- **Stack Setup**: ESP points to stack top before C call
- **Calling Convention**: Standard cdecl (parameters on stack)
- **Stack Size**: 16KB adequate for kernel operations
- **BSS Section**: Uninitialized memory for stack allocation
- **Return Handling**: Infinite loop if C function returns

### Task 2: C Functions (`kernel.c`)
```c
#include "framebuffer.h"

// Required function: sum of three integers
int sum_of_three(int a, int b, int c) {
    return a + b + c;
}

// Additional function 1: factorial calculation
int factorial(int n) {
    if (n <= 1) return 1;
    int result = 1;
    for (int i = 2; i <= n; i++) {
        result *= i;
    }
    return result;
}

// Additional function 2: Fibonacci sequence
int fibonacci(int n) {
    if (n <= 1) return n;
    int a = 0, b = 1, c;
    for (int i = 2; i <= n; i++) {
        c = a + b;
        a = b;
        b = c;
    }
    return b;
}

// Main kernel function called from assembly
void kmain() {
    // Initialize display
    fb_clear();
    
    // Test required function
    int sum = sum_of_three(5, 10, 15);
    fb_write_string("sum_of_three(5,10,15) = ", FB_MAKE_COLOR(FB_CYAN, FB_BLACK));
    fb_write_int(sum, FB_MAKE_COLOR(FB_YELLOW, FB_BLACK));
    
    // Test additional functions
    int fact = factorial(5);
    int fib = fibonacci(8);
    
    // Display results with colored output
    fb_write_string("\nfactorial(5) = ", FB_MAKE_COLOR(FB_GREEN, FB_BLACK));
    fb_write_int(fact, FB_MAKE_COLOR(FB_YELLOW, FB_BLACK));
    
    fb_write_string("\nfibonacci(8) = ", FB_MAKE_COLOR(FB_MAGENTA, FB_BLACK));
    fb_write_int(fib, FB_MAKE_COLOR(FB_YELLOW, FB_BLACK));
    
    // Demonstrate framebuffer capabilities
    fb_move(10, 10);  // Cursor positioning
    fb_write_string("Hello from (10,10)!", FB_MAKE_COLOR(FB_WHITE, FB_RED));
}
```

**Function Analysis**:
- **sum_of_three()**: Direct integer arithmetic, validates C calling
- **factorial()**: Iterative approach (recursive would use more stack)
- **fibonacci()**: Efficient O(n) algorithm, demonstrates loops
- **kmain()**: Integration point showing all functionality

### Task 3: Framebuffer Driver (`framebuffer.c`)

#### Memory-Mapped I/O
```c
#define FB_MEMORY 0x000B8000    // VGA text buffer address

// Character cell structure (implicit):
// Byte 0: ASCII character code
// Byte 1: Attribute (4-bit bg + 4-bit fg)

void fb_write_char(char c, unsigned char color) {
    unsigned short *fb = (unsigned short *)FB_MEMORY;
    unsigned short pos = cursor_y * FB_COLS + cursor_x;
    
    // Combine character and color into 16-bit value
    fb[pos] = (color << 8) | c;
    
    // Update cursor position
    cursor_x++;
    if (cursor_x >= FB_COLS) {
        cursor_x = 0;
        cursor_y++;
        if (cursor_y >= FB_ROWS) {
            fb_scroll();  // Handle screen overflow
        }
    }
    
    fb_update_cursor();  // Sync hardware cursor
}
```

#### I/O Port Control
```c
#define FB_COMMAND_PORT 0x3D4   // VGA controller command
#define FB_DATA_PORT    0x3D5   // VGA controller data

// Inline assembly for port I/O
void outb(unsigned short port, unsigned char val) {
    asm volatile ("outb %0, %1" : : "a"(val), "Nd"(port));
}

unsigned char inb(unsigned short port) {
    unsigned char ret;
    asm volatile ("inb %1, %0" : "=a"(ret) : "Nd"(port));
    return ret;
}

// Hardware cursor positioning
void fb_update_cursor() {
    unsigned short pos = cursor_y * FB_COLS + cursor_x;
    
    // Send cursor position to VGA controller
    outb(FB_COMMAND_PORT, 0x0E);        // High byte command
    outb(FB_DATA_PORT, (pos >> 8) & 0xFF);
    outb(FB_COMMAND_PORT, 0x0F);        // Low byte command  
    outb(FB_DATA_PORT, pos & 0xFF);
}
```

#### Advanced Features
```c
// Automatic screen scrolling
void fb_scroll() {
    unsigned short *fb = (unsigned short *)FB_MEMORY;
    
    // Move all lines up one position
    for (int i = 0; i < (FB_ROWS - 1) * FB_COLS; i++) {
        fb[i] = fb[i + FB_COLS];
    }
    
    // Clear bottom line
    for (int i = (FB_ROWS - 1) * FB_COLS; i < FB_ROWS * FB_COLS; i++) {
        fb[i] = 0x0720;  // Space with default color
    }
    
    cursor_y = FB_ROWS - 1;  // Position cursor on last line
}

// Integer to string conversion (no stdlib)
void fb_write_int(int num, unsigned char color) {
    char buffer[12];  // Max 32-bit integer digits
    char *ptr = buffer + 11;
    *ptr = '\0';
    
    // Handle negative numbers
    int is_negative = (num < 0);
    if (is_negative) num = -num;
    
    // Extract digits in reverse order
    if (num == 0) {
        *(--ptr) = '0';
    } else {
        while (num > 0) {
            *(--ptr) = '0' + (num % 10);
            num /= 10;
        }
    }
    
    if (is_negative) *(--ptr) = '-';
    
    fb_write_string(ptr, color);
}
```

### Memory Layout (`link.ld`)
```ld
ENTRY(loader)                   # Entry point symbol

SECTIONS {
    . = 0x00100000;            # Load address (1MB)
    
    .text ALIGN (0x1000) : {   # Code section (4KB aligned)
        *(.text)               # C code
    }
    
    .rodata ALIGN (0x1000) : { # Read-only data
        *(.rodata*)            # String constants
    }
    
    .data ALIGN (0x1000) : {   # Initialized data
        *(.data)
    }
    
    .bss ALIGN (0x1000) : {    # Uninitialized data
        *(COMMON)
        *(.bss)                # Stack space
    }
}
```

**Linker Script Analysis**:
- **Entry Point**: `loader` symbol from assembly
- **Load Address**: 1MB (standard for kernels)
- **Section Alignment**: 4KB pages for memory management
- **Section Order**: Code → Constants → Data → BSS

---

## Testing & Debugging

### Basic Functionality Tests

#### Task 1 Verification
```bash
# Build and test simple kernel
make run-simple

# Verify 0xCAFEBABE in binary
objdump -s -j .text: kernel-simple.elf
# Look for: b8bebafeca (mov eax, 0xCAFEBABE)

# Automated test
make test
# Searches CPU logs for CAFEBABE pattern
```

#### Task 2 & 3 Testing
```bash
# Test full kernel
make run-kernel

# Visual testing (if available)
make run-kernel-curses

# Check kernel execution
make test-kernel
```

### Binary Analysis

#### ELF Structure Analysis
```bash
# Check file format
file kernel.elf
# Expected: ELF 32-bit LSB executable, Intel 80386

# Examine sections
objdump -h kernel.elf
# Key sections:
# .text     - C code functions
# .rodata   - String constants
# .text:    - Assembly loader
# .bss      - Stack space

# Symbol table
objdump -t kernel.elf | grep -E "(loader|kmain|fb_|sum_)"
# Verify all functions present

# Disassembly
objdump -d kernel.elf > kernel_disasm.txt
# Full machine code analysis
```

#### Machine Code Verification
```bash
# Task 1: Check for 0xCAFEBABE instruction
objdump -s -j .text: kernel-simple.elf
# Should show: b8bebafeca (little-endian)

# Task 2: Verify C function calls
objdump -d kernel.elf | grep -A10 -B10 "call.*kmain"
# Shows assembly calling C code

# Task 3: Check framebuffer functions
objdump -d kernel.elf | grep -A5 "fb_write"
# Verify framebuffer API compiled
```

### Runtime Debugging with QEMU

#### CPU State Monitoring
```bash
# Run with CPU debugging
qemu-system-i386 -nographic -kernel kernel.elf -m 32 \
    -d cpu,int -D debug.log

# Monitor execution
tail -f debug.log
# Shows CPU registers, instruction execution

# Check for Task 1 completion
grep -i "EAX=cafebabe" debug.log
# Confirms 0xCAFEBABE written to EAX
```

#### Memory Analysis
```bash
# Dump memory regions
qemu-system-i386 -monitor stdio -kernel kernel.elf -m 32
# In QEMU monitor:
info registers          # Show all CPU registers
x/20i 0x100000          # Disassemble at load address
x/100wx 0xb8000         # Examine VGA framebuffer
x/20wx 0x102000         # Check stack area
```

#### Interactive Debugging
```bash
# GDB debugging (advanced)
qemu-system-i386 -s -S -kernel kernel.elf -m 32 &
gdb-multiarch kernel.elf
(gdb) target remote localhost:1234
(gdb) break loader
(gdb) continue
(gdb) stepi              # Step through instructions
(gdb) info registers     # Check register values
(gdb) x/i $eip          # Examine current instruction
```

### Common Test Scenarios

#### Boot Process Verification
```bash
# Test multiboot compliance
qemu-system-i386 -kernel kernel.elf -m 32 -d guest_errors
# Should boot without multiboot errors

# Test with GRUB (if ISO created)
qemu-system-i386 -cdrom os.iso -m 32
# Full boot sequence testing
```

#### Framebuffer Testing
```bash
# Visual output test
qemu-system-i386 -curses -kernel kernel.elf -m 32
# Should show colored text output

# Memory-mapped I/O test
qemu-system-i386 -monitor stdio -kernel kernel.elf -m 32
# In monitor: x/100c 0xb8000
# Shows framebuffer contents
```

#### Function Call Testing
```bash
# Verify C functions execute
qemu-system-i386 -d exec -kernel kernel.elf -m 32 -D exec.log
grep -E "(sum_of_three|factorial|fibonacci)" exec.log
# Should show function calls

# Stack usage analysis
qemu-system-i386 -d cpu -kernel kernel.elf -m 32 -D cpu.log
grep "ESP=" cpu.log | head -20
# Monitor stack pointer changes
```

### Error Diagnosis

#### Common Build Errors
```bash
# Multilib not installed
gcc: error: unrecognized command line option '-m32'
# Solution: sudo apt-get install gcc-multilib

# NASM not found  
make: nasm: command not found
# Solution: sudo apt-get install nasm

# Linker errors
ld: cannot find entry symbol loader
# Check: objdump -t source/loader.o | grep loader
# Verify: global loader in assembly
```

#### Runtime Errors
```bash
# Kernel doesn't boot
qemu-system-i386 -kernel kernel.elf -d guest_errors
# Check multiboot header alignment

# No output visible
# Check: VGA buffer at 0xB8000
# Verify: fb_clear() called first

# Crashes/triple fault
qemu-system-i386 -kernel kernel.elf -d int,cpu
# Monitor for exceptions, stack issues
```

---

## Hardware Interface

### VGA Text Mode Details

#### Memory Layout
```
VGA Text Buffer: 0x000B8000 - 0x000B8F9F (4000 bytes)
Layout: 80 columns × 25 rows × 2 bytes/cell = 4000 bytes

Each cell: [Character Byte][Attribute Byte]
Character: ASCII code (0x00-0xFF)
Attribute: [Background 4-bits][Foreground 4-bits]
```

#### Color Encoding
```c
// Standard VGA colors (0-15)
#define FB_BLACK        0    // 0000
#define FB_BLUE         1    // 0001  
#define FB_GREEN        2    // 0010
#define FB_CYAN         3    // 0011
#define FB_RED          4    // 0100
#define FB_MAGENTA      5    // 0101
#define FB_BROWN        6    // 0110
#define FB_LIGHT_GREY   7    // 0111
#define FB_DARK_GREY    8    // 1000
#define FB_LIGHT_BLUE   9    // 1001
#define FB_LIGHT_GREEN 10    // 1010
#define FB_LIGHT_CYAN  11    // 1011
#define FB_LIGHT_RED   12    // 1100
#define FB_LIGHT_MAGENTA 13  // 1101
#define FB_LIGHT_BROWN 14    // 1110 (Yellow)
#define FB_WHITE       15    // 1111

// Attribute byte construction
FB_MAKE_COLOR(fg, bg) = (bg << 4) | (fg & 0x0F)
// Example: White on blue = (1 << 4) | (15 & 0x0F) = 0x1F
```

#### Character Positioning
```c
// Linear address calculation
position = row * 80 + column
memory_address = 0xB8000 + (position * 2)

// Example: Position (10, 5) = row 5, column 10
position = 5 * 80 + 10 = 410
address = 0xB8000 + (410 * 2) = 0xB8334
```

### I/O Port Interface

#### VGA Controller Ports
```c
// Port addresses
#define VGA_CRTC_INDEX  0x3D4    // CRT Controller Index
#define VGA_CRTC_DATA   0x3D5    // CRT Controller Data

// Cursor control registers
#define CURSOR_HIGH     0x0E     // Cursor Location High
#define CURSOR_LOW      0x0F     // Cursor Location Low

// Usage example
void set_cursor(unsigned short position) {
    outb(VGA_CRTC_INDEX, CURSOR_HIGH);
    outb(VGA_CRTC_DATA, (position >> 8) & 0xFF);
    outb(VGA_CRTC_INDEX, CURSOR_LOW); 
    outb(VGA_CRTC_DATA, position & 0xFF);
}
```

#### I/O Instructions
```assembly
; Output byte to port
; outb(port, value)
mov dx, port_number     ; Port in DX
mov al, value           ; Value in AL
out dx, al              ; Output AL to DX

; Input byte from port  
; value = inb(port)
mov dx, port_number     ; Port in DX
in al, dx               ; Input from DX to AL
```

### Hardware Constraints

#### Memory Access Patterns
- **Byte Access**: Individual character/attribute modification
- **Word Access**: Efficient character+attribute updates
- **Burst Writes**: Fast screen clearing/scrolling

#### Timing Considerations
- **VGA Refresh**: ~70Hz, avoid tearing during updates
- **I/O Latency**: Port operations slower than memory
- **CPU Cache**: Memory-mapped I/O may bypass cache

#### Hardware Compatibility
- **VGA Standard**: Compatible with all PC systems
- **Resolution**: Fixed 80×25 text mode
- **Colors**: Standard 16-color palette
- **Fonts**: Built-in VGA character set

---

## Memory Management

### Physical Memory Layout
```
0x00000000 - 0x0009FFFF  Conventional Memory (640KB)
0x000A0000 - 0x000BFFFF  VGA Memory (128KB)
0x000B8000 - 0x000B8F9F  VGA Text Buffer (4KB)
0x000C0000 - 0x000FFFFF  BIOS ROM/Extensions (256KB)
0x00100000 - 0x001FFFFF  Extended Memory (Kernel Space)
```

### Kernel Memory Sections

#### Code Section (.text)
```
Base Address: 0x00100000 (1MB)
Size: ~1934 bytes (varies with compilation)
Content: Compiled C functions, optimized code
Permissions: Read + Execute
Alignment: 4KB pages
```

#### Read-Only Data (.rodata)  
```
Base Address: 0x00101000  
Size: ~288 bytes
Content: String literals, constants
Permissions: Read only
Examples: "Testing C Functions:\n", "factorial(5) = "
```

#### Assembly Section (.text:)
```
Base Address: 0x00101120
Size: 24 bytes  
Content: Multiboot header, loader code
Permissions: Read + Execute  
Critical: Entry point and stack setup
```

#### BSS Section (.bss)
```
Base Address: 0x00102000
Size: 16388 bytes (16KB + 4 bytes)
Content: Stack space, uninitialized variables
Permissions: Read + Write
Layout: [16KB Stack][4 bytes alignment]
```

### Stack Management

#### Stack Layout
```
High Address: 0x00106004 (Stack Top)
     │
     ├── [Function Parameters]
     ├── [Return Addresses]  
     ├── [Local Variables]
     ├── [Saved Registers]
     │
     ▼ (Stack grows down)
Low Address:  0x00102000 (Stack Bottom)
```

#### Calling Convention (cdecl)
```c
// Function call: sum_of_three(5, 10, 15)
// Stack before call:
[ESP+8]  15        (parameter 3)
[ESP+4]  10        (parameter 2) 
[ESP+0]  5         (parameter 1)

// After call instruction:
[ESP+12] 15        (parameter 3)
[ESP+8]  10        (parameter 2)
[ESP+4]  5         (parameter 1)
[ESP+0]  Return Address

// Function prologue:
push ebp           ; Save old frame pointer
mov ebp, esp       ; Set new frame pointer
sub esp, 16        ; Allocate local variables

// Access parameters:
mov eax, [ebp+8]   ; First parameter (a)
mov ebx, [ebp+12]  ; Second parameter (b)  
mov ecx, [ebp+16]  ; Third parameter (c)
```

#### Stack Overflow Prevention
```c
// Stack size: 16KB = 16384 bytes
// Typical usage per function call: ~32 bytes
// Maximum safe recursion depth: ~500 calls
// Our kernel: Non-recursive, safe usage

// Stack pointer monitoring (debug)
void check_stack_usage() {
    unsigned int current_esp;
    asm volatile ("mov %%esp, %0" : "=r" (current_esp));
    unsigned int stack_used = 0x00106004 - current_esp;
    // Log stack usage for debugging
}
```

### Memory-Mapped I/O

#### VGA Buffer Management
```c
// Direct memory access
volatile unsigned short *vga_buffer = (volatile unsigned short *)0xB8000;

// Efficient character placement
vga_buffer[row * 80 + col] = (color << 8) | character;

// Memory barriers (if needed)
asm volatile ("" ::: "memory");  // Compiler barrier
```

#### DMA Considerations
- **No DMA**: Simple PIO (Programmed I/O) only
- **Cache Coherency**: VGA memory typically uncached
- **Memory Ordering**: Sequential access sufficient

### Memory Debugging

#### Address Space Verification
```bash
# Check section addresses
objdump -h kernel.elf
# Verify no overlapping sections

# Memory map validation  
objdump -t kernel.elf | sort
# Check symbol addresses

# Stack bounds checking
gdb-multiarch kernel.elf
(gdb) info registers esp
(gdb) x/20wx $esp
# Verify stack in valid range
```

#### Memory Access Patterns
```bash
# Monitor memory writes
qemu-system-i386 -kernel kernel.elf -d mmu,cpu
# Shows memory access patterns

# VGA buffer monitoring
qemu-monitor> x/100c 0xb8000
# View framebuffer contents

# Stack usage tracking
qemu-monitor> x/50wx 0x102000
# Examine stack contents
```

---

## Troubleshooting

### Build Issues

#### Missing Dependencies
```bash
# Symptom: gcc: command not found
sudo apt-get update
sudo apt-get install build-essential

# Symptom: nasm: command not found  
sudo apt-get install nasm

# Symptom: 32-bit compilation fails
sudo apt-get install gcc-multilib libc6-dev-i386
```

#### Compilation Errors
```bash
# Undefined reference to 'kmain'
# Check: extern kmain in loader.asm
# Check: kmain defined in kernel.c
objdump -t source/kernel.o | grep kmain

# Linker can't find entry point
# Check: global loader in loader.asm
# Check: ENTRY(loader) in link.ld
objdump -t source/loader.o | grep loader

# Section alignment issues
# Verify: align 4 in assembly
# Verify: ALIGN(0x1000) in linker script
```

#### Warning Resolution
```bash
# Warning: unused parameter in fb_set_color
# Add: (void)parameter; to suppress
# Or: __attribute__((unused)) parameter

# Warning: missing .note.GNU-stack section
# Add to assembly: section .note.GNU-stack noalloc noexec nowrite progbits

# Warning: deprecated linker behavior
# Update: Use newer GCC/binutils versions
```

### Runtime Issues

#### Boot Failures
```bash
# Multiboot magic mismatch
hexdump -C kernel.elf | grep "02b0ad1b"
# Should show multiboot magic number

# Wrong load address
objdump -h kernel.elf | grep ".text"
# VMA should be 0x00100000

# Entry point issues
objdump -f kernel.elf | grep "start address"
# Should match loader symbol address
```

#### Execution Problems
```bash
# Triple fault (CPU reset)
qemu-system-i386 -kernel kernel.elf -d int
# Check for exceptions before crash

# Stack overflow
qemu-system-i386 -kernel kernel.elf -d cpu | grep ESP
# Monitor stack pointer changes

# Infinite loop detection
timeout 5 qemu-system-i386 -kernel kernel.elf
# Should terminate after 5 seconds
```

#### Display Issues
```bash
# No output visible
# Check: fb_clear() called first
# Check: VGA buffer address 0xB8000
qemu-monitor> x/100c 0xb8000

# Wrong colors/characters
# Check: FB_MAKE_COLOR macro
# Check: character encoding
# Verify: attribute byte format

# Cursor not updating  
# Check: fb_update_cursor() calls
# Check: I/O port operations
# Verify: port addresses 0x3D4/0x3D5
```

### Debugging Strategies

#### Systematic Approach
1. **Build Verification**: Ensure clean compilation
2. **Binary Analysis**: Check ELF structure/symbols
3. **Boot Testing**: Verify multiboot compliance
4. **Function Testing**: Test individual components
5. **Integration Testing**: Test complete system

#### Debug Output Methods
```c
// Method 1: Framebuffer debugging
void debug_print(const char *msg) {
    fb_write_string(msg, FB_MAKE_COLOR(FB_RED, FB_BLACK));
    fb_write_string("\n", FB_MAKE_COLOR(FB_WHITE, FB_BLACK));
}

// Method 2: Memory location debugging
void debug_value(int value) {
    volatile int *debug_addr = (volatile int *)0x200000;
    *debug_addr = value;  // Write to unused memory
}

// Method 3: Port debugging
void debug_port(unsigned char value) {
    outb(0x80, value);  // POST code port
}
```

#### QEMU Debug Features
```bash
# CPU state logging
-d cpu,int,exec,guest_errors -D debug.log

# Memory access tracing  
-d mmu,page,trace:memory_*

# Interrupt monitoring
-d int,guest_errors

# Custom debug points
-s -S  # GDB remote debugging
```

### Performance Analysis

#### Code Optimization
```bash
# Check compiler optimizations
gcc -m32 -O2 -ffreestanding kernel.c -S
# Review generated assembly

# Function call overhead
objdump -d kernel.elf | grep -A10 "call"
# Analyze calling patterns

# Memory access efficiency
perf record qemu-system-i386 -kernel kernel.elf
perf report  # If available
```

#### Memory Usage
```bash
# Kernel size analysis
size kernel.elf
# Shows section sizes

# Runtime memory usage
qemu-monitor> info mem
# Memory map information

# Stack usage estimation
objdump -d kernel.elf | grep -E "(push|pop|sub.*esp|add.*esp)"
# Analyze stack operations
```

---

## Advanced Topics

### Kernel Extensions

#### Adding New Drivers
```c
// Driver interface template
typedef struct {
    const char *name;
    int (*init)(void);
    int (*write)(const void *data, size_t len);
    int (*read)(void *data, size_t len);
    void (*cleanup)(void);
} driver_t;

// Example: Serial port driver
static driver_t serial_driver = {
    .name = "serial",
    .init = serial_init,
    .write = serial_write,
    .read = serial_read,
    .cleanup = serial_cleanup
};
```

#### Memory Management Extensions
```c
// Simple heap allocator
#define HEAP_START 0x00200000
#define HEAP_SIZE  0x00100000

static unsigned char heap[HEAP_SIZE];
static size_t heap_offset = 0;

void *kmalloc(size_t size) {
    if (heap_offset + size > HEAP_SIZE) return NULL;
    void *ptr = &heap[heap_offset];
    heap_offset += size;
    return ptr;
}
```

#### Interrupt Handling
```assembly
; Interrupt Descriptor Table entry
global idt_flush
extern idt_ptr

idt_flush:
    lidt [idt_ptr]    ; Load IDT
    sti               ; Enable interrupts
    ret

; Interrupt Service Routine template
isr_common:
    pusha             ; Save all registers
    push ds
    push es
    push fs
    push gs
    
    call isr_handler  ; Call C handler
    
    pop gs
    pop fs
    pop es
    pop ds
    popa              ; Restore registers
    add esp, 8        ; Clean up error/interrupt code
    iret              ; Return from interrupt
```

### Bootloader Integration

#### Custom Bootloader
```assembly
; Simple bootloader (512 bytes)
[BITS 16]
[ORG 0x7C00]

start:
    ; Set up segments
    cli
    xor ax, ax
    mov ds, ax
    mov es, ax
    mov ss, ax
    mov sp, 0x7C00
    sti
    
    ; Load kernel from disk
    mov ah, 0x02      ; Read sectors
    mov al, 10        ; Number of sectors
    mov ch, 0         ; Cylinder
    mov cl, 2         ; Sector (1-based)
    mov dh, 0         ; Head
    mov dl, 0x80      ; Drive
    mov bx, 0x1000    ; Buffer address
    int 0x13          ; BIOS disk interrupt
    
    ; Switch to protected mode
    lgdt [gdt_descriptor]
    mov eax, cr0
    or eax, 1
    mov cr0, eax
    jmp 0x08:protected_mode

[BITS 32]
protected_mode:
    ; Jump to kernel
    jmp 0x10000

; Global Descriptor Table
gdt_start:
    dd 0x0, 0x0       ; Null descriptor
    dd 0x0000FFFF, 0x00CF9A00  ; Code segment
    dd 0x0000FFFF, 0x00CF9200  ; Data segment
gdt_end:

gdt_descriptor:
    dw gdt_end - gdt_start - 1
    dd gdt_start

times 510-($-$$) db 0
dw 0xAA55            ; Boot signature
```

#### UEFI Boot Support
```c
// UEFI boot protocol
#include <efi.h>

EFI_STATUS efi_main(EFI_HANDLE ImageHandle, EFI_SYSTEM_TABLE *SystemTable) {
    EFI_STATUS Status;
    
    // Initialize services
    ST = SystemTable;
    BS = SystemTable->BootServices;
    RT = SystemTable->RuntimeServices;
    
    // Load kernel image
    Status = load_kernel_image();
    if (EFI_ERROR(Status)) return Status;
    
    // Exit boot services
    Status = BS->ExitBootServices(ImageHandle, MapKey);
    if (EFI_ERROR(Status)) return Status;
    
    // Jump to kernel
    kernel_entry_point();
    
    return EFI_SUCCESS;
}
```

### Cross-Platform Considerations

#### Architecture Abstractions
```c
// Platform-specific definitions
#ifdef __i386__
    #define ARCH_BITS 32
    #define PAGE_SIZE 4096
    #define STACK_ALIGN 4
#elif __x86_64__
    #define ARCH_BITS 64
    #define PAGE_SIZE 4096
    #define STACK_ALIGN 8
#elif __arm__
    #define ARCH_BITS 32
    #define PAGE_SIZE 4096
    #define STACK_ALIGN 4
#endif

// Architecture-specific I/O
static inline void arch_outb(uint16_t port, uint8_t value) {
#ifdef __i386__
    asm volatile ("outb %0, %1" : : "a"(value), "Nd"(port));
#else
    // Alternative implementation for other architectures
#endif
}
```

#### Compiler Compatibility
```c
// GCC-specific attributes
#define PACKED __attribute__((packed))
#define ALIGNED(x) __attribute__((aligned(x)))
#define NORETURN __attribute__((noreturn))

// Cross-compiler compatibility
#ifdef __GNUC__
    #define LIKELY(x)   __builtin_expect(!!(x), 1)
    #define UNLIKELY(x) __builtin_expect(!!(x), 0)
#else
    #define LIKELY(x)   (x)
    #define UNLIKELY(x) (x)
#endif
```

### Testing Frameworks

#### Unit Testing
```c
// Simple test framework
#define ASSERT(condition, message) \
    do { \
        if (!(condition)) { \
            fb_write_string("FAIL: " message "\n", FB_MAKE_COLOR(FB_RED, FB_BLACK)); \
            return 0; \
        } \
    } while(0)

#define TEST_PASS() \
    fb_write_string("PASS\n", FB_MAKE_COLOR(FB_GREEN, FB_BLACK))

// Test cases
int test_sum_of_three() {
    ASSERT(sum_of_three(1, 2, 3) == 6, "sum_of_three basic test");
    ASSERT(sum_of_three(0, 0, 0) == 0, "sum_of_three zero test");
    ASSERT(sum_of_three(-1, 1, 0) == 0, "sum_of_three negative test");
    TEST_PASS();
    return 1;
}

int test_factorial() {
    ASSERT(factorial(0) == 1, "factorial(0) should be 1");
    ASSERT(factorial(1) == 1, "factorial(1) should be 1");
    ASSERT(factorial(5) == 120, "factorial(5) should be 120");
    TEST_PASS();
    return 1;
}
```

#### Integration Testing
```bash
#!/bin/bash
# Automated integration test suite

echo "Running Kernel Test Suite..."

# Build tests
make clean && make all || exit 1

# Test 1: Basic boot
timeout 5 qemu-system-i386 -kernel kernel.elf -nographic -serial stdio > boot.log 2>&1 &
QEMU_PID=$!
sleep 2
kill $QEMU_PID 2>/dev/null

if grep -q "Kernel loaded successfully" boot.log; then
    echo "✓ Boot test passed"
else
    echo "✗ Boot test failed"
    exit 1
fi

# Test 2: Function execution
timeout 5 qemu-system-i386 -kernel kernel.elf -nographic -serial stdio > func.log 2>&1 &
QEMU_PID=$!
sleep 2  
kill $QEMU_PID 2>/dev/null

if grep -q "sum_of_three.*30" func.log; then
    echo "✓ Function test passed"
else
    echo "✗ Function test failed"
    exit 1
fi

echo "All tests passed!"
```

### Performance Optimization

#### Code Optimization
```c
// Compiler hints
register int fast_var asm("eax");  // Prefer register
volatile int hw_register;          // Prevent optimization

// Function attributes
static inline void fast_function(void) __attribute__((always_inline));
void slow_function(void) __attribute__((noinline));

// Branch prediction
if (LIKELY(common_condition)) {
    // Frequently executed path
} else {
    // Rarely executed path
}
```

#### Memory Optimization
```c
// Structure packing
typedef struct PACKED {
    uint8_t  type;      // 1 byte
    uint16_t id;        // 2 bytes  
    uint32_t value;     // 4 bytes
} message_t;            // Total: 7 bytes (vs 12 unpacked)

// Memory alignment
typedef struct ALIGNED(16) {
    uint32_t data[4];   // 16-byte aligned
} cache_line_t;

// Memory barriers
#define memory_barrier() asm volatile ("" ::: "memory")
#define cpu_relax() asm volatile ("pause" ::: "memory")
```

---

## Conclusion

This worksheet demonstrates fundamental operating system development concepts:

1. **Boot Process**: Understanding BIOS/GRUB interaction and kernel loading
2. **Assembly-C Integration**: Bridging low-level hardware control with high-level logic
3. **Hardware Programming**: Direct memory-mapped I/O and port-based device control
4. **System Architecture**: Memory layout, linking, and executable format design

The implementation provides a solid foundation for more advanced OS development topics like interrupt handling, memory management, process scheduling, and device drivers.

**Key Takeaways**:
- OS development requires understanding both hardware and software layers
- Proper testing and debugging are crucial for low-level development
- Build systems must handle cross-compilation and specialized linking
- Documentation is essential for maintaining complex system code

**Next Steps**:
- Implement interrupt handling for keyboard input
- Add memory management with paging support
- Develop process scheduling and multitasking
- Create file system support and device drivers