# Tiny OS Development - Worksheet 2 Part 1

## Project Overview

This project implements a basic operating system from scratch, demonstrating fundamental OS development concepts including machine booting, calling C from assembly, and developing framebuffer drivers. The OS targets 32-bit x86 architecture and uses GRUB as the bootloader.

### Architecture and Design Decisions

- **Architecture**: 32-bit x86 (i386)
- **Bootloader**: GRUB Legacy with Multiboot specification
- **Memory Layout**: Kernel loaded at 1MB (0x00100000)
- **Stack Size**: 16KB for C runtime
- **Display**: VGA text mode framebuffer (80x25 characters)

## Task 1: Basic Bootable Kernel

### Multiboot Specification

The Multiboot specification allows bootloaders like GRUB to load our kernel. Our kernel includes the required magic header:

```assembly
MAGIC_NUMBER equ 0x1BADB002     ; Multiboot magic number
FLAGS equ 0x0                   ; No special flags
CHECKSUM equ -MAGIC_NUMBER      ; Checksum must make sum zero
```

### Boot Process

1. **BIOS/UEFI** loads GRUB from the bootable medium
2. **GRUB** reads the menu.lst configuration
3. **GRUB** loads our kernel.elf at address 0x00100000 (1MB)
4. **GRUB** verifies the Multiboot header
5. **GRUB** transfers control to our `loader` entry point
6. **Kernel** executes and writes 0xCAFEBABE to EAX register

### Key Assembly Concepts

The basic kernel demonstrates:
- **Multiboot compliance** for bootloader compatibility
- **Memory addressing** with proper alignment
- **Infinite loop** to prevent CPU from executing random memory
- **Register manipulation** to store the target value

```assembly
loader:                         ; Entry point
    mov eax, 0xCAFEBABE        ; Store target value in EAX
.loop:
    jmp .loop                   ; Infinite loop to halt execution
```

### Verification

The kernel successfully writes 0xCAFEBABE to the EAX register, which can be verified by examining the QEMU CPU trace logs.

## Task 2: C Integration

### Assembly to C Interface

The enhanced loader sets up a C runtime environment:

```assembly
loader:
    ; Set up stack for C runtime
    mov esp, kernel_stack + KERNEL_STACK_SIZE
    
    ; Call C main function
    call kmain
```

### Stack Setup and Calling Conventions

- **Stack Pointer (ESP)**: Points to the top of a 16KB stack
- **Calling Convention**: Standard C calling convention (cdecl)
- **Parameters**: Passed on the stack (though our kmain takes no parameters)
- **Return Values**: Returned in EAX register

### Implemented C Functions

1. **sum_of_three(int a, int b, int c)**: Returns the sum of three integers
2. **factorial(int n)**: Calculates factorial using iterative approach
3. **fibonacci(int n)**: Calculates nth Fibonacci number iteratively

```c
int sum_of_three(int a, int b, int c) {
    return a + b + c;
}

int factorial(int n) {
    if (n <= 1) return 1;
    int result = 1;
    for (int i = 2; i <= n; i++) {
        result *= i;
    }
    return result;
}
```

## Task 3: Framebuffer Driver

### Memory-Mapped I/O

The VGA text mode framebuffer is located at physical address 0x000B8000. Each character cell consists of 2 bytes:
- **Byte 0**: ASCII character code
- **Byte 1**: Attribute byte (4 bits background + 4 bits foreground color)

Example: `0x410F` = 'A' character (0x41) with white foreground on black background (0x0F)

### I/O Ports for Cursor Control

The VGA controller uses I/O ports to manage cursor position:
- **Port 0x3D4**: Command register
- **Port 0x3D5**: Data register

Commands:
- **0x0E**: Set cursor location high byte
- **0x0F**: Set cursor location low byte

```c
void fb_update_cursor() {
    unsigned short pos = cursor_y * FB_COLS + cursor_x;
    
    // Send high byte
    outb(FB_COMMAND_PORT, FB_HIGH_BYTE_COMMAND);
    outb(FB_DATA_PORT, (pos >> 8) & 0xFF);
    
    // Send low byte
    outb(FB_COMMAND_PORT, FB_LOW_BYTE_COMMAND);
    outb(FB_DATA_PORT, pos & 0xFF);
}
```

### API Design and Functions

The framebuffer driver provides a complete 2D text API:

#### Core Functions
- `fb_move(x, y)`: Move cursor to specified position
- `fb_write_char(c, color)`: Write single character with color
- `fb_write_string(str, color)`: Write null-terminated string
- `fb_clear()`: Clear entire screen
- `fb_write_int(num, color)`: Write integer as decimal string

#### Color Management
- 16 standard VGA colors (0-15)
- `FB_MAKE_COLOR(fg, bg)` macro for color attributes
- Support for foreground and background colors

#### Advanced Features
- **Automatic scrolling** when reaching bottom of screen
- **Newline handling** with proper cursor positioning
- **Tab support** with 8-character alignment
- **Boundary checking** to prevent buffer overflows

### Example Output

The kernel demonstrates various framebuffer capabilities:
- Text in different colors (red, green, blue, magenta)
- Cursor movement to arbitrary positions
- Number display and mathematical calculations
- Screen clearing functionality

## Build System

### Makefile Targets

- `make all`: Build complete bootable ISO image
- `make kernel.elf`: Build kernel only
- `make run`: Run OS in QEMU (text mode)
- `make run-curses`: Run OS in QEMU (framebuffer mode)
- `make run-simple`: Run Task 1 basic kernel
- `make test`: Run and verify 0xCAFEBABE in logs
- `make clean`: Remove all build artifacts

### Build Process

1. **Assembly**: `nasm -f elf loader.asm -o loader.o`
2. **C Compilation**: `gcc -m32 -c -ffreestanding -fno-stack-protector *.c`
3. **Linking**: `ld -T link.ld -melf_i386 *.o -o kernel.elf`
4. **ISO Creation**: `genisoimage` with GRUB bootloader

### Dependencies

- **NASM**: Netwide Assembler for x86 assembly
- **GCC**: GNU Compiler Collection with 32-bit support
- **GNU LD**: GNU Linker
- **QEMU**: System emulator for testing
- **genisoimage**: ISO image creation tool

## QEMU Usage Instructions

### Basic Testing (Task 1)
```bash
make run-simple
# Check logQ-simple.txt for 0xCAFEBABE
```

### Full OS Testing (Tasks 2-3)
```bash
# Text mode (CPU logs only)
make run

# Framebuffer mode (visual output)
make run-curses
# In separate terminal: telnet localhost 45454, then type 'quit' to exit
```

## Challenges and Solutions

### Challenge 1: Stack Setup
**Problem**: C functions require a proper stack setup, but assembly starts with undefined stack.
**Solution**: Allocated 16KB stack in BSS section and set ESP before calling C functions.

### Challenge 2: Cursor Synchronization
**Problem**: Hardware cursor position gets out of sync with software cursor tracking.
**Solution**: Implemented `fb_update_cursor()` function called after every character write.

### Challenge 3: Screen Scrolling
**Problem**: Text output beyond screen boundaries corrupts memory.
**Solution**: Implemented automatic scrolling by moving all lines up and clearing the bottom line.

### Challenge 4: Integer to String Conversion
**Problem**: No standard library available for number formatting.
**Solution**: Implemented custom `fb_write_int()` with manual digit extraction and string building.

### Challenge 5: Color Attribute Encoding
**Problem**: VGA color encoding is non-intuitive (background in high nibble).
**Solution**: Created `FB_MAKE_COLOR()` macro to simplify color specification.

## Lessons Learned

1. **Low-level Programming**: Direct hardware access requires careful register and memory management
2. **Boot Process**: Understanding the chain from BIOS to bootloader to kernel is crucial
3. **Memory Management**: Without an OS, every byte of memory must be manually managed
4. **Hardware Interfaces**: I/O ports and memory-mapped I/O provide direct hardware control
5. **Cross-Language Integration**: Calling conventions and stack management are critical for C/assembly interaction

## Technical Specifications

- **Kernel Size**: Approximately 4KB compiled
- **Memory Usage**: 16KB stack + framebuffer + kernel code
- **Boot Time**: Under 1 second in QEMU
- **Supported Features**: Text output, cursor control, color management, scrolling
- **Performance**: Direct hardware access provides maximum speed

## Future Enhancements

Potential improvements for more advanced OS development:
- Interrupt handling and keyboard input
- Memory management and paging
- Process scheduling and multitasking
- File system support
- Network stack implementation

---

*This tiny OS serves as the foundation for understanding operating system internals and provides a platform for implementing more advanced OS features in future worksheets.*