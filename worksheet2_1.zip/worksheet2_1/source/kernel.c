#include "framebuffer.h"

// Task 2: C Functions
int sum_of_three(int a, int b, int c) {
    return a + b + c;
}

int factorial(int n) {
    if (n <= 1) return 1;
    int result = 1;
    for (int i = 2; i <= n; i++) {
        result *= i;
    }
    return result;
}

int fibonacci(int n) {
    if (n <= 1) return n;
    int a = 0, b = 1, c;
    for (int i = 2; i <= n; i++) {
        c = a + b;
        a = b;
        b = c;
    }
    return b;
}

// Main kernel function called from assembly
void kmain() {
    // Initialize framebuffer
    fb_clear();
    
    // Test Task 2 functions
    fb_write_string("Testing C Functions:\n", FB_MAKE_COLOR(FB_WHITE, FB_BLACK));
    
    // Test sum_of_three
    int sum = sum_of_three(5, 10, 15);
    fb_write_string("sum_of_three(5, 10, 15) = ", FB_MAKE_COLOR(FB_CYAN, FB_BLACK));
    fb_write_int(sum, FB_MAKE_COLOR(FB_YELLOW, FB_BLACK));
    fb_write_string("\n", FB_MAKE_COLOR(FB_WHITE, FB_BLACK));
    
    // Test factorial
    int fact = factorial(5);
    fb_write_string("factorial(5) = ", FB_MAKE_COLOR(FB_CYAN, FB_BLACK));
    fb_write_int(fact, FB_MAKE_COLOR(FB_YELLOW, FB_BLACK));
    fb_write_string("\n", FB_MAKE_COLOR(FB_WHITE, FB_BLACK));
    
    // Test fibonacci
    int fib = fibonacci(8);
    fb_write_string("fibonacci(8) = ", FB_MAKE_COLOR(FB_CYAN, FB_BLACK));
    fb_write_int(fib, FB_MAKE_COLOR(FB_YELLOW, FB_BLACK));
    fb_write_string("\n\n", FB_MAKE_COLOR(FB_WHITE, FB_BLACK));
    
    // Test framebuffer functions
    fb_write_string("Testing Framebuffer Driver:\n", FB_MAKE_COLOR(FB_WHITE, FB_BLUE));
    
    // Test different colors
    fb_write_string("Red text ", FB_MAKE_COLOR(FB_RED, FB_BLACK));
    fb_write_string("Green text ", FB_MAKE_COLOR(FB_GREEN, FB_BLACK));
    fb_write_string("Blue text ", FB_MAKE_COLOR(FB_BLUE, FB_BLACK));
    fb_write_string("Magenta text\n", FB_MAKE_COLOR(FB_MAGENTA, FB_BLACK));
    
    // Test cursor movement
    fb_write_string("Moving cursor to (10, 10)...\n", FB_MAKE_COLOR(FB_CYAN, FB_BLACK));
    fb_move(10, 10);
    fb_write_string("Hello from (10,10)!", FB_MAKE_COLOR(FB_WHITE, FB_RED));
    
    // Move back and continue
    fb_move(0, 8);
    fb_write_string("Back to normal position\n", FB_MAKE_COLOR(FB_WHITE, FB_BLACK));
    
    // Test number display
    fb_write_string("Numbers: ", FB_MAKE_COLOR(FB_YELLOW, FB_BLACK));
    for (int i = 0; i < 10; i++) {
        fb_write_int(i, FB_MAKE_COLOR(FB_GREEN, FB_BLACK));
        fb_write_char(' ', FB_MAKE_COLOR(FB_WHITE, FB_BLACK));
    }
    fb_write_string("\n", FB_MAKE_COLOR(FB_WHITE, FB_BLACK));
    
    fb_write_string("\nKernel loaded successfully! 0xCAFEBABE", FB_MAKE_COLOR(FB_WHITE, FB_GREEN));
}