#ifndef FRAMEBUFFER_H
#define FRAMEBUFFER_H

// VGA color constants
#define FB_BLACK     0
#define FB_BLUE      1
#define FB_GREEN     2
#define FB_CYAN      3
#define FB_RED       4
#define FB_MAGENTA   5
#define FB_BROWN     6
#define FB_LIGHT_GREY 7
#define FB_DARK_GREY 8
#define FB_LIGHT_BLUE 9
#define FB_LIGHT_GREEN 10
#define FB_LIGHT_CYAN 11
#define FB_LIGHT_RED 12
#define FB_LIGHT_MAGENTA 13
#define FB_LIGHT_BROWN 14
#define FB_WHITE     15
#define FB_YELLOW    14  // Same as FB_LIGHT_BROWN

// Macro to create color attribute
#define FB_MAKE_COLOR(fg, bg) ((bg << 4) | (fg & 0x0F))

// Screen dimensions
#define FB_COLS 80
#define FB_ROWS 25

// Framebuffer API
void fb_move(unsigned short x, unsigned short y);
void fb_write_char(char c, unsigned char color);
void fb_write_string(const char* str, unsigned char color);
void fb_clear(void);
void fb_set_color(unsigned char fg, unsigned char bg);
void fb_write_int(int num, unsigned char color);

#endif