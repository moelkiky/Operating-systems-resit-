#include <stdio.h>
#include <string.h>

// Generic swap function using void pointers
void swap(void *x, void *y, size_t size) {
    // Create temporary buffer to hold one of the values
    char temp[size];
    
    // Copy x to temp, y to x, temp to y
    memcpy(temp, x, size);
    memcpy(x, y, size);
    memcpy(y, temp, size);
}

int main() {
    printf("Generic Swap Function Tests:\n");
    printf("============================\n");
    
    // Test 1: Swap integers
    printf("Test 1 - Swapping integers:\n");
    int a = 10, b = 20;
    printf("Before swap: a = %d, b = %d\n", a, b);
    swap(&a, &b, sizeof(int));
    printf("After swap:  a = %d, b = %d\n\n", a, b);
    
    // Test 2: Swap floats
    printf("Test 2 - Swapping floats:\n");
    float x = 3.14f, y = 2.71f;
    printf("Before swap: x = %.2f, y = %.2f\n", x, y);
    swap(&x, &y, sizeof(float));
    printf("After swap:  x = %.2f, y = %.2f\n\n", x, y);
    
    // Test 3: Swap characters
    printf("Test 3 - Swapping characters:\n");
    char c1 = 'A', c2 = 'Z';
    printf("Before swap: c1 = %c, c2 = %c\n", c1, c2);
    swap(&c1, &c2, sizeof(char));
    printf("After swap:  c1 = %c, c2 = %c\n\n", c1, c2);
    
    // Test 4: Swap doubles
    printf("Test 4 - Swapping doubles:\n");
    double d1 = 123.456, d2 = 789.012;
    printf("Before swap: d1 = %.3f, d2 = %.3f\n", d1, d2);
    swap(&d1, &d2, sizeof(double));
    printf("After swap:  d1 = %.3f, d2 = %.3f\n\n", d1, d2);
    
    // Test 5: Swap arrays
    printf("Test 5 - Swapping arrays:\n");
    int arr1[3] = {1, 2, 3};
    int arr2[3] = {4, 5, 6};
    printf("Before swap: arr1 = {%d, %d, %d}, arr2 = {%d, %d, %d}\n", 
           arr1[0], arr1[1], arr1[2], arr2[0], arr2[1], arr2[2]);
    swap(arr1, arr2, sizeof(arr1));
    printf("After swap:  arr1 = {%d, %d, %d}, arr2 = {%d, %d, %d}\n", 
           arr1[0], arr1[1], arr1[2], arr2[0], arr2[1], arr2[2]);
    
    return 0;
}