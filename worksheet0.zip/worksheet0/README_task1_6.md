# Task 1.6 - 2D Array Printing Function

## Overview
This task demonstrates how to work with 2D arrays using pointer arithmetic by implementing a function that prints 2D arrays of any dimensions. It showcases the mathematical relationship between 2D array indexing and linear memory layout.

## Problem Statement
Create a program that:
1. Implements a function `print_array(int *arr, int width, int height)`
2. Prints 2D arrays using only pointer arithmetic (no array indexing)
3. Uses the formula `arr[i * width + j]` for element access
4. Demonstrates with arrays of various dimensions
5. Includes an educational demonstration of the indexing formula

## Solution Approach

### Key Concepts Used
- **2D to 1D Mapping**: `arr[i][j] ≡ *(arr + i * width + j)`
- **Row-major Order**: Elements stored row by row in memory
- **Pointer Arithmetic**: Linear address calculation
- **Generic Dimensions**: Function works with any width/height
- **Mathematical Formula**: `index = row * width + column`

### Implementation Details

#### Core Printing Function
```c
void print_array(int *arr, int width, int height) {
    printf("2D Array (%dx%d):\n", height, width);
    
    for (int i = 0; i < height; i++) {        // For each row
        for (int j = 0; j < width; j++) {     // For each column
            // Use formula: arr[i * width + j] for element at position (i,j)
            printf("%4d ", *(arr + i * width + j));
        }
        printf("\n");
    }
    printf("\n");
}
```

#### Memory Layout Formula
```
2D Array Declaration:  arr[rows][cols]
Memory Layout:         [row0][row1][row2]...[rowN]
Element Access:        arr[i][j] = *(arr + i * width + j)

For 3x3 array:
Position (0,0) → index 0*3+0 = 0
Position (0,1) → index 0*3+1 = 1  
Position (0,2) → index 0*3+2 = 2
Position (1,0) → index 1*3+0 = 3
Position (1,1) → index 1*3+1 = 4
Position (1,2) → index 1*3+2 = 5
Position (2,0) → index 2*3+0 = 6
Position (2,1) → index 2*3+1 = 7
Position (2,2) → index 2*3+2 = 8
```

### Test Case Architecture

#### Multiple Dimension Tests
```c
// Test 1: 3x3 square array
int arr1[3][3] = {{1, 2, 3}, {4, 5, 6}, {7, 8, 9}};
print_array((int*)arr1, 3, 3);

// Test 2: 2x4 rectangular array  
int arr2[2][4] = {{10, 20, 30, 40}, {50, 60, 70, 80}};
print_array((int*)arr2, 4, 2);

// Test 3: 4x2 tall array
int arr3[4][2] = {{100, 200}, {300, 400}, {500, 600}, {700, 800}};
print_array((int*)arr3, 2, 4);

// Test 4: 1x5 single row
int arr4[1][5] = {{11, 22, 33, 44, 55}};
print_array((int*)arr4, 5, 1);

// Test 5: 5x1 single column  
int arr5[5][1] = {{111}, {222}, {333}, {444}, {555}};
print_array((int*)arr5, 1, 5);
```

## Testing Methodology

### Compilation
```bash
clang -o task1_6 task1_6.c
```

### Execution
```bash
./task1_6
```

### Expected Output
```
2D Array Printing Function Tests:
=================================
Test 1 - 3x3 Array:
2D Array (3x3):
   1    2    3 
   4    5    6 
   7    8    9 

Test 2 - 2x4 Array:
2D Array (2x4):
  10   20   30   40 
  50   60   70   80 

Test 3 - 4x2 Array:
2D Array (4x2):
 100  200 
 300  400 
 500  600 
 700  800 

Test 4 - 1x5 Array (single row):
2D Array (1x5):
  11   22   33   44   55 

Test 5 - 5x1 Array (single column):
2D Array (5x1):
 111 
 222 
 333 
 444 
 555 

Indexing Demonstration for 3x3 array:
=====================================
Position	Formula		Value
--------	-------		-----
(0,0)		0 * 3 + 0 = 0	1
(0,1)		0 * 3 + 1 = 1	2
(0,2)		0 * 3 + 2 = 2	3
(1,0)		1 * 3 + 0 = 3	4
(1,1)		1 * 3 + 1 = 4	5
(1,2)		1 * 3 + 2 = 5	6
(2,0)		2 * 3 + 0 = 6	7
(2,1)		2 * 3 + 1 = 7	8
(2,2)		2 * 3 + 2 = 8	9
```

## Test Results Analysis

### ✅ Successful Outcomes
1. **3x3 Square Array**: Properly formatted square layout
2. **2x4 Rectangular**: Correctly handles non-square dimensions
3. **4x2 Tall Array**: Vertical layout displayed correctly
4. **1x5 Single Row**: Horizontal single-row layout
5. **5x1 Single Column**: Vertical single-column layout
6. **Formula Demonstration**: Shows index calculation for each position

### Mathematical Verification
- **Index Formula**: `i * width + j` correctly maps 2D to 1D
- **Memory Layout**: Sequential storage verified by addresses
- **Boundary Handling**: No buffer overflows for any test case
- **Formatting**: Proper alignment and spacing for readability

## Advanced Concepts Demonstrated

### Row-Major vs Column-Major Storage
```c
// Row-major (C/C++ standard):
// arr[3][4] stored as: [row0][row1][row2]
// Memory: [0,0][0,1][0,2][0,3][1,0][1,1][1,2][1,3][2,0][2,1][2,2][2,3]

// Column-major (Fortran style):  
// Would be: [0,0][1,0][2,0][0,1][1,1][2,1][0,2][1,2][2,2][0,3][1,3][2,3]
```

### Pointer Casting for 2D Arrays
```c
int arr[3][4];           // 2D array declaration
int *ptr = (int*)arr;    // Cast to linear pointer
// or
int *ptr = &arr[0][0];   // Pointer to first element
```

### Memory Address Calculation
```c
// For element at (i, j):
int *element_addr = arr + (i * width + j);
int element_value = *(arr + (i * width + j));

// Equivalent to:
int element_value = arr[i * width + j];  // If arr was declared as int arr[]
```

### Generic Multi-dimensional Access
```c
// 3D array access pattern:
// arr[i][j][k] ≡ *(arr + i*height*depth + j*depth + k)

// 4D array access pattern:
// arr[i][j][k][l] ≡ *(arr + i*d1*d2*d3 + j*d2*d3 + k*d3 + l)
```

## Memory Layout Analysis

### 3x3 Array Memory Visualization
```
Conceptual 2D Layout:     Linear Memory Layout:
┌─────┬─────┬─────┐      ┌─────┬─────┬─────┬─────┬─────┬─────┬─────┬─────┬─────┐
│  1  │  2  │  3  │      │  1  │  2  │  3  │  4  │  5  │  6  │  7  │  8  │  9  │
├─────┼─────┼─────┤      └─────┴─────┴─────┴─────┴─────┴─────┴─────┴─────┴─────┘
│  4  │  5  │  6  │      Index: 0   1   2   3   4   5   6   7   8
├─────┼─────┼─────┤      Pos: (0,0)(0,1)(0,2)(1,0)(1,1)(1,2)(2,0)(2,1)(2,2)
│  7  │  8  │  9  │
└─────┴─────┴─────┘
```

### Address Calculation Example
```c
int arr[3][3] = {{1,2,3}, {4,5,6}, {7,8,9}};
int *base = (int*)arr;

// Element at position (1,2) = value 6
int *addr = base + (1 * 3 + 2);  // base + 5
int value = *(base + 5);          // value = 6
```

## Performance Characteristics

### Time Complexity
- **O(width × height)**: Must visit every element once
- **Linear traversal**: Cache-friendly sequential access
- **No overhead**: Direct pointer arithmetic, no function calls

### Space Complexity
- **O(1)**: Constant space usage (no additional storage)
- **Stack variables**: Only loop counters and parameters
- **No recursion**: Iterative approach

### Cache Performance
- **Sequential Access**: Optimal cache locality
- **Predictable Pattern**: CPU can prefetch next cache lines
- **Memory Bandwidth**: Efficiently uses available memory bandwidth

## Practical Applications

### Image Processing
```c
// RGB image as 2D array of pixels
void process_image(int *pixels, int width, int height) {
    for (int y = 0; y < height; y++) {
        for (int x = 0; x < width; x++) {
            int pixel = *(pixels + y * width + x);
            // Process pixel...
        }
    }
}
```

### Matrix Operations
```c
// Matrix multiplication using pointer arithmetic
void matrix_multiply(int *A, int *B, int *C, int rows, int cols, int inner) {
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            int sum = 0;
            for (int k = 0; k < inner; k++) {
                sum += (*(A + i * inner + k)) * (*(B + k * cols + j));
            }
            *(C + i * cols + j) = sum;
        }
    }
}
```

### Game Development
```c
// 2D game board representation
void update_game_board(int *board, int width, int height) {
    for (int row = 0; row < height; row++) {
        for (int col = 0; col < width; col++) {
            int cell = *(board + row * width + col);
            // Update game logic...
        }
    }
}
```

## Educational Value

### Formula Understanding
The demonstration section teaches:
- **Index calculation**: How (row, col) maps to linear index
- **Memory layout**: How 2D arrays are stored in 1D memory  
- **Pointer arithmetic**: Why `ptr + offset` works
- **Mathematical relationship**: The formula `i * width + j`

### Debugging Skills
Students learn to:
- **Visualize memory**: Understanding linear vs 2D representation
- **Calculate addresses**: Manual verification of pointer arithmetic
- **Detect errors**: Off-by-one errors in index calculations
- **Optimize access**: Understanding cache-friendly patterns

## Safety Considerations

### Bounds Checking
```c
// Enhanced version with bounds checking:
void safe_print_array(int *arr, int width, int height) {
    if (arr == NULL || width <= 0 || height <= 0) {
        printf("Invalid array parameters\n");
        return;
    }
    // ... rest of function
}
```

### Buffer Overflow Prevention
- **Parameter validation**: Check for reasonable dimensions
- **Null pointer checks**: Verify array pointer is valid
- **Integer overflow**: Be careful with large width × height calculations

## Compilation and Portability

### Standard Compliance
- **C99 compatible**: Uses standard integer types and stdio
- **No extensions**: Pure standard C language features
- **Portable**: Works on any architecture with C compiler

### Optimization Opportunities
- **Loop unrolling**: Compiler may unroll inner loops
- **SIMD instructions**: Vector operations for large arrays  
- **Cache prefetching**: Hardware may optimize sequential access