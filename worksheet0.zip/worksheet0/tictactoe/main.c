#include <stdio.h>
#include "game.h"

int main() {
    char choice;
    
    do {
        // Start the game
        play_game();
        
        // Ask if player wants to play again
        printf("\nWould you like to play again? (y/n): ");
        scanf(" %c", &choice);
        
        // Clear input buffer
        while (getchar() != '\n');
        
    } while (choice == 'y' || choice == 'Y');
    
    printf("Goodbye!\n");
    return 0;
}