#ifndef GAME_H
#define GAME_H

#include "board.h"

// Game logic functions
int check_winner(char *board);
int check_line(char *board, int pos1, int pos2, int pos3);
void switch_player(char *current_player);
int get_player_move(void);
void play_game(void);

#endif