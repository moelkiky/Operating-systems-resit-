#ifndef BOARD_H
#define BOARD_H

#define BOARD_SIZE 3
#define EMPTY ' '
#define PLAYER_X 'X'
#define PLAYER_O 'O'

// Board operations
void init_board(char *board);
void display_board(char *board);
int is_valid_move(char *board, int position);
void make_move(char *board, int position, char player);
int is_board_full(char *board);

#endif