#include <stdio.h>
#include <stdlib.h>
#include "game.h"
#include "board.h"

// Check if there's a winner by examining all possible winning lines
int check_winner(char *board) {
    // Check rows
    if (check_line(board, 0, 1, 2) || 
        check_line(board, 3, 4, 5) || 
        check_line(board, 6, 7, 8)) {
        return 1;
    }
    
    // Check columns
    if (check_line(board, 0, 3, 6) || 
        check_line(board, 1, 4, 7) || 
        check_line(board, 2, 5, 8)) {
        return 1;
    }
    
    // Check diagonals
    if (check_line(board, 0, 4, 8) || 
        check_line(board, 2, 4, 6)) {
        return 1;
    }
    
    return 0;  // No winner
}

// Check if three positions form a winning line using pointer arithmetic
int check_line(char *board, int pos1, int pos2, int pos3) {
    char val1 = *(board + pos1);
    char val2 = *(board + pos2);
    char val3 = *(board + pos3);
    
    // Check if all three positions have the same non-empty value
    return (val1 != EMPTY && val1 == val2 && val2 == val3);
}

// Switch between players using pointer to current player
void switch_player(char *current_player) {
    if (*current_player == PLAYER_X) {
        *current_player = PLAYER_O;
    } else {
        *current_player = PLAYER_X;
    }
}

// Get a valid move from the player
int get_player_move(void) {
    int move;
    char buffer[100];
    
    while (1) {
        printf("Enter your move (1-9): ");
        
        // Read input as string first to handle invalid input
        if (fgets(buffer, sizeof(buffer), stdin) != NULL) {
            // Try to parse as integer
            if (sscanf(buffer, "%d", &move) == 1) {
                if (move >= 1 && move <= 9) {
                    return move;
                }
            }
        }
        
        printf("Invalid input! Please enter a number between 1 and 9.\n");
    }
}

// Main game loop
void play_game(void) {
    char board[BOARD_SIZE * BOARD_SIZE];
    char current_player = PLAYER_X;
    int move;
    int game_over = 0;
    
    // Initialize the board
    init_board(board);
    
    printf("Welcome to Tic-Tac-Toe!\n");
    printf("Player X goes first.\n");
    
    while (!game_over) {
        // Display current board
        display_board(board);
        
        // Get player move
        printf("Player %c's turn.\n", current_player);
        move = get_player_move();
        
        // Validate and make move
        if (is_valid_move(board, move)) {
            make_move(board, move, current_player);
            
            // Check for winner
            if (check_winner(board)) {
                display_board(board);
                printf("🎉 Player %c wins! 🎉\n", current_player);
                game_over = 1;
            }
            // Check for tie
            else if (is_board_full(board)) {
                display_board(board);
                printf("It's a tie! Good game!\n");
                game_over = 1;
            }
            // Continue game
            else {
                switch_player(&current_player);
            }
        } else {
            printf("Invalid move! Position %d is already taken or out of bounds.\n", move);
        }
    }
    
    printf("Thanks for playing!\n");
}