#include <stdio.h>
#include "board.h"

// Initialize the board with empty spaces
void init_board(char *board) {
    for (int i = 0; i < BOARD_SIZE * BOARD_SIZE; i++) {
        *(board + i) = EMPTY;
    }
}

// Display the current state of the board
void display_board(char *board) {
    printf("\n");
    printf("   |   |   \n");
    printf(" %c | %c | %c \n", *(board + 0), *(board + 1), *(board + 2));
    printf("___|___|___\n");
    printf("   |   |   \n");
    printf(" %c | %c | %c \n", *(board + 3), *(board + 4), *(board + 5));
    printf("___|___|___\n");
    printf("   |   |   \n");
    printf(" %c | %c | %c \n", *(board + 6), *(board + 7), *(board + 8));
    printf("   |   |   \n");
    printf("\n");
    
    // Show position numbers for reference
    printf("Position reference:\n");
    printf("   |   |   \n");
    printf(" 1 | 2 | 3 \n");
    printf("___|___|___\n");
    printf("   |   |   \n");
    printf(" 4 | 5 | 6 \n");
    printf("___|___|___\n");
    printf("   |   |   \n");
    printf(" 7 | 8 | 9 \n");
    printf("   |   |   \n");
    printf("\n");
}

// Check if a move is valid (position is empty and within bounds)
int is_valid_move(char *board, int position) {
    // Convert 1-9 to 0-8 array index
    int index = position - 1;
    
    // Check bounds
    if (index < 0 || index >= BOARD_SIZE * BOARD_SIZE) {
        return 0;
    }
    
    // Check if position is empty
    return *(board + index) == EMPTY;
}

// Make a move on the board using pointer arithmetic
void make_move(char *board, int position, char player) {
    // Convert 1-9 to 0-8 array index
    int index = position - 1;
    *(board + index) = player;
}

// Check if the board is full
int is_board_full(char *board) {
    for (int i = 0; i < BOARD_SIZE * BOARD_SIZE; i++) {
        if (*(board + i) == EMPTY) {
            return 0;  // Found empty space
        }
    }
    return 1;  // Board is full
}