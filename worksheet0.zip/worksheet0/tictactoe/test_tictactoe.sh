#!/bin/bash

# TicTacToe Test Script
# This script demonstrates how to test the TicTacToe game

echo "=== TicTacToe Game Test ==="
echo "This script shows how to test the TicTacToe game."
echo ""
echo "Method 1: Manual Testing"
echo "Run: ./tictactoe"
echo "Then enter numbers 1-9 to place X's and O's on the board"
echo ""
echo "Method 2: Automated Test (simulating a quick game)"
echo "We'll simulate X winning with moves: 1, 4, 2, 5, 3"
echo ""

# Create a test input file
cat > test_input.txt << 'EOF'
1
4
2
5
3
n
EOF

echo "Test input created. Running game with predetermined moves..."
echo "Expected result: X should win with a diagonal (positions 1, 5, 9) or top row (1, 2, 3)"
echo ""
echo "Running test..."
./tictactoe < test_input.txt

echo ""
echo "=== Test Complete ==="
echo "The game should have shown:"
echo "1. Welcome message"
echo "2. Empty board with position numbers"
echo "3. Player moves being placed"
echo "4. A winner announcement"
echo "5. Play again prompt (answered 'n')"