# TASK 1.5 - GENERIC SWAP FUNCTION WITH VOID POINTERS

## Overview
This program demonstrates advanced pointer concepts including void pointers, generic programming, memory manipulation functions, and type-agnostic data swapping with comprehensive testing across multiple data types.

## File: task1_5.c

### Program Architecture

#### Generic Function Declaration
```c
void swap(void *x, void *y, size_t size);
```

**Advanced Parameter Design:**
- `void *x` - Generic pointer to first data item (type-agnostic)
- `void *y` - Generic pointer to second data item (type-agnostic)
- `size_t size` - Number of bytes to swap (type size information)
- Return type: `void` (operation modifies data in-place)

#### Core Swapping Algorithm
```c
char temp[size];           // Variable-length array (VLA) for temporary storage
memcpy(temp, x, size);     // Copy x → temp
memcpy(x, y, size);        // Copy y → x  
memcpy(y, temp, size);     // Copy temp → y
```

**Memory Operations:**
- **Variable Length Array**: `char temp[size]` allocates runtime-sized buffer
- **memcpy()**: Byte-level memory copying function from `<string.h>`
- **Three-way swap**: Classic algorithm using temporary storage
- **Byte-wise operation**: Works with any data type

#### Type-Safe Function Calls
```c
swap(&a, &b, sizeof(int));      // Integer swapping
swap(&x, &y, sizeof(float));    // Float swapping
swap(arr1, arr2, sizeof(arr1)); // Array swapping
```

**Generic Interface Usage:**
- Address-of operator (`&`) provides memory addresses
- `sizeof()` operator provides type size information
- Arrays passed directly (array names are already addresses)
- Type information encoded in size parameter

### Test Suite Analysis

#### Test 1: Integer Swapping
```c
int a = 10, b = 20;
swap(&a, &b, sizeof(int));  // 4 bytes on most systems
// Result: a = 20, b = 10
```

#### Test 2: Float Swapping
```c
float x = 3.14f, y = 2.71f;
swap(&x, &y, sizeof(float));  // 4 bytes (IEEE 754)
// Result: x = 2.71, y = 3.14
```

#### Test 3: Character Swapping
```c
char c1 = 'A', c2 = 'Z';
swap(&c1, &c2, sizeof(char));  // 1 byte
// Result: c1 = 'Z', c2 = 'A'
```

#### Test 4: Double Precision Swapping
```c
double d1 = 123.456, d2 = 789.012;
swap(&d1, &d2, sizeof(double));  // 8 bytes (IEEE 754)
// Result: d1 = 789.012, d2 = 123.456
```

#### Test 5: Array Swapping
```c
int arr1[3] = {1, 2, 3};
int arr2[3] = {4, 5, 6};
swap(arr1, arr2, sizeof(arr1));  // 12 bytes (3 × 4 bytes)
// Result: arr1 = {4, 5, 6}, arr2 = {1, 2, 3}
```

### Build Instructions

#### Compilation
```bash
clang -o task1_5 task1_5.c
```

#### Execution
```bash
./task1_5
```

### Expected Output
```
Generic Swap Function Tests:
============================
Test 1 - Swapping integers:
Before swap: a = 10, b = 20
After swap:  a = 20, b = 10

Test 2 - Swapping floats:
Before swap: x = 3.14, y = 2.71
After swap:  x = 2.71, y = 3.14

Test 3 - Swapping characters:
Before swap: c1 = A, c2 = Z
After swap:  c1 = Z, c2 = A

Test 4 - Swapping doubles:
Before swap: d1 = 123.456, d2 = 789.012
After swap:  d1 = 789.012, d2 = 123.456

Test 5 - Swapping arrays:
Before swap: arr1 = {1, 2, 3}, arr2 = {4, 5, 6}
After swap:  arr1 = {4, 5, 6}, arr2 = {1, 2, 3}
```

### Technical Deep Dive

#### Void Pointer Mechanics
```c
void *ptr;  // Can point to any data type
```

**Characteristics:**
- **Type Erasure**: Loses original type information
- **No Arithmetic**: Cannot perform pointer arithmetic directly
- **No Dereferencing**: Cannot dereference without casting
- **Generic Storage**: Can hold address of any type

#### Memory Layout Analysis
```
Memory Operation for int swap (4 bytes):
┌─────────┬─────────┬─────────┬─────────┐
│ Byte 0  │ Byte 1  │ Byte 2  │ Byte 3  │ ← Variable 'a'
└─────────┴─────────┴─────────┴─────────┘
┌─────────┬─────────┬─────────┬─────────┐
│ Byte 0  │ Byte 1  │ Byte 2  │ Byte 3  │ ← Variable 'b'
└─────────┴─────────┴─────────┴─────────┘
┌─────────┬─────────┬─────────┬─────────┐
│ Byte 0  │ Byte 1  │ Byte 2  │ Byte 3  │ ← Temporary buffer
└─────────┴─────────┴─────────┴─────────┘
```

#### memcpy() Function Analysis
```c
void *memcpy(void *dest, const void *src, size_t n);
```

**Operation Details:**
- **Byte-by-byte copying**: No type interpretation required
- **Efficient implementation**: Often optimized with assembly
- **Non-overlapping regions**: Source and destination must not overlap
- **Returns destination pointer**: Allows function chaining

#### Variable Length Array (VLA)
```c
char temp[size];  // C99 feature
```

**Stack Allocation:**
- **Runtime sizing**: Array size determined at function call
- **Stack-based**: Allocated in function's stack frame
- **Automatic cleanup**: Deallocated when function returns
- **Size limitations**: Limited by stack size

### Advanced Programming Concepts

#### Generic Programming in C
```c
// Type-specific functions (traditional approach):
void swap_int(int *a, int *b);
void swap_float(float *a, float *b);
void swap_double(double *a, double *b);

// vs. Generic function (modern approach):
void swap(void *x, void *y, size_t size);  // One function for all types
```

#### Memory Abstraction Levels
```
High Level:   swap(int *a, int *b)           ← Type-safe, less flexible
Medium Level: swap(void *x, void *y, size)  ← Generic, requires size
Low Level:    Manual byte manipulation      ← Maximum control, complex
```

#### Function Polymorphism Simulation
```c
#define SWAP(x, y) swap(&(x), &(y), sizeof(x))

// Usage becomes more convenient:
SWAP(a, b);    // Automatically determines size and takes addresses
```

### Learning Objectives Achieved

#### Advanced Pointer Concepts
1. ✅ **Void Pointers**: Generic pointer usage and limitations
2. ✅ **Type Erasure**: Working without compile-time type information
3. ✅ **Memory Manipulation**: Low-level data copying operations
4. ✅ **Generic Programming**: Single function for multiple types

#### Memory Management Skills
1. ✅ **Variable Length Arrays**: Runtime array allocation
2. ✅ **memcpy() Usage**: Efficient memory copying techniques
3. ✅ **Stack Management**: Understanding function-local storage
4. ✅ **Memory Safety**: Proper buffer sizing and usage

#### Software Design Principles
1. ✅ **Code Reusability**: Single function for multiple data types
2. ✅ **Interface Design**: Clean, consistent function signatures
3. ✅ **Testing Methodology**: Comprehensive type coverage
4. ✅ **Documentation**: Clear usage examples and explanations

### Performance Analysis

#### Time Complexity
- **Swap Operation**: O(n) where n = size in bytes
- **Memory Copy**: Linear in data size (optimized implementations)
- **Function Call**: O(1) overhead regardless of data type

#### Space Complexity
- **Temporary Storage**: O(n) additional space for buffer
- **Stack Usage**: VLA allocated on function stack
- **No Heap Usage**: All operations use automatic storage

#### Optimization Considerations
```c
// Compiler optimizations:
// 1. memcpy() often becomes inline assembly
// 2. Small sizes may use direct register operations
// 3. VLA may be optimized for common sizes
```

### Real-World Applications

#### Algorithm Implementation
- **Sorting Algorithms**: Generic quicksort, mergesort implementations
- **Data Structure Operations**: Generic stack, queue operations
- **Memory Pool Management**: Generic allocation/deallocation
- **Serialization**: Converting structures to/from byte streams

#### System Programming
```c
// Examples of generic swap usage:
void generic_sort(void *base, size_t nmemb, size_t size, 
                  int (*compar)(const void *, const void *));
                  
void circular_buffer_swap(void *buf, size_t pos1, size_t pos2, size_t elem_size);
```

### Common Pitfalls and Solutions

#### Size Mismatch
```c
// Problem: Wrong size parameter
swap(&a, &b, sizeof(float));  // 'a' and 'b' are ints!
// Solution: Always use sizeof() with actual variable types
```

#### Alignment Issues
```c
// Some architectures require proper alignment
// memcpy() handles this automatically
```

#### Overlapping Memory
```c
// Problem: Source and destination overlap
// Solution: Use memmove() instead of memcpy() for overlapping regions
```

### Integration with Course Objectives
- **Generic Programming**: Foundation for template-like behavior in C
- **Memory Management**: Understanding low-level data manipulation
- **Function Design**: Creating reusable, type-agnostic interfaces
- **Testing Methodology**: Comprehensive validation across data types
- **Performance Awareness**: Understanding memory operation costs