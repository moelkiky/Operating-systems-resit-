# Operating Systems Worksheet 0 - C Programming Fundamentals

This repository contains solutions for UFCFWK-15-2 Operating Systems Worksheet 0, focusing on C programming fundamentals including pointers, file I/O, and modular programming.

## File Structure

```
worksheet0/
├── task1_1.c          # Basic pointer operations
├── task1_2.c          # Array pointer iteration
├── task1_3.c          # Array comparison function
├── task1_4.c          # File reading and sum calculation
├── foo.txt            # Input file for task1_4
├── task1_5.c          # Generic swap function
├── task1_6.c          # 2D array printing function
├── tictactoe/         # TicTacToe game implementation
│   ├── main.c         # Main game entry point
│   ├── game.c         # Game logic implementation
│   ├── game.h         # Game logic header
│   ├── board.c        # Board operations implementation
│   ├── board.h        # Board operations header
│   └── Makefile       # Build configuration
└── README.md          # This file
```

## Compilation Instructions

### Individual Tasks (Task 1.1 - 1.6)

```bash
# Compile any individual task
clang -o task1_1 task1_1.c
clang -o task1_2 task1_2.c
clang -o task1_3 task1_3.c
clang -o task1_4 task1_4.c
clang -o task1_5 task1_5.c
clang -o task1_6 task1_6.c

# Run the compiled program
./task1_1
```

### TicTacToe Game (Task 2)

```bash
# Navigate to tictactoe directory
cd tictactoe

# Compile using Makefile
make

# Or compile manually
clang -o tictactoe main.c game.c board.c

# Run the game
./tictactoe
```

## Task Descriptions

### Task 1.1: Basic Pointers
- Creates a pointer to a local variable
- Uses the pointer to increment the variable
- Demonstrates pointer dereferencing and address operations

### Task 1.2: Array Pointer Iteration
- Creates an array {10, 30, 2000}
- Uses pointer arithmetic to iterate through the array
- Prints both values and addresses of each element

### Task 1.3: Array Comparison Function
- Implements `compare_arrays(int *ptr1, int *ptr2, int length)`
- Includes null pointer checking
- Compares arrays element by element using pointers
- Comprehensive test cases included

### Task 1.4: File Reading and Sum
- Reads integers from `foo.txt`
- Calculates and displays the sum (should be 154)
- Includes proper file handling and error checking

### Task 1.5: Generic Swap Function
- Implements `swap(void *x, void *y, size_t size)`
- Works with any data type using void pointers
- Tests with integers, floats, characters, doubles, and arrays

### Task 1.6: 2D Array Printing Function
- Implements `print_array(int *arr, int width, int height)`
- Uses formula `arr[i * width + j]` for 2D indexing
- Demonstrates various array sizes and layouts

### Task 2: TicTacToe Game
- Complete modular implementation with separate .c and .h files
- Extensive use of pointers throughout the codebase
- Features:
  - Board initialization and display
  - Move validation and execution
  - Win condition checking
  - Player input handling
  - Game loop management

## Key C Programming Concepts Demonstrated

1. **Pointer Operations**: Dereferencing, address-of operator, pointer arithmetic
2. **Array Manipulation**: Using pointers to traverse and modify arrays
3. **Function Parameters**: Pass by reference using pointers
4. **File I/O**: Reading from files with proper error handling
5. **Memory Management**: Safe pointer usage and null checking
6. **Modular Programming**: Separation of concerns with header files
7. **Generic Programming**: Void pointers for type-agnostic functions

## Sample Outputs

### Task 1.1 Output
```
Original value of n: 10
Address of n: 0x7fff5fbff6ac
Value of ptr_to_n (address it points to): 0x7fff5fbff6ac
After incrementing through pointer:
New value of n: 11
Value accessed through pointer: 11
```

### Task 1.4 Output
```
Reading numbers from foo.txt:
Numbers found: 10 20 30 40 54 

Results:
--------
Total numbers read: 5
Sum of all numbers: 154
```

### TicTacToe Game Sample
```
Welcome to Tic-Tac-Toe!
Player X goes first.

   |   |   
   |   |   
___|___|___
   |   |   
   |   |   
___|___|___
   |   |   
   |   |   
   |   |   

Position reference:
   |   |   
 1 | 2 | 3 
___|___|___
   |   |   
 4 | 5 | 6 
___|___|___
   |   |   
 7 | 8 | 9 
   |   |   

Player X's turn.
Enter your move (1-9): 5
```

## Technical Notes

- All code compiles with `clang` without warnings
- Proper error handling implemented throughout
- Extensive use of pointer arithmetic as required
- Memory-safe operations with null pointer checks
- Clean modular design with proper header guards

## Author

Created for UFCFWK-15-2 Operating Systems Course - Worksheet 0