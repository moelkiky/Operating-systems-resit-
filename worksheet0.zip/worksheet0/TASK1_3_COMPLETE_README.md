# TASK 1.3 - ARRAY COMPARISON WITH FUNCTIONS

## Overview
This program demonstrates function-based array comparison using pointer parameters, null pointer validation, parameter passing techniques, and comprehensive testing scenarios with various array configurations.

## File: task1_3.c

### Program Architecture

#### Function Declaration and Parameters
```c
int compare_arrays(int *ptr1, int *ptr2, int length);
```

**Parameter Design:**
- `int *ptr1` - Pointer to first array (passed by reference)
- `int *ptr2` - Pointer to second array (passed by reference)  
- `int length` - Number of elements to compare (passed by value)
- Return type: `int` (1 for equal, 0 for different/error)

#### Core Comparison Logic
```c
for (int i = 0; i < length; i++) {
    if (*(ptr1 + i) != *(ptr2 + i)) {
        return 0;  // Early termination on first difference
    }
}
return 1;  // All elements matched
```

**Algorithm Features:**
- Element-by-element comparison using pointer arithmetic
- Short-circuit evaluation (stops at first difference)
- Pointer dereferencing with offset calculation
- Boolean return value (1 = true, 0 = false)

#### Safety Validation
```c
if (ptr1 == NULL || ptr2 == NULL) {
    return 0;  // Defensive programming
}
```

**Security Features:**
- Null pointer detection prevents segmentation faults
- Graceful error handling with meaningful return values
- Defensive programming best practices

### Test Suite Analysis

#### Test Case 1: Identical Arrays
```c
int arr1[] = {1, 2, 3, 4, 5};
int arr2[] = {1, 2, 3, 4, 5};
compare_arrays(arr1, arr2, 5) → Returns 1 (EQUAL)
```

#### Test Case 2: Different Arrays (Same Length)
```c
int arr1[] = {1, 2, 3, 4, 5};
int arr3[] = {1, 2, 3, 4, 6};  // Last element differs
compare_arrays(arr1, arr3, 5) → Returns 0 (DIFFERENT)
```

#### Test Case 3: Partial Comparison
```c
compare_arrays(arr1, arr3, 4) → Returns 1 (EQUAL)
// Only compares first 4 elements: {1, 2, 3, 4}
```

#### Test Case 4: Different Data Sets
```c
int arr4[] = {10, 20, 30};
compare_arrays(arr1, arr4, 3) → Returns 0 (DIFFERENT)
```

#### Test Case 5: Null Pointer Handling
```c
compare_arrays(arr1, NULL, 5) → Returns 0 (NULL detected)
```

### Build Instructions

#### Compilation
```bash
clang -o task1_3 task1_3.c
```

#### Execution
```bash
./task1_3
```

### Expected Output
```
Array Comparison Tests:
======================
Test 1 - arr1 vs arr2 (identical): Arrays are EQUAL
Test 2 - arr1 vs arr3 (different): Arrays are DIFFERENT
Test 3 - arr1 vs arr3 (first 4 elements): Arrays are EQUAL
Test 4 - arr1 vs arr4 (first 3 elements): Arrays are DIFFERENT
Test 5 - arr1 vs NULL: Arrays are DIFFERENT (null pointer detected)
```

### Technical Deep Dive

#### Memory Access Patterns
```c
*(ptr1 + i) vs *(ptr2 + i)
```

**Address Calculation:**
- `ptr1 + i` = base_address1 + (i × sizeof(int))
- `ptr2 + i` = base_address2 + (i × sizeof(int))
- Automatic type-aware arithmetic scaling

#### Function Call Mechanics
```c
// When calling: compare_arrays(arr1, arr2, 5)
// Array names decay to pointers
arr1 → &arr1[0]  (pointer to first element)
arr2 → &arr2[0]  (pointer to first element)
```

#### Stack Frame Analysis
```
Function Stack Frame:
┌─────────────────┐
│ int length = 5  │ ← Value parameter (copy)
├─────────────────┤
│ int *ptr2       │ ← Pointer parameter (address)
├─────────────────┤
│ int *ptr1       │ ← Pointer parameter (address)
├─────────────────┤
│ return address  │ ← Function return point
└─────────────────┘
```

### Advanced Programming Concepts

#### Pointer Parameter Passing
- **Pass by Reference**: Arrays passed as pointers (efficient)
- **Pass by Value**: Length parameter copied (safe)
- **No Array Copying**: Only addresses transferred
- **Memory Efficiency**: Constant space regardless of array size

#### Error Handling Strategy
```c
// Multiple failure modes handled:
if (ptr1 == NULL || ptr2 == NULL) return 0;  // Null pointers
if (*(ptr1 + i) != *(ptr2 + i)) return 0;    // Value mismatch
return 1;  // Success case
```

#### Algorithm Complexity
- **Time Complexity**: O(n) where n = length parameter
- **Space Complexity**: O(1) constant additional space
- **Best Case**: O(1) if first elements differ
- **Worst Case**: O(n) if arrays are identical

### Learning Objectives Achieved

#### Function Design Principles
1. ✅ **Single Responsibility**: Function has one clear purpose
2. ✅ **Parameter Validation**: Input checking for robustness
3. ✅ **Return Value Design**: Meaningful boolean return
4. ✅ **Error Handling**: Graceful failure management

#### Pointer Function Parameters
1. ✅ **Array Passing**: Understanding array-to-pointer decay
2. ✅ **Efficiency**: No array copying overhead
3. ✅ **Memory Access**: Pointer arithmetic in functions
4. ✅ **Type Safety**: Consistent pointer typing

#### Testing Methodology
1. ✅ **Comprehensive Cases**: Multiple scenarios covered
2. ✅ **Edge Cases**: Null pointer testing
3. ✅ **Boundary Testing**: Partial array comparison
4. ✅ **Error Conditions**: Invalid input handling

### Performance Analysis

#### Efficiency Considerations
- **Memory**: No array duplication, only pointer passing
- **CPU**: Linear scan with early termination optimization
- **Cache**: Sequential access pattern optimizes cache usage
- **Scalability**: Performance scales linearly with comparison length

#### Optimization Opportunities
```c
// Possible optimizations:
// 1. SIMD instructions for bulk comparison
// 2. Loop unrolling for small arrays
// 3. Compiler intrinsics for optimized comparison
```

### Real-World Applications
- **Data Validation**: Comparing expected vs. actual results
- **Unit Testing**: Automated test case validation
- **Data Structures**: Set equality operations
- **Memory Management**: Buffer content verification
- **Cryptography**: Secure comparison operations

### Common Use Cases Extended
```c
// String comparison (character arrays):
int compare_strings(char *str1, char *str2, int length);

// Structure comparison:
int compare_structs(struct data *s1, struct data *s2, int count);

// Generic comparison:
int compare_memory(void *ptr1, void *ptr2, size_t bytes);
```

### Integration with Course Objectives
- **Function Parameter Mastery**: Pointer vs. value parameters
- **Memory Efficiency**: Understanding reference passing
- **Error Handling**: Robust programming practices
- **Algorithm Design**: Efficient comparison strategies
- **Testing Methodology**: Comprehensive validation approaches