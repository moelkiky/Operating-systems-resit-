#include <stdio.h>

// Function to print a 2D array given a pointer, width, and height
void print_array(int *arr, int width, int height) {
    printf("2D Array (%dx%d):\n", height, width);
    
    for (int i = 0; i < height; i++) {
        for (int j = 0; j < width; j++) {
            // Use formula: arr[i * width + j] for element at position (i,j)
            printf("%4d ", *(arr + i * width + j));
        }
        printf("\n");
    }
    printf("\n");
}

int main() {
    printf("2D Array Printing Function Tests:\n");
    printf("=================================\n");
    
    // Test 1: 3x3 array
    printf("Test 1 - 3x3 Array:\n");
    int arr1[3][3] = {
        {1, 2, 3},
        {4, 5, 6},
        {7, 8, 9}
    };
    print_array((int*)arr1, 3, 3);
    
    // Test 2: 2x4 array
    printf("Test 2 - 2x4 Array:\n");
    int arr2[2][4] = {
        {10, 20, 30, 40},
        {50, 60, 70, 80}
    };
    print_array((int*)arr2, 4, 2);
    
    // Test 3: 4x2 array
    printf("Test 3 - 4x2 Array:\n");
    int arr3[4][2] = {
        {100, 200},
        {300, 400},
        {500, 600},
        {700, 800}
    };
    print_array((int*)arr3, 2, 4);
    
    // Test 4: 1x5 array (single row)
    printf("Test 4 - 1x5 Array (single row):\n");
    int arr4[1][5] = {
        {11, 22, 33, 44, 55}
    };
    print_array((int*)arr4, 5, 1);
    
    // Test 5: 5x1 array (single column)
    printf("Test 5 - 5x1 Array (single column):\n");
    int arr5[5][1] = {
        {111},
        {222},
        {333},
        {444},
        {555}
    };
    print_array((int*)arr5, 1, 5);
    
    // Demonstration of how the indexing works
    printf("Indexing Demonstration for 3x3 array:\n");
    printf("=====================================\n");
    printf("Position\tFormula\t\tValue\n");
    printf("--------\t-------\t\t-----\n");
    
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            int index = i * 3 + j;
            printf("(%d,%d)\t\t%d * 3 + %d = %d\t%d\n", 
                   i, j, i, j, index, *((int*)arr1 + index));
        }
    }
    
    return 0;
}