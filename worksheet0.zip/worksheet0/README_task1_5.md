# Task 1.5 - Generic Swap Function

## Overview
This task implements a universal swap function using void pointers and memory manipulation functions. The function can swap any data type by treating data as raw bytes, demonstrating advanced pointer concepts and type-agnostic programming.

## Problem Statement
Create a program that:
1. Implements a generic `swap(void *x, void *y, size_t size)` function
2. Can swap any data type (integers, floats, chars, arrays, etc.)
3. Uses `memcpy()` for safe memory operations
4. Demonstrates swapping with multiple data types
5. Shows the power of void pointers for generic programming

## Solution Approach

### Key Concepts Used
- **Void Pointers**: `void*` for type-agnostic parameters
- **Memory Manipulation**: `memcpy()` for byte-level copying
- **Size Parameter**: `size_t size` to specify data size
- **Temporary Buffer**: Local array for intermediate storage
- **Type Safety**: Caller responsible for passing correct size

### Implementation Details

#### Core Swap Function
```c
void swap(void *x, void *y, size_t size) {
    char temp[size];        // VLA (Variable Length Array) as temporary buffer
    
    memcpy(temp, x, size);  // temp = *x
    memcpy(x, y, size);     // *x = *y  
    memcpy(y, temp, size);  // *y = temp
}
```

#### Memory Operation Breakdown
```
Initial State:    x → [data_x]    y → [data_y]    temp → [garbage]
Step 1 (temp=x):  x → [data_x]    y → [data_y]    temp → [data_x]
Step 2 (x=y):     x → [data_y]    y → [data_y]    temp → [data_x]
Step 3 (y=temp):  x → [data_y]    y → [data_x]    temp → [data_x]
Final State:      x → [data_y]    y → [data_x]    temp → [data_x]
```

### Test Case Architecture

#### Multiple Data Type Tests
```c
// Test 1: Integer swap
int a = 10, b = 20;
swap(&a, &b, sizeof(int));

// Test 2: Float swap  
float x = 3.14f, y = 2.71f;
swap(&x, &y, sizeof(float));

// Test 3: Character swap
char c1 = 'A', c2 = 'Z';
swap(&c1, &c2, sizeof(char));

// Test 4: Double swap
double d1 = 123.456, d2 = 789.012;
swap(&d1, &d2, sizeof(double));

// Test 5: Array swap
int arr1[3] = {1, 2, 3};
int arr2[3] = {4, 5, 6};
swap(arr1, arr2, sizeof(arr1));
```

## Testing Methodology

### Compilation
```bash
clang -o task1_5 task1_5.c
```

### Execution
```bash
./task1_5
```

### Expected Output
```
Generic Swap Function Tests:
============================
Test 1 - Swapping integers:
Before swap: a = 10, b = 20
After swap:  a = 20, b = 10

Test 2 - Swapping floats:
Before swap: x = 3.14, y = 2.71
After swap:  x = 2.71, y = 3.14

Test 3 - Swapping characters:
Before swap: c1 = A, c2 = Z
After swap:  c1 = Z, c2 = A

Test 4 - Swapping doubles:
Before swap: d1 = 123.456, d2 = 789.012
After swap:  d1 = 789.012, d2 = 123.456

Test 5 - Swapping arrays:
Before swap: arr1 = {1, 2, 3}, arr2 = {4, 5, 6}
After swap:  arr1 = {4, 5, 6}, arr2 = {1, 2, 3}
```

## Test Results Analysis

### ✅ Successful Outcomes
1. **Integer Swap**: 10↔20 swapped correctly
2. **Float Swap**: 3.14↔2.71 swapped with proper precision
3. **Character Swap**: A↔Z swapped successfully
4. **Double Swap**: Large precision numbers swapped accurately
5. **Array Swap**: Entire arrays {1,2,3}↔{4,5,6} swapped completely

### Technical Validation
- **Memory Safety**: No buffer overflows or memory corruption
- **Type Agnostic**: Function works regardless of data type
- **Precision Preservation**: No loss of precision in floating-point swaps
- **Atomic Operation**: Each swap is completed entirely or not at all

## Advanced Concepts Demonstrated

### Void Pointer Mechanics
```c
void *x;  // Can point to any data type
// Cannot be dereferenced directly: *x (ERROR)
// Must cast or use memcpy for access
```

### Variable Length Arrays (VLA)
```c
char temp[size];  // Size determined at runtime
// Allocated on stack, automatically deallocated
// C99 feature for dynamic stack allocation
```

### Memory Copy Operations
```c
memcpy(dest, src, size);
// Copies 'size' bytes from src to dest
// Handles overlapping memory safely
// More efficient than byte-by-byte copying
```

### Generic Programming Pattern
```c
// Traditional type-specific functions
void swap_int(int *a, int *b);
void swap_float(float *a, float *b);
void swap_char(char *a, char *b);

// Generic approach (used here)
void swap(void *x, void *y, size_t size);
```

## Memory Layout Analysis

### Stack Frame During Swap
```
Stack Layout:
[temp buffer: size bytes]  ← VLA allocation
[size: 8 bytes]           ← size_t parameter  
[y: 8 bytes]              ← void* parameter
[x: 8 bytes]              ← void* parameter
[return address]          ← function call overhead
```

### Memory Copy Visualization (4-byte int)
```
Before: x→[10][00][00][00]  y→[20][00][00][00]  temp→[??][??][??][??]
Step 1: x→[10][00][00][00]  y→[20][00][00][00]  temp→[10][00][00][00]
Step 2: x→[20][00][00][00]  y→[20][00][00][00]  temp→[10][00][00][00] 
Step 3: x→[20][00][00][00]  y→[10][00][00][00]  temp→[10][00][00][00]
```

## Performance Characteristics

### Time Complexity
- **O(n)** where n is the size in bytes
- **3 × memcpy operations**: Each taking O(n) time
- **Constant overhead**: Function call and VLA allocation

### Space Complexity
- **O(n)** for temporary buffer
- **Stack allocation**: No heap fragmentation
- **Automatic cleanup**: VLA deallocated on function exit

### Optimization Considerations
```c
// For small, fixed-size types, compiler may optimize to:
// Register-based swapping for sizeof(int), sizeof(float)
// SIMD instructions for larger aligned data
// Inline expansion for frequently used sizes
```

## Practical Applications

### Generic Data Structures
```c
// Generic sorting algorithms
void qsort(void *base, size_t nmemb, size_t size, 
           int (*compar)(const void *, const void *));

// Generic stack operations  
void stack_swap_top_two(Stack *s, size_t element_size);
```

### System Programming
- **Buffer manipulation**: Swapping network packet contents
- **Memory pool management**: Swapping allocated blocks
- **Device drivers**: Swapping hardware register contents

### Algorithm Implementation
- **Sorting algorithms**: Generic bubble sort, quick sort partitioning
- **Graph algorithms**: Swapping vertex data
- **String processing**: Swapping character sequences

## Safety Considerations

### Potential Pitfalls
```c
// WRONG: Inconsistent sizes
int a = 5; 
double b = 3.14;
swap(&a, &b, sizeof(int));  // Only swaps 4 bytes of 8-byte double

// WRONG: Uninitialized pointers
int *p1, *p2;
swap(p1, p2, sizeof(int));  // Undefined behavior

// CORRECT: Matching types and sizes
int a = 5, b = 10;
swap(&a, &b, sizeof(int));
```

### Best Practices
1. **Size Consistency**: Always pass correct size for both operands
2. **Type Matching**: Only swap data of the same type/size
3. **Pointer Validation**: Ensure pointers are valid before calling
4. **Alignment Considerations**: Be aware of structure padding

## Alternative Implementations

### Macro-based Approach
```c
#define SWAP(x, y, T) do { \
    T temp = x; \
    x = y; \
    y = temp; \
} while(0)
```

### Template-based (C++ style concept)
```c
// Not available in C, but conceptually:
template<typename T>
void swap(T& a, T& b) {
    T temp = a;
    a = b; 
    b = temp;
}
```

## Compilation and Portability

### C99 Features Used
- **Variable Length Arrays**: `char temp[size]`
- **size_t type**: Standard integer type for sizes
- **memcpy function**: Standard library memory operation

### Platform Compatibility
- **Works on**: Linux, macOS, Windows, embedded systems
- **Requires**: C99 or later compiler support
- **Dependencies**: `<string.h>` for memcpy, `<stdio.h>` for testing

### Compiler Optimizations
- **Inlining**: Small sizes may be inlined by compiler
- **SIMD**: Large aligned data may use vector instructions
- **Register allocation**: Temporary buffer may use registers for small sizes