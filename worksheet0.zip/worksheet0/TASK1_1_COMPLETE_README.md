# TASK 1.1 - BASIC POINTER OPERATIONS

## Overview
This program demonstrates fundamental pointer concepts in C programming, including pointer declaration, dereferencing, address operations, and pointer-based variable modification.

## File: task1_1.c

### Program Logic

#### Variable Declaration
```c
int n = 10;                    // Declare integer variable with initial value
int *ptr_to_n = &n;           // Create pointer pointing to address of n
```

**Key Concepts:**
- `int n = 10` - Direct variable declaration and initialization
- `int *ptr_to_n` - Pointer variable declaration (stores memory addresses)
- `&n` - Address-of operator (gets memory address of variable n)

#### Memory Address Operations
```c
printf("Address of n: %p\n", (void*)&n);
printf("Value of ptr_to_n (address it points to): %p\n", (void*)ptr_to_n);
```

**Demonstrated Concepts:**
- **Address-of operator (&)**: Gets memory address of a variable
- **Pointer value**: Shows the address stored in the pointer
- **Address comparison**: Both should show the same memory address

#### Pointer Dereferencing and Modification
```c
(*ptr_to_n)++;                 // Increment value through pointer
```

**Key Operations:**
- `*ptr_to_n` - Dereference operator (accesses value at pointer address)
- `(*ptr_to_n)++` - Increment the value that the pointer points to
- Parentheses ensure correct operator precedence

### Build Instructions

#### Compilation
```bash
clang -o task1_1 task1_1.c
```

#### Execution
```bash
./task1_1
```

### Expected Output
```
Original value of n: 10
Address of n: 0x7fff5fbff6ac
New value of n: 11
Value accessed through pointer: 11
```

**Output Explanation:**
- Memory addresses will vary between runs (ASLR - Address Space Layout Randomization)
- Both address values should be identical (pointer points to same location)
- Value changes from 10 to 11 after pointer-based increment

### Technical Analysis

#### Memory Layout
```
Stack Memory:
┌─────────────────┐
│ n = 10 → 11     │ ← Variable storage
│ (address: 0x7f..)│
└─────────────────┘
┌─────────────────┐
│ ptr_to_n        │ ← Pointer storage
│ = 0x7f.. (addr) │   (contains address of n)
└─────────────────┘
```

#### Pointer Arithmetic Flow
1. **Initialization**: `ptr_to_n` stores address of `n`
2. **Dereference**: `*ptr_to_n` accesses value at stored address
3. **Modification**: `++` operator increments the dereferenced value
4. **Verification**: Both `n` and `*ptr_to_n` show same updated value

### Learning Objectives Achieved

#### Core Pointer Concepts
1. ✅ **Pointer Declaration**: `int *ptr` syntax
2. ✅ **Address-of Operator**: `&variable` usage
3. ✅ **Dereference Operator**: `*pointer` usage
4. ✅ **Indirect Modification**: Changing variables through pointers

#### Memory Understanding
1. ✅ **Address Visualization**: Seeing actual memory addresses
2. ✅ **Pointer-Variable Relationship**: Understanding the connection
3. ✅ **Memory Access Patterns**: Direct vs. indirect access

### Testing Verification

#### Test 1: Address Consistency
- Both `&n` and `ptr_to_n` should show identical addresses
- Demonstrates pointer correctly stores variable address

#### Test 2: Value Modification
- Original value: 10
- After increment: 11
- Proves pointer-based modification affects original variable

#### Test 3: Access Equivalence
- `n` and `*ptr_to_n` show same value after modification
- Confirms pointer dereference accesses correct memory location

### Common Concepts Demonstrated

#### Operator Precedence
```c
(*ptr_to_n)++     // Correct: dereference first, then increment
*ptr_to_n++       // Wrong: would increment pointer, then dereference
```

#### Type Safety
```c
int *ptr_to_n     // Pointer specifically typed for integers
(void*)&n         // Cast to void* for printf %p format specifier
```

### Real-World Applications
- **Function Parameters**: Pass-by-reference simulation
- **Dynamic Memory**: Foundation for malloc/free operations
- **Data Structures**: Building linked lists, trees
- **Performance**: Avoiding large data copying

### Integration with Course
- Foundation for more complex pointer operations
- Prerequisite for array manipulation tasks
- Essential for understanding memory management
- Basis for function parameter passing techniques

### Debugging Tips
- Use `printf` with `%p` to visualize addresses
- Check that pointer and variable addresses match
- Verify value changes occur in both variable and pointer access
- Watch for segmentation faults (accessing invalid memory)