# Task 1.2 - Array Pointer Iteration

## Overview
This task demonstrates how to iterate through arrays using pointer arithmetic instead of traditional array indexing. It showcases two different approaches to traverse array elements using pointers.

## Problem Statement
Create a program that:
1. Declares an array with 3 elements: {10, 30, 2000}
2. Uses a pointer to iterate through the array
3. Displays each element's value and memory address
4. Demonstrates two different pointer iteration techniques

## Solution Approach

### Key Concepts Used
- **Array-to-Pointer Conversion**: `int *ptr = arr` (arr decays to pointer)
- **Pointer Arithmetic**: `*(ptr + i)` to access elements
- **Pointer Increment**: `ptr++` to move to next element
- **Address Calculation**: `(void*)(ptr + i)` for memory addresses
- **Array Equivalence**: `arr[i] ≡ *(arr + i) ≡ *(ptr + i)`

### Implementation Details

#### Method 1: Pointer Arithmetic with Index
```c
int arr[3] = {10, 30, 2000};
int *ptr = arr;  // Array name decays to pointer to first element

for (int i = 0; i < 3; i++) {
    printf("arr[%d]\t%d\t%p\n", i, *(ptr + i), (void*)(ptr + i));
}
```

#### Method 2: Pointer Increment
```c
ptr = arr;  // Reset pointer to beginning
for (int i = 0; i < 3; i++) {
    printf("arr[%d]\t%d\t%p\n", i, *ptr, (void*)ptr);
    ptr++;  // Move pointer to next element
}
```

### Memory Layout
```
Index  Address      Value   Pointer Offset
[0]    0x7fff1000   10      ptr + 0
[1]    0x7fff1004   30      ptr + 1  (ptr + 4 bytes)
[2]    0x7fff1008   2000    ptr + 2  (ptr + 8 bytes)
```

## Testing Methodology

### Compilation
```bash
clang -o task1_2 task1_2.c
```

### Execution
```bash
./task1_2
```

### Expected Output
```
Array elements using pointer iteration:
Element	Value	Address
-------	-----	-------
arr[0]	10	0x7ffd9bc96840
arr[1]	30	0x7ffd9bc96844
arr[2]	2000	0x7ffd9bc96848

Alternative approach using pointer increment:
Element	Value	Address
-------	-----	-------
arr[0]	10	0x7ffd9bc96840
arr[1]	30	0x7ffd9bc96844
arr[2]	2000	0x7ffd9bc96848
```

## Test Results Analysis

### ✅ Successful Outcomes
1. **Array-to-Pointer Decay**: Successfully converted array to pointer
2. **Sequential Memory**: Addresses show 4-byte intervals (sizeof(int))
3. **Pointer Arithmetic**: Both `*(ptr + i)` and array indexing produce identical results
4. **Memory Consistency**: Both methods show identical addresses for same elements
5. **Proper Iteration**: All three elements accessed correctly in sequence

### Technical Details
- **Address Spacing**: Each integer occupies 4 bytes (32-bit integers)
- **Pointer Arithmetic**: `ptr + 1` advances by `sizeof(int)` bytes automatically
- **Type Safety**: Compiler handles byte calculations based on pointer type

### Key Learning Points
- Array names are equivalent to pointers to their first element
- Pointer arithmetic automatically scales by the size of the pointed type
- `arr[i]`, `*(arr + i)`, and `*(ptr + i)` are mathematically equivalent
- Incrementing a pointer moves it to the next element, not the next byte
- Memory addresses increment by `sizeof(data_type)` for each element

### Performance Considerations
- **Method 1**: More readable, allows random access
- **Method 2**: Potentially faster for sequential access (fewer calculations)
- **Compiler Optimization**: Modern compilers often optimize both to identical assembly

## Advanced Concepts Demonstrated

### Pointer Arithmetic Rules
```c
ptr + i  ≡  ptr + (i * sizeof(*ptr))
*(ptr + i)  ≡  ptr[i]  ≡  i[ptr]  // Last one is valid but not recommended
```

### Memory Address Calculation
```c
&arr[i]  ≡  arr + i  ≡  ptr + i
```

## Practical Applications
This knowledge is fundamental for:
- Efficient array processing algorithms
- String manipulation functions
- Dynamic memory management
- Buffer operations in system programming
- Implementing custom data structures

## Safety Considerations
- No bounds checking performed (C doesn't provide automatic bounds checking)
- Pointer must be reset to array start for second iteration
- Accessing beyond array bounds leads to undefined behavior

## Compilation Notes
- Compiles with no warnings using `-Wall -Wextra`
- Uses only standard C library functions
- Portable across different architectures
- Demonstrates low-level memory access patterns