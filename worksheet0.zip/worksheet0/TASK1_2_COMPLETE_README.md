# TASK 1.2 - ARRAY POINTER ITERATION

## Overview
This program demonstrates advanced pointer arithmetic concepts including array-pointer relationships, pointer iteration, pointer arithmetic operations, and memory address calculation patterns.

## File: task1_2.c

### Program Logic

#### Array Declaration and Initialization
```c
int arr[3] = {10, 30, 2000};   // Array with 3 integer elements
int *ptr = arr;                // Pointer to first element (arr == &arr[0])
```

**Key Concepts:**
- `arr[3]` - Static array declaration with size specification
- `{10, 30, 2000}` - Array initialization with literal values
- `int *ptr = arr` - Array name decays to pointer to first element
- Array-pointer equivalence: `arr` is identical to `&arr[0]`

#### Pointer Arithmetic Method 1
```c
for (int i = 0; i < 3; i++) {
    printf("arr[%d]\t%d\t%p\n", i, *(ptr + i), (void*)(ptr + i));
}
```

**Demonstrated Operations:**
- `*(ptr + i)` - Pointer arithmetic with dereference
- `(ptr + i)` - Address calculation: base_address + (i * sizeof(int))
- Index-based pointer arithmetic without modifying original pointer

#### Pointer Increment Method 2
```c
ptr = arr;                     // Reset pointer to array start
for (int i = 0; i < 3; i++) {
    printf("arr[%d]\t%d\t%p\n", i, *ptr, (void*)ptr);
    ptr++;                     // Increment pointer to next element
}
```

**Advanced Concepts:**
- `ptr++` - Post-increment pointer arithmetic
- Pointer state modification during iteration
- Sequential memory traversal pattern

### Build Instructions

#### Compilation
```bash
clang -o task1_2 task1_2.c
```

#### Execution
```bash
./task1_2
```

### Expected Output
```
Array elements using pointer iteration:
Element	Value	Address
-------	-----	-------
arr[0]	10	0x7fff5fbff6a0
arr[1]	30	0x7fff5fbff6a4
arr[2]	2000	0x7fff5fbff6a8

Alternative approach using pointer increment:
Element	Value	Address
-------	-----	-------
arr[0]	10	0x7fff5fbff6a0
arr[1]	30	0x7fff5fbff6a4
arr[2]	2000	0x7fff5fbff6a8
```

**Output Analysis:**
- Addresses increment by 4 bytes (sizeof(int) on 64-bit systems)
- Both methods produce identical results
- Sequential memory layout demonstrated
- Hexadecimal address progression shows contiguous allocation

### Technical Deep Dive

#### Memory Layout Visualization
```
Memory Layout (32-bit integers):
┌─────────────────┐ 0x7fff5fbff6a0
│ arr[0] = 10     │
├─────────────────┤ 0x7fff5fbff6a4 (+4 bytes)
│ arr[1] = 30     │
├─────────────────┤ 0x7fff5fbff6a8 (+4 bytes)
│ arr[2] = 2000   │
└─────────────────┘ 0x7fff5fbff6ac
```

#### Pointer Arithmetic Mathematics
```c
// For int array (4-byte elements):
ptr + 0 = base_address + (0 * 4) = base_address
ptr + 1 = base_address + (1 * 4) = base_address + 4
ptr + 2 = base_address + (2 * 4) = base_address + 8
```

#### Array-Pointer Equivalences
```c
arr[i]    ≡  *(arr + i)    ≡  *(ptr + i)
&arr[i]   ≡  (arr + i)     ≡  (ptr + i)
arr       ≡  &arr[0]       ≡  ptr (when ptr = arr)
```

### Advanced Pointer Concepts

#### Method Comparison

**Method 1: Offset-Based Access**
- **Advantages**: Preserves original pointer value, safer for reuse
- **Use Case**: Random access patterns, multiple iterations
- **Performance**: Calculation overhead for each access

**Method 2: Increment-Based Access**
- **Advantages**: More efficient, natural sequential access
- **Use Case**: Single-pass algorithms, streaming data
- **Limitation**: Modifies pointer state, requires reset for reuse

#### Type-Safe Pointer Arithmetic
```c
int *ptr = arr;           // Type-specific pointer
ptr + 1;                  // Advances by sizeof(int) bytes automatically
// vs.
char *byte_ptr = (char*)arr;
byte_ptr + 1;             // Advances by 1 byte only
```

### Learning Objectives Achieved

#### Pointer Arithmetic Mastery
1. ✅ **Offset Calculation**: `*(ptr + i)` syntax understanding
2. ✅ **Pointer Increment**: `ptr++` operation mechanics
3. ✅ **Address Arithmetic**: Size-aware pointer mathematics
4. ✅ **Type Scaling**: Automatic size multiplication based on pointer type

#### Array Understanding
1. ✅ **Array Decay**: Array name to pointer conversion
2. ✅ **Memory Layout**: Contiguous element storage
3. ✅ **Index Equivalence**: `arr[i]` vs `*(arr + i)`
4. ✅ **Address Patterns**: Sequential memory allocation

### Testing Verification

#### Test 1: Address Progression
- Each address should be exactly 4 bytes apart
- Demonstrates proper integer array memory layout
- Confirms compiler padding/alignment behavior

#### Test 2: Value Accuracy
- Values should match initialization: 10, 30, 2000
- Both methods should produce identical output
- Verifies pointer arithmetic correctness

#### Test 3: Method Equivalence
- Both iteration approaches show same addresses
- Same values retrieved through different pointer techniques
- Proves mathematical equivalence of approaches

### Performance Considerations

#### Cache Efficiency
- Sequential access pattern optimizes CPU cache usage
- Prefetching benefits from predictable memory access
- Spatial locality principle demonstration

#### Compiler Optimizations
- Loop unrolling possibilities
- Pointer arithmetic optimization
- Strength reduction (multiplication to addition)

### Common Pitfalls and Solutions

#### Pointer Reset Requirement
```c
// Problem: Pointer modified by increment
ptr = arr;  // Solution: Reset before second iteration
```

#### Bounds Checking
```c
// Always verify array bounds
for (int i = 0; i < 3; i++)  // Correct: explicit size check
```

#### Type Consistency
```c
int *ptr = arr;              // Correct: matching types
// void *ptr = arr;          // Requires casting for arithmetic
```

### Real-World Applications
- **String Processing**: Character array traversal
- **Image Processing**: Pixel data manipulation
- **Data Parsing**: Sequential data structure processing
- **Memory Management**: Dynamic array implementations

### Integration with Course Objectives
- Foundation for dynamic memory allocation
- Prerequisite for linked data structures
- Essential for function parameter passing
- Basis for algorithm implementation efficiency