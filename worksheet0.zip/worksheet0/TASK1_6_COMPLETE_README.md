# TASK 1.6 - 2D ARRAY POINTER ARITHMETIC

## Overview
This program demonstrates advanced 2D array manipulation using pointer arithmetic, multi-dimensional array indexing, memory layout understanding, and generic array printing with comprehensive testing across various array dimensions.

## File: task1_6.c

### Program Architecture

#### Generic 2D Array Function
```c
void print_array(int *arr, int width, int height);
```

**Function Design:**
- `int *arr` - Flattened pointer to 2D array data (linearized memory)
- `int width` - Number of columns in the 2D array
- `int height` - Number of rows in the 2D array
- Generic approach works with any rectangular integer array

#### Core Indexing Algorithm
```c
*(arr + i * width + j)  // Access element at position (i,j)
```

**Mathematical Formula:**
- **Row-major order**: Elements stored row by row in memory
- **Linear index**: `i * width + j` converts 2D coordinates to 1D offset
- **Memory address**: Base address + (linear index × sizeof(int))
- **Universal formula**: Works for any width/height combination

#### 2D Array Casting
```c
print_array((int*)arr1, 3, 3);  // Cast 2D array to 1D pointer
```

**Memory Layout Conversion:**
- 2D array `int arr[3][3]` stored as contiguous memory block
- Cast `(int*)` converts 2D array name to flat pointer
- Preserves memory layout while changing access method
- Enables generic function to handle various array sizes

### Test Suite Analysis

#### Test 1: Square Array (3×3)
```c
int arr1[3][3] = {{1,2,3}, {4,5,6}, {7,8,9}};
```
**Memory Layout:**
```
[1][2][3][4][5][6][7][8][9]  ← Linear memory
 0  1  2  3  4  5  6  7  8   ← Indices
```

#### Test 2: Rectangular Array (2×4)
```c
int arr2[2][4] = {{10,20,30,40}, {50,60,70,80}};
```
**Index Calculation Examples:**
- Position (0,0): 0×4+0 = 0 → value 10
- Position (0,3): 0×4+3 = 3 → value 40  
- Position (1,0): 1×4+0 = 4 → value 50
- Position (1,3): 1×4+3 = 7 → value 80

#### Test 3: Tall Array (4×2)
```c
int arr3[4][2] = {{100,200}, {300,400}, {500,600}, {700,800}};
```

#### Test 4: Single Row (1×5)
```c
int arr4[1][5] = {{11,22,33,44,55}};
```

#### Test 5: Single Column (5×1)
```c
int arr5[5][1] = {{111}, {222}, {333}, {444}, {555}};
```

### Build Instructions

#### Compilation
```bash
clang -o task1_6 task1_6.c
```

#### Execution
```bash
./task1_6
```

### Expected Output
```
2D Array Printing Function Tests:
=================================
Test 1 - 3x3 Array:
2D Array (3x3):
   1    2    3 
   4    5    6 
   7    8    9 

Test 2 - 2x4 Array:
2D Array (2x4):
  10   20   30   40 
  50   60   70   80 

Test 3 - 4x2 Array:
2D Array (4x2):
 100  200 
 300  400 
 500  600 
 700  800 

Test 4 - 1x5 Array (single row):
2D Array (1x5):
  11   22   33   44   55 

Test 5 - 5x1 Array (single column):
2D Array (5x1):
 111 
 222 
 333 
 444 
 555 

Indexing Demonstration for 3x3 array:
=====================================
Position	Formula		Value
--------	-------		-----
(0,0)		0 * 3 + 0 = 0	1
(0,1)		0 * 3 + 1 = 1	2
(0,2)		0 * 3 + 2 = 2	3
(1,0)		1 * 3 + 0 = 3	4
(1,1)		1 * 3 + 1 = 4	5
(1,2)		1 * 3 + 2 = 5	6
(2,0)		2 * 3 + 0 = 6	7
(2,1)		2 * 3 + 1 = 7	8
(2,2)		2 * 3 + 2 = 8	9
```

### Technical Deep Dive

#### Memory Layout Understanding
```
2D Array Conceptual View:    Physical Memory Layout:
┌─────┬─────┬─────┐         ┌─────┬─────┬─────┬─────┬─────┬─────┬─────┬─────┬─────┐
│  1  │  2  │  3  │         │  1  │  2  │  3  │  4  │  5  │  6  │  7  │  8  │  9  │
├─────┼─────┼─────┤    →    └─────┴─────┴─────┴─────┴─────┴─────┴─────┴─────┴─────┘
│  4  │  5  │  6  │           0     4     8    12    16    20    24    28    32
├─────┼─────┼─────┤         (byte addresses for 4-byte integers)
│  7  │  8  │  9  │
└─────┴─────┴─────┘
```

#### Row-Major Order Calculation
```c
// For array[height][width]:
// Element at (row, col) = base_address + (row * width + col) * sizeof(element)

// Examples for 3x3 array:
arr[0][0] = arr + (0 * 3 + 0) = arr + 0  // First element
arr[1][2] = arr + (1 * 3 + 2) = arr + 5  // Middle of second row
arr[2][2] = arr + (2 * 3 + 2) = arr + 8  // Last element
```

#### Pointer Arithmetic Mechanics
```c
int *ptr = (int*)arr;
*(ptr + i * width + j)  // Equivalent to arr[i][j]
```

**Address Calculation:**
- `ptr + offset` advances pointer by `offset * sizeof(int)` bytes
- `i * width + j` converts 2D coordinates to linear offset
- `*()` dereferences to get actual value

### Advanced Programming Concepts

#### Array Dimension Flexibility
```c
// Same function handles different array sizes:
print_array((int*)arr_3x3, 3, 3);   // Square
print_array((int*)arr_2x4, 4, 2);   // Wide rectangle
print_array((int*)arr_4x2, 2, 4);   // Tall rectangle
print_array((int*)arr_1x5, 5, 1);   // Single row
print_array((int*)arr_5x1, 1, 5);   // Single column
```

#### Generic Array Processing
```c
// Function works with any rectangular array:
void process_2d_array(int *arr, int width, int height) {
    for (int i = 0; i < height; i++) {
        for (int j = 0; j < width; j++) {
            int value = *(arr + i * width + j);
            // Process each element generically
        }
    }
}
```

#### Memory Access Patterns
```c
// Row-wise access (cache-friendly):
for (int i = 0; i < height; i++) {
    for (int j = 0; j < width; j++) {
        process(*(arr + i * width + j));
    }
}

// Column-wise access (less cache-friendly):
for (int j = 0; j < width; j++) {
    for (int i = 0; i < height; i++) {
        process(*(arr + i * width + j));
    }
}
```

### Learning Objectives Achieved

#### Multi-dimensional Array Concepts
1. ✅ **Memory Layout**: Understanding row-major storage order
2. ✅ **Index Mapping**: Converting 2D coordinates to linear indices
3. ✅ **Pointer Casting**: Converting 2D arrays to 1D pointers
4. ✅ **Generic Processing**: Single function for various array sizes

#### Advanced Pointer Arithmetic
1. ✅ **Complex Expressions**: `*(arr + i * width + j)` breakdown
2. ✅ **Mathematical Mapping**: Formula derivation and application
3. ✅ **Memory Address Calculation**: Understanding pointer offset math
4. ✅ **Type-Safe Arithmetic**: Working with typed pointer increments

#### Software Design Principles
1. ✅ **Function Genericity**: Parameterized width/height handling
2. ✅ **Interface Design**: Clean, intuitive function signatures
3. ✅ **Testing Coverage**: Multiple array configurations validated
4. ✅ **Documentation**: Clear formula explanation and examples

### Performance Analysis

#### Cache Efficiency
- **Row-major access**: Optimal memory locality (sequential access)
- **Cache line utilization**: Adjacent elements loaded together
- **Prefetching benefits**: Predictable access patterns
- **Memory bandwidth**: Efficient utilization of available bandwidth

#### Time Complexity
- **Array traversal**: O(width × height) for complete processing
- **Element access**: O(1) for individual element lookup
- **Index calculation**: O(1) arithmetic operations
- **Memory access**: O(1) with potential cache effects

#### Space Complexity
- **No additional storage**: In-place array processing
- **Stack usage**: O(1) for function variables
- **Memory efficiency**: Direct pointer arithmetic (no intermediate arrays)

### Real-World Applications

#### Image Processing
```c
// Process 2D image data:
void process_image(int *pixels, int width, int height) {
    for (int y = 0; y < height; y++) {
        for (int x = 0; x < width; x++) {
            int pixel = *(pixels + y * width + x);
            // Apply filters, transformations, etc.
        }
    }
}
```

#### Matrix Mathematics
```c
// Generic matrix operations:
void matrix_multiply(int *a, int *b, int *result, int rows, int cols, int inner);
void matrix_transpose(int *src, int *dst, int rows, int cols);
void matrix_add(int *a, int *b, int *result, int rows, int cols);
```

#### Game Development
```c
// 2D game board processing:
void update_game_board(int *board, int width, int height);
int check_win_condition(int *board, int width, int height);
void render_board(int *board, int width, int height);
```

### Common Applications Extended

#### Scientific Computing
- **Numerical simulations**: 2D grids for physics calculations
- **Data analysis**: Processing experimental data matrices
- **Signal processing**: 2D convolution operations
- **Computer graphics**: Texture and framebuffer manipulation

### Integration with Course Objectives
- **Memory Management**: Understanding multi-dimensional data layout
- **Pointer Mastery**: Complex arithmetic expressions and dereferencing
- **Algorithm Design**: Efficient 2D data structure traversal
- **Generic Programming**: Creating flexible, reusable functions
- **Performance Optimization**: Cache-conscious programming techniques