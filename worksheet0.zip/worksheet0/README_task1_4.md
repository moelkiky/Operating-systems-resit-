# Task 1.4 - File Reading and Sum Calculation

## Overview
This task demonstrates file I/O operations in C by reading integers from a text file and calculating their sum. It includes proper error handling for file operations and validates the expected results from the worksheet.

## Problem Statement
Create a program that:
1. Opens and reads from a file named "foo.txt"
2. Reads integers from the file line by line
3. Calculates the sum of all integers
4. Displays each number found and the final sum
5. Handles file access errors gracefully

## Solution Approach

### Key Concepts Used
- **File I/O Operations**: `fopen()`, `fscanf()`, `fclose()`
- **Error Handling**: Check for NULL file pointer
- **Input Validation**: Verify `fscanf()` return value
- **Resource Management**: Proper file closure
- **Accumulator Pattern**: Running sum calculation

### Implementation Details

#### File Structure (foo.txt)
```
10
20
30
40
54
```

#### Core Reading Logic
```c
FILE *file;
int number, sum = 0, count = 0;

file = fopen("foo.txt", "r");
if (file == NULL) {
    printf("Error: Could not open file foo.txt\n");
    return 1;
}

while (fscanf(file, "%d", &number) == 1) {
    printf("%d ", number);
    sum += number;
    count++;
}

fclose(file);
```

### Error Handling Strategy
- **File Access Check**: Verify `fopen()` doesn't return NULL
- **Read Validation**: Check `fscanf()` return value (1 = successful read)
- **Graceful Degradation**: Provide helpful error messages
- **Resource Cleanup**: Always close file, even on error

## Testing Methodology

### File Preparation
```bash
# The foo.txt file contains:
echo -e "10\n20\n30\n40\n54" > foo.txt
```

### Compilation
```bash
clang -o task1_4 task1_4.c
```

### Execution
```bash
./task1_4
```

### Expected Output
```
Reading numbers from foo.txt:
Numbers found: 10 20 30 40 54 

Results:
--------
Total numbers read: 5
Sum of all numbers: 154
```

## Test Results Analysis

### ✅ Successful Outcomes
1. **File Opening**: Successfully opens foo.txt for reading
2. **Number Reading**: Correctly reads all 5 integers from the file
3. **Sum Calculation**: Accurately calculates sum: 10+20+30+40+54 = 154
4. **Count Tracking**: Properly counts the number of integers read
5. **File Closure**: Cleanly closes the file after reading

### Mathematical Verification
```
Expected Sum: 10 + 20 + 30 + 40 + 54 = 154
Actual Sum:   154 ✅
Expected Count: 5 numbers
Actual Count:   5 ✅
```

### File I/O Mechanics
- **Sequential Reading**: Processes file line by line
- **Automatic Whitespace Handling**: `fscanf("%d")` skips whitespace
- **EOF Detection**: Loop terminates when no more integers can be read
- **Buffer Management**: Operating system handles file buffering

## Advanced Concepts Demonstrated

### File Pointer Management
```c
FILE *file;           // Declare file pointer
file = fopen("foo.txt", "r");  // Open for reading
// ... use file ...
fclose(file);         // Release file resources
```

### Input Validation Pattern
```c
while (fscanf(file, "%d", &number) == 1) {
    // fscanf returns 1 when it successfully reads one integer
    // Returns 0 if it can't parse an integer
    // Returns EOF (-1) at end of file
}
```

### Error Handling Best Practices
```c
if (file == NULL) {
    printf("Error: Could not open file foo.txt\n");
    printf("Make sure the file exists in the current directory.\n");
    return 1;  // Exit with error code
}
```

## Edge Cases and Error Scenarios

### Handled Cases
1. **File Not Found**: Displays error message and exits gracefully
2. **Permission Denied**: Handles when file exists but can't be read
3. **Empty File**: Would display count=0, sum=0
4. **Invalid Data**: `fscanf()` would fail and loop would terminate

### Potential Improvements
```c
// Enhanced error checking
if (ferror(file)) {
    printf("Error occurred while reading file\n");
}

// Check for non-integer data
int result = fscanf(file, "%d", &number);
if (result == 0) {
    printf("Warning: Non-integer data found\n");
}
```

## File Format Requirements
- **Plain Text**: ASCII/UTF-8 encoded
- **One Integer Per Line**: Separated by newlines
- **No Comments**: Pure numeric data
- **Optional Whitespace**: Leading/trailing spaces ignored

## Practical Applications
This file reading pattern is used in:
- **Configuration Files**: Reading settings and parameters
- **Data Processing**: Batch processing of numeric datasets
- **Log Analysis**: Extracting numeric values from log files
- **Scientific Computing**: Loading experimental data
- **System Administration**: Processing system metrics

## Memory Management
- **Stack-based Variables**: All variables are automatic (stack-allocated)
- **No Dynamic Allocation**: No `malloc()` or `free()` required
- **File Buffer Management**: Handled automatically by C standard library
- **Resource Cleanup**: File handle properly closed

## Performance Characteristics
- **Time Complexity**: O(n) where n is the number of integers in file
- **Space Complexity**: O(1) - constant space usage
- **I/O Efficiency**: Uses buffered I/O for optimal performance
- **Memory Usage**: Minimal - only stores current number and running sum

## Compilation and Portability
- **Standard C Library**: Uses only `<stdio.h>` and `<stdlib.h>`
- **Platform Independent**: Works on Unix, Linux, Windows, macOS
- **No External Dependencies**: Self-contained program
- **C99 Compatible**: Uses standard C99 features only

## Security Considerations
- **Buffer Safety**: `fscanf()` with `%d` is safe from buffer overflows
- **Input Validation**: Checks file operations return values
- **Resource Leaks**: Proper file closure prevents resource leaks
- **Error Propagation**: Returns appropriate exit codes