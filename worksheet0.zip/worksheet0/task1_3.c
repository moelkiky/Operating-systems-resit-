#include <stdio.h>

// Function to compare two arrays
int compare_arrays(int *ptr1, int *ptr2, int length) {
    // Check for null pointers
    if (ptr1 == NULL || ptr2 == NULL) {
        return 0;  // Return false if either pointer is null
    }
    
    // Compare arrays element by element
    for (int i = 0; i < length; i++) {
        if (*(ptr1 + i) != *(ptr2 + i)) {
            return 0;  // Return false if any elements differ
        }
    }
    
    return 1;  // Return true if all elements are equal
}

int main() {
    // Test arrays
    int arr1[] = {1, 2, 3, 4, 5};
    int arr2[] = {1, 2, 3, 4, 5};
    int arr3[] = {1, 2, 3, 4, 6};
    int arr4[] = {10, 20, 30};
    
    printf("Array Comparison Tests:\n");
    printf("======================\n");
    
    // Test 1: Identical arrays
    printf("Test 1 - arr1 vs arr2 (identical): ");
    if (compare_arrays(arr1, arr2, 5)) {
        printf("Arrays are EQUAL\n");
    } else {
        printf("Arrays are DIFFERENT\n");
    }
    
    // Test 2: Different arrays (same length)
    printf("Test 2 - arr1 vs arr3 (different): ");
    if (compare_arrays(arr1, arr3, 5)) {
        printf("Arrays are EQUAL\n");
    } else {
        printf("Arrays are DIFFERENT\n");
    }
    
    // Test 3: Partial comparison
    printf("Test 3 - arr1 vs arr3 (first 4 elements): ");
    if (compare_arrays(arr1, arr3, 4)) {
        printf("Arrays are EQUAL\n");
    } else {
        printf("Arrays are DIFFERENT\n");
    }
    
    // Test 4: Different arrays (different lengths)
    printf("Test 4 - arr1 vs arr4 (first 3 elements): ");
    if (compare_arrays(arr1, arr4, 3)) {
        printf("Arrays are EQUAL\n");
    } else {
        printf("Arrays are DIFFERENT\n");
    }
    
    // Test 5: Null pointer test
    printf("Test 5 - arr1 vs NULL: ");
    if (compare_arrays(arr1, NULL, 5)) {
        printf("Arrays are EQUAL\n");
    } else {
        printf("Arrays are DIFFERENT (null pointer detected)\n");
    }
    
    return 0;
}