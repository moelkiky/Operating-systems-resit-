#include <stdio.h>

int main() {
    // Declare an integer variable n
    int n = 10;
    
    // Create a pointer ptr_to_n that points to n
    int *ptr_to_n = &n;
    
    printf("Original value of n: %d\n", n);
    printf("Address of n: %p\n", (void*)&n);
    printf("Value of ptr_to_n (address it points to): %p\n", (void*)ptr_to_n);
    
    // Use the pointer to increment n by 1
    (*ptr_to_n)++;
    
    printf("After incrementing through pointer:\n");
    printf("New value of n: %d\n", n);
    printf("Value accessed through pointer: %d\n", *ptr_to_n);
    
    return 0;
}