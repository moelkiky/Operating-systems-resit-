#include <stdio.h>
#include <stdlib.h>

int main() {
    FILE *file;
    int number;
    int sum = 0;
    int count = 0;
    
    // Open the file for reading
    file = fopen("foo.txt", "r");
    
    // Check if file opened successfully
    if (file == NULL) {
        printf("Error: Could not open file foo.txt\n");
        printf("Make sure the file exists in the current directory.\n");
        return 1;
    }
    
    printf("Reading numbers from foo.txt:\n");
    printf("Numbers found: ");
    
    // Read integers from file until EOF
    while (fscanf(file, "%d", &number) == 1) {
        printf("%d ", number);
        sum += number;
        count++;
    }
    
    // Close the file
    fclose(file);
    
    printf("\n\nResults:\n");
    printf("--------\n");
    printf("Total numbers read: %d\n", count);
    printf("Sum of all numbers: %d\n", sum);
    
    return 0;
}