# Task 1.1 - Basic Pointer Operations

## Overview
This task demonstrates fundamental pointer operations in C, including pointer declaration, initialization, dereferencing, and using pointers to modify variables.

## Problem Statement
Create a program that:
1. Declares an integer variable `n` with value 10
2. Creates a pointer `ptr_to_n` that points to `n`
3. Displays the original value and address of `n`
4. Uses the pointer to increment `n` by 1
5. Shows the updated value through both direct access and pointer dereferencing

## Solution Approach

### Key Concepts Used
- **Pointer Declaration**: `int *ptr_to_n`
- **Address-of Operator**: `&n` to get the address of variable `n`
- **Pointer Assignment**: `ptr_to_n = &n`
- **Pointer Dereferencing**: `*ptr_to_n` to access/modify the value
- **Pointer Arithmetic**: `(*ptr_to_n)++` to increment through pointer

### Implementation Details
```c
int n = 10;                    // Declare and initialize integer
int *ptr_to_n = &n;           // Create pointer pointing to n
printf("Original value: %d\n", n);           // Direct access
printf("Address: %p\n", (void*)&n);          // Show memory address
printf("Pointer value: %p\n", (void*)ptr_to_n); // Pointer contains same address
(*ptr_to_n)++;                // Increment through pointer
printf("New value: %d\n", *ptr_to_n);        // Access through pointer
```

### Memory Layout
```
Memory Address    Variable    Value
0x7fff1234       n           10 → 11
0x7fff5678       ptr_to_n    0x7fff1234
```

## Testing Methodology

### Compilation
```bash
clang -o task1_1 task1_1.c
```

### Execution
```bash
./task1_1
```

### Expected Output
```
Original value of n: 10
Address of n: 0x7fff9934c428
Value of ptr_to_n (address it points to): 0x7fff9934c428
After incrementing through pointer:
New value of n: 11
Value accessed through pointer: 11
```

## Test Results Analysis

### ✅ Successful Outcomes
1. **Pointer Initialization**: Pointer correctly stores the address of variable `n`
2. **Address Verification**: Both `&n` and `ptr_to_n` show identical memory addresses
3. **Pointer Dereferencing**: Successfully accesses the value through the pointer
4. **Indirect Modification**: Incrementing through pointer correctly modifies the original variable
5. **Consistency**: Both direct access (`n`) and pointer access (`*ptr_to_n`) show the same updated value

### Key Learning Points
- Pointers store memory addresses, not values
- The `&` operator gets the address of a variable
- The `*` operator dereferences a pointer to access/modify the pointed value
- Modifying a value through a pointer affects the original variable
- Proper type casting with `(void*)` for printing addresses

### Memory Safety Features
- No dynamic memory allocation (stack-based variables)
- Pointer always points to a valid memory location
- No pointer arithmetic beyond basic dereferencing

## Practical Applications
This fundamental pointer knowledge is essential for:
- Function parameter passing by reference
- Dynamic memory allocation
- Array manipulation
- Data structure implementation
- System-level programming

## Compilation Notes
- Compiles cleanly with no warnings
- Uses standard C library functions only
- Compatible with C99 standard and later
- Portable across different architectures