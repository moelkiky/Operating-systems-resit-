#include <stdio.h>

int main() {
    // Create an array with 3 elements
    int arr[3] = {10, 30, 2000};
    
    // Declare a pointer to the array
    int *ptr = arr;  // arr is equivalent to &arr[0]
    
    printf("Array elements using pointer iteration:\n");
    printf("Element\tValue\tAddress\n");
    printf("-------\t-----\t-------\n");
    
    // Loop through the array using pointer arithmetic
    for (int i = 0; i < 3; i++) {
        printf("arr[%d]\t%d\t%p\n", i, *(ptr + i), (void*)(ptr + i));
    }
    
    printf("\nAlternative approach using pointer increment:\n");
    printf("Element\tValue\tAddress\n");
    printf("-------\t-----\t-------\n");
    
    // Reset pointer to beginning of array
    ptr = arr;
    
    // Another way to iterate using pointer increment
    for (int i = 0; i < 3; i++) {
        printf("arr[%d]\t%d\t%p\n", i, *ptr, (void*)ptr);
        ptr++;  // Move pointer to next element
    }
    
    return 0;
}